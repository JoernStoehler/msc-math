from continuous import *
tic=time.perf_counter();fs=families();cases=[r for r in json.load(open(str(WORK/'hull_state.json')))['bad'] if r['gap']<-1e-8]
# Also test an algebraic near-redundant direction giving an exact failure of the supplied 147-row bank.
cases.append(dict(D=(A[4]+A[7]+A[8]-2.9*A[0]).tolist(),gap=None))
out=[]
for i,r in enumerate(cases):
 print('CASE',i,'D',r['D'],flush=True)
 rr=run_direction(fs,np.array(r['D']),maxrounds=7)
 out.append(dict(D=rr['D'],volume=rr['volume'],initial_hull_gap=r['gap'],history=rr['history'],added_count=len(rr['added']),primal_witness=rr['primal_witness'],maximum_pivot_condition_f64=rr['maximum_pivot_condition_f64'],minimum_active_word_beta_f64=rr['minimum_active_word_beta_f64']))
 json.dump(dict(cases=out,seconds=time.perf_counter()-tic),open(str(WORK/'continuous_batch.json'),'w'),indent=2)
print('BATCH',len(out),'min_final_gap',min(r['history'][-1]['gap'] for r in out),'seconds',time.perf_counter()-tic,flush=True)
