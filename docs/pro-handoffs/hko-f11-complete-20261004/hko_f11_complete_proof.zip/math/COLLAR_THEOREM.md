# The complete scale-dependent collar certificate

The new finite predicate proves, in every one of twenty normalized tilt cones,

    Phi_j(D) >= v(D) + mu^2/1000,     0 <= mu <= 1/10,

where

    Phi_j(D)=sum_v (D.v)_+^2 (alpha_jv + ell_jv.D).

The coefficients and their realizing HK relations are in `collar/data/policies.json`.

## What is certified before the area comparison

For each selected path, beta_start>=0, beta_end>0, beta_new(start)=0, constraints hold identically, and Q(beta(s))=Q_H for the whole affine path. The new response is s C1+s^2 C2, with C1=4 beta_new(end) v and C2.a0=0. The gradient is quadratic in s.

Set s_v=10(D.v)_+. Since mu<=1/10, all ten s_v belong to [0,1]. Each policy combines these paths with nonnegative constant masses and old sections with nonnegative quadratic Bernstein weights. The checker verifies polynomial mass and all forty old-gradient identities. An exact anchor correction preserves nonnegativity throughout the entire independent cube [0,1]^10. Its maximum mixing fraction is approximately 2.30e-9.

Thus Phi_j is the support value of a point in closure(C). A fixed-direction strict gap gives a genuine finite positive-section certificate by approximation and anchor correction. Boundary paths are not silently differentiated as if all their weights were positive.

## What is certified for the volume comparison

Directions in a tilt cone have three coordinates (u,w,mu), with u,w>=0, u+w<=1 and 0<=mu<=1/10. The complete arrangement of the ten depth signs has eight full-dimensional cells. `geometry.py` enumerates intersections of every triple of defining planes, filters the exact inequalities, assigns all possible zero-sign choices, and triangulates every resulting three-dimensional cell by its facets. Boundedness ensures every cell vertex appears in this enumeration. Lower-dimensional cells follow by continuity.

On a sign cell, the moment formula in PROOF.md Section 5 makes v rational. Its denominator has known positive sign in the cone interior. Clearing that denominator reduces the comparison to degree-nine polynomial nonnegativity.

`integer_bernstein.py` expands the polynomial in homogeneous barycentric coordinates. The sign of a homogeneous coefficient is the sign of the corresponding Bernstein coefficient, since their conversion factor is positive. All 195,140 coefficients across 887 leaf tetrahedra are nonnegative, with 55,928 exact zeros. The full subdivision trees are checked; no hole is accepted from a depth limit or numerical failure.

The exact moment formula is separately compared with clipped-pentagon Fubini integration at 160 exact interior points, one per sign cell. The cleared integer polynomial is also compared exactly there with the direct rational expression. These crosschecks supplement, rather than replace, the derivation of the formula and the polynomial identity.

Nonzero margin mu^2/1000 persists for every mu>0. Vanishing denominators on tilt-cone boundaries are removed by continuity of the original inequality. This result is precisely the missing overlap: it extends all the way to mu=0, not merely to another positive cutoff.
