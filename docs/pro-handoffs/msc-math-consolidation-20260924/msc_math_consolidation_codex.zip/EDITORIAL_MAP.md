# Human-facing consolidation map

Current entrypoint (read at the pinned baseline): thesis/main.tex.
Relevant existing chapters:
- 04-quadratic-program: capacity/reduction foundations;
- 06-variation and 07-hko: local certificate method and HKO;
- 09-rotated-regular-polygons, 10-affine-pentagons, 11-product-position;
- 14-code-data, 00-abstract, 01-introduction, 16-conclusion;
- appendices/hko-certificate.tex and hko_core.py.

Suggested mathematical spine, allowing a better structure after reading:
1. HK feasible-section principle and the precise upper-bound direction.
2. A common local-certificate lemma: sharp first-order directions, equality
   parameters, and controlled quadratic transverse directions.
3. Two different local landscapes: HKO and the non-HKO ratio-one family.
4. One full affine-orbit bound with rigidity, followed by its genuinely useful
   corollaries; a minimal illustration of why product-only words are incomplete
   for general skew forms.
5. Precisely stated unresolved all-body/facet-changing questions.

Do not turn the PDF into a chronological log of Pro sessions. The second affine
proof, the discarded word-bank proposal, all mesh data, repeated special-case
proofs and negative search tables belong in source/evidence notes unless one
specific item teaches a method the reader needs.

Exact formula versus upper bound:
The full affine-orbit bound subsumes the weaker global inequality for independent
affine pentagon factors, but not that class's complete capacity formula.
Similarly it does not reproduce an entire angular capacity profile. Retain
those statements selectively, with their strongest genuinely informative scope.
The generic arbitrary-factor initial-rotation theorem has a different domain;
check its value rather than deleting it on a superficial general/special label.

Keep main proof trust boundaries readable: state a finite proposition, explain
its geometric implication, and point to a modest verifier where available.
Avoid replacing necessary proof bridges by 'CAS verifies' or printing enormous
certificates. Posterity preservation means a canonical, rerunnable source,
not keeping duplicate explanations in the thesis.
