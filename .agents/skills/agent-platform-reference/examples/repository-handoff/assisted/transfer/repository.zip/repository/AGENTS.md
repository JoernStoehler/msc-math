# Project guide

Read `docs/cache-policy.md` before building. From the repository root, run `bash scripts/build.sh`. This creates an inspectable `report.html` in the repository root. Open that file in the destination's supported file preview; a localhost server is not assumed to be visible across sessions.

The build uses Cargo and Python 3. Cargo availability must be checked in the destination. `AGENTS.md` may not load automatically in chat/Cowork, so explicitly read this file and the cache policy before continuing.
