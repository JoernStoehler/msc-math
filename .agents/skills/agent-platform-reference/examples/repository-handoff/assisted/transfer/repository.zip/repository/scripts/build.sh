#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cache_root="${XDG_CACHE_HOME:-${TMPDIR:-/tmp}}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-${cache_root%/}/handoff-example/cargo-target}"
mkdir -p -- "$CARGO_TARGET_DIR"

cd "$repo_root"
cargo build --target-dir "$CARGO_TARGET_DIR"
python3 scripts/report.py
