# New in the current session

Read LOCAL_COVER_RIGIDITY.md for the local arbitrary-convex-partner result and
its exact 50-marginal certificate. This is newly derived here, not yet an
independent review. The geometric local signed-polygon bound must be reviewed
as well as the executed algebra.

LOCAL_CUT_LIFTING.md extends the previous coupled Case IV argument to Case III
using a simple uniform tube-volume estimate. It still does not cover Cases I/II.
SMOOTH_CELL_REDUCTION.md is a first contact-reduction lemma, not a global proof.

Run from this directory, with a fresh output path:

    python verify_local_cover.py --fixture-code pentagon_fixture.py --out fresh.json
    python hko_single_orbit_check.py

SymPy is the only dependency of these checks. The numerical local-expansion
sample is diagnostic, not a proof premise. No full F=11 or global fixed-partner
theorem is claimed. Exact comparison data contain timing only as provenance.
