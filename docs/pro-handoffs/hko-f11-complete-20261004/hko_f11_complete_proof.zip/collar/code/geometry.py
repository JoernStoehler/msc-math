"""Complete exact three-dimensional arrangement and pulling/star triangulation."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/"core/code"))
from exact_tools import *
from functools import lru_cache
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[2]

def det3(M):
 return M[0][0]*(M[1][1]*M[2][2]-M[1][2]*M[2][1])-M[0][1]*(M[1][0]*M[2][2]-M[1][2]*M[2][0])+M[0][2]*(M[1][0]*M[2][1]-M[1][1]*M[2][0])
def affrank3(vs):
 if len(vs)<4:return False
 ds=[[x[k]-vs[0][k] for k in range(3)] for x in vs[1:]]
 return any(det3(t) for t in itertools.combinations(ds,3))
def Hvalue(h,x):return h[0]+a.dot(h[1:],x)
def key(H):return tuple(tuple(c.a for c in h) for h in H)
cache={}

def build(cone):
 eta=a.K(F(1,10));trees=json.load(open(ROOT/'core/data/tree.json'));ex=exact_prisms(eta);T=[a.add(x,a.scale(-eta,a.A[0])) for x in ex[trees['root_permutation'][3*cone]][:3]]
 M=list(map(list,zip(a.add(T[0],a.scale(-1,T[2])),a.add(T[1],a.scale(-1,T[2])),a.A[0])));Fv=[u+w for u in a.U[:2] for w in a.W]
 dep=[[a.dot(v,T[2])]+a.mv(list(map(list,zip(*M))),v) for v in Fv]
 base=[[ZERO,ONE,ZERO,ZERO],[ZERO,ZERO,ONE,ZERO],[ONE,-ONE,-ONE,ZERO],[ZERO,ZERO,ZERO,ONE],[eta,ZERO,ZERO,-ONE]]
 kk=tuple(key(dep))
 if kk in cache:return T,dep,cache[kk]
 tic=time.perf_counter();planes=[]
 for h in base+dep:
  # Canonical hyperplane normalization by first nonzero coefficient, regardless of side.
  non=next(x for x in h if x);q=[x/non for x in h]
  if q not in planes:planes.append(q)
 vertices={}
 for inds in itertools.combinations(range(len(planes)),3):
  mat=[planes[i][1:] for i in inds];dt=det3(mat)
  if not dt:continue
  rhs=[-planes[i][0] for i in inds];v=[]
  for k in range(3):
   mc=[row[:] for row in mat]
   for i in range(3):mc[i][k]=rhs[i]
   v.append(det3(mc)/dt)
  if all(a.sign(Hvalue(h,v))>=0 for h in base):vertices[tuple(v)]=inds
 cells=defaultdict(list)
 for v in vertices:
  sig=[a.sign(Hvalue(h,v)) for h in dep];zeros=[i for i,x in enumerate(sig) if x==0]
  for signs in itertools.product([-1,1],repeat=len(zeros)):
   new=sig[:]
   for i,sg in zip(zeros,signs):new[i]=sg
   cells[tuple(new)].append(list(v))
 valid=[];roots=[]
 for signs,vs in sorted(cells.items()):
  if not affrank3(vs):continue
  hs=base+[a.scale(s,h) for s,h in zip(signs,dep)];center=[sum((v[k] for v in vs),ZERO)/len(vs) for k in range(3)];faces=set();tris=[]
  a.require(all(a.sign(Hvalue(h,center))>0 or all(Hvalue(h,v)==ZERO for v in vs) for h in hs),'cell barycenter interior')
  for h in hs:
   ids=[i for i,v in enumerate(vs) if Hvalue(h,v)==ZERO]
   if len(ids)<3:continue
   fs=tuple(sorted(ids))
   if fs in faces:continue
   # Exact 2D convex hull in a coordinate projection of this plane.
   drop=next((k for k in range(3) if h[k+1]),None)
   if drop is None:continue
   keep=[k for k in range(3) if k!=drop];ps=hull2([[vs[i][k] for k in keep] for i in ids])
   if len(ps)<3:continue
   lookup={tuple(vs[i][k] for k in keep):i for i in ids};ordered=[lookup[tuple(p)] for p in ps];faces.add(fs)
   for j in range(1,len(ordered)-1):
    tri=[vs[ordered[i]] for i in [0,j,j+1]];tet=[center]+tri
    a.require(det3([[x[k]-center[k] for k in range(3)] for x in tri])!=ZERO,'nondegenerate star tetrahedron')
    tris.append(tet);roots.append(dict(vertices=tet,signs=signs))
  valid.append(dict(signs=signs,vertices=vs,facets=len(faces),tetrahedra=tris))
 result=dict(planes=planes,vertices=list(vertices),cells=valid,roots=roots,seconds=time.perf_counter()-tic);cache[kk]=result
 print('exact arrangement',cone,'planes',len(planes),'vertices',len(vertices),'cells',len(valid),'roots',len(roots),'seconds',result['seconds'],flush=True)
 return T,dep,result

