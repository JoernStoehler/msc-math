# Exact remaining scope and the Hausdorff reduction

## What is proved and what is not

Theorem R proves complete parameter neighborhoods whenever the extra normal
limits to the relative interior of any of the 35 polar edges. The audited
supplied lifting covers the interiors of the 50 polar triangles and 25
polar tetrahedra. The interior of the polar is redundant in a neighborhood.
Theorem F-sector additionally proves explicit coupled angular sectors at
the ten polar vertices.

**The unrestricted duplicate-normal neighborhoods are still missing.** No
improving family with a capacity lower bound has been constructed. This
packet therefore neither proves nor decisively falsifies full HKO local
maximality for at most eleven genuine facets.

## 1. A concrete description of the missing parameters

By the checked HKO symmetries, the base duplicate normal may be taken to be
\(a_0\). In the accepted local normalization write

\[
 A=A_0+H,\qquad b=a_0(A)+d,\qquad r=\|H\|\to0,\quad d\to0.
\]

Here \(F(A)\) is the moving old facet at label 0. The exact redundant cases
should first be removed:

* If \(\max_{F(A)}d\cdot x\leq0\), the added inequality is redundant.
* If \(\min_{F(A)}d\cdot x\geq0\), the old label-0 inequality is redundant
  after adding the new one, so the body again has a nearby ten-facet
  presentation.

For the first assertion, support maxima for a normal near \(a_0(A)\) occur
on the vertices of \(F(A)\), all other old vertices having a fixed gap.
For the second, suppose a point satisfying the other nine inequalities
and \(b\cdot x\leq1\) had \(a_0(A)\cdot x>1\). Its radial contraction to
\(a_0(A)\cdot z=1\) belongs to \(F(A)\) and satisfies \(b\cdot z<1\),
contradicting \(d\cdot z\geq0\). Both cases follow from the accepted F=10
theorem. They are inequalities on a cone, not a linear-kernel statement.

A genuinely split case therefore has

\[
 m_+(A,d)=\max_{F(A)}d\cdot x>0,\qquad
 m_-(A,d)=-\min_{F(A)}d\cdot x>0.                  \tag{B1}
\]

Normalize
\[
 t=m_++m_->0,\qquad D=d/t,\qquad \mu=m_+/t\in(0,1).
\]
Then \(\operatorname{osc}_{F(A)}D\cdot x=1\),
\(\min D\cdot x=\mu-1\), and \(\max D\cdot x=\mu\).
These normalized directions are bounded: the vertices of this affine
three-face span \(\mathbb R^4\) linearly, so bounded values of the linear
functional on them bound \(D\). Their limit set at \(A_0\) is the compact
set

\[
 \mathcal D=\{D:\operatorname{osc}_{F_0}D\cdot x=1,
                    \min_{F_0}D\cdot x\leq0\leq\max_{F_0}D\cdot x\}.
                                                               \tag{B2}
\]

The elementary facet cap bound and F=10 imply
\(S\leq-\kappa r+Ct\). Thus any putative improving sequence in these
coordinates must have \(r=O(t)\). The residual task is to control **all**
normalized directions in (B2), outside the explicitly proved angular
sectors and their label/symmetry images, with **all** \(H=O(t)\).
The endpoint regimes \(\mu\to0\) or \(1\) are included in this obligation;
they cannot be discarded because the limiting direction itself is
redundant. Joint limits of the open-ridge parameter with the cut scale
belong to precisely these duplicate charts.

This is a bounded-direction problem after normalization, but not a
justification for uniformity: the negative term can vanish at the boundary
of (B2), and its relative error still needs to be controlled.

## 2. An explicit sufficient first-order inequality that is not yet proved

For a tight positive feasible duplicate-normal section \(k\), let \(G_k\)
and \(c_k\) be the aggregate old gradient and cut covector defined in (F5).
Let
\[
 v(D)=\frac1{V_0\|a_0\|}\int_{F_0}(D\cdot x)_+\,dS.
\]

For each interior sign-changing direction \(D\), a sufficient certificate
would be a positive combination of actual feasible sections satisfying

\[
 \sum\lambda_k=1,\qquad\sum\lambda_kG_k=0,\qquad
 \sum\lambda_k c_k\cdot D\geq v(D)+m(D),\quad m(D)>0.           \tag{B3}
\]

On compact direction sets with a positive lower bound for \(m(D)\), finite
feasible-section continuation and the scale split in Theorem F-sector
would give a uniform coupled neighborhood. Near \(\mu=0,1\), one additionally
needs remainders uniform relative to the vanishing margin, or a separate
endpoint argument. One must allow a continuum of split weights when
necessary. Condition (B3) is a sufficient upper-witness route, not an
asserted characterization of the true capacity derivative.

The 26-section certificate in this packet proves (B3) on one quantified
ball of directions and its symmetry/copy-interchange images. The general
inequality and its boundary-scale implication are not established.

## 3. What the facet searches actually show

The initial 65-seed-derived finite split bank had 1,032 positive sections.
Ten of 313 sampled directions defeated that finite bank. Optimizing the
continuous split parameter removed most such gaps, but not all. Adding
further tight old-normal families changed the conclusion again: the
9,206-section enriched diagnostic bank gave a positive margin on the three
retained targeted tests, including the prior worst direction and
\((8,6,13,-11)\).

The latter direction was then converted into the exact 26-section
certificate and the open-sector proof in `FACET_SECTOR.md`. Thus the earlier
failed bank is specifically **not** an obstruction to that direction, much
less a falsification of HKO. The retained discovery outputs are explicitly
numerical; they assert neither complete enumeration of minimizing words
nor a lower capacity bound. The phrase “seven-support enrichment” means
sampled flat insertions into the supplied six-support seeds, not all
seven-support minimizers.

## 4. Why the remaining duplicate charts are exactly the Hausdorff blocker

Let \(K_n\to P_0\) in Hausdorff distance, with at most eleven genuine facets.
The origin remains in a common inner ball. Polarity is continuous on such
uniformly bounded bodies, so \(B_n=K_n^\circ\to B_0=P_0^\circ\), and each
\(B_n\) has at most eleven vertices.

Each of the ten vertices \(a_i\) of \(B_0\) is exposed. Choose for each an
exposing functional and a small neighborhood disjoint from the other nine.
A maximizer of that functional on \(B_n\) may be chosen to be a vertex, and
must lie near \(a_i\): otherwise a subsequential limit would be a different
maximizer on \(B_0\). Thus, for all sufficiently large \(n\), one can label
ten distinct vertices \(a_{i,n}\to a_i\). There is at most one remaining
vertex. If there is none, F=10 applies. Otherwise pass to a subsequence and
write the remaining vertex as \(b_n\to b_0\in B_0\). This gives exactly the
parameter presentation used in this packet, with ten old normals tending
to \(A_0\) and one extra normal.

If \(b_0\) is in the polar interior, in an open edge, in an open triangle,
or in an open tetrahedron, the corresponding actual neighborhood theorem
excludes an improving sequence. Therefore any still-possible improving
sequence must have \(b_0=a_i\) for one of the ten vertices. The explicit
facet sectors exclude further such sequences, but not all of them.

If full neighborhoods at all ten duplicate vertices were proved, the base
locus \(\{A_0\}\times B_0\) would be covered and compactness would complete
the target Hausdorff theorem. We do **not** invoke compactness of the
punctured polar, nor promote the separate open-edge radii to endpoint
uniformity. This is the precise final assembly step that remains blocked.
