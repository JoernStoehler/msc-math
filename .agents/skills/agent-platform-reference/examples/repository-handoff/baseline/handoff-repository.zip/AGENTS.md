# Project guide

Run `bash scripts/build.sh` to build the Rust project and generate `report.html`.

Keep build caches out of tracked source. Choose a writable cache path from the current runtime environment (`CARGO_TARGET_DIR`, then `XDG_CACHE_HOME`, then `$HOME/.cache`) rather than reusing a path from another machine. Do not assume Rust/Cargo is installed in a new runtime; check first and report the exact blocker if it is missing.

After generating the report, serve the repository with `python3 -m http.server 8000` and open `http://localhost:8000/report.html` when the destination supports local preview. Verify destination-specific preview support before relying on it.
