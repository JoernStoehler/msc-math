#!/usr/bin/env python3
"""Run all finite proof checks, with fresh output and optional negative controls."""
import argparse,json,platform,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--negative-controls',action='store_true');q=p.parse_args();out=q.out.resolve()
 if out.exists():raise FileExistsError('Use a new output directory: '+str(out))
 out.mkdir(parents=True);jobs=[('inherited_ridges',[sys.executable,str(ROOT/'inherited/code/exact_core.py'),'--data',str(ROOT/'inherited/data'),'--out',str(out/'inherited_ridges.json')],None),('inherited_endpoints',[sys.executable,str(ROOT/'inherited/code/check_new.py'),'--out',str(out/'inherited_endpoints.json')],None),('core',[sys.executable,str(ROOT/'core/verify.py'),'--out',str(out/'core.json')],None),('collar',[sys.executable,str(ROOT/'collar/verify.py'),'--out',str(out/'collar.json')],None)]
 if q.negative_controls:
  jobs.extend([('reject_missing_core_leaf',[sys.executable,str(ROOT/'core/verify.py'),'--out',str(out/'SHOULD_NOT_EXIST_1.json'),'--negative-control','leaf'],'every leaf certified exactly once'),('reject_negative_policy_weight',[sys.executable,str(ROOT/'collar/verify.py'),'--out',str(out/'SHOULD_NOT_EXIST_2.json'),'--negative-control','negative_weight'],'nonnegative path weight'),('reject_false_polynomial_bound',[sys.executable,str(ROOT/'collar/verify.py'),'--out',str(out/'SHOULD_NOT_EXIST_3.json'),'--negative-control','false_bound'],'nonnegative exact homogeneous coefficients')])
 start=time.perf_counter();stages=[]
 for name,command,expected in jobs:
  tic=time.perf_counter();res=subprocess.run(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);elapsed=time.perf_counter()-tic;(out/(name+'.log')).write_text(res.stdout)
  ok=(res.returncode==0) if expected is None else (res.returncode!=0 and expected in res.stdout)
  stages.append(dict(name=name,passed=ok,seconds=elapsed,command=command,returncode=res.returncode,expected_failure=expected));print(name, 'PASS' if ok else 'FAIL',round(elapsed,3),'seconds',flush=True)
  if not ok:raise RuntimeError('See '+str(out/(name+'.log')))
 summary=dict(all_passed=True,seconds=time.perf_counter()-start,stages=stages,python=sys.version,platform=platform.platform(),scope='Finite predicates for the complete proof; read PROOF.md for the mathematical implication and accepted F=10 input.');(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print('ALL STAGES PASSED',summary['seconds'],'seconds',flush=True)
if __name__=='__main__':main()
