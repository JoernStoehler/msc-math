#!/usr/bin/env python3
"""Exact arithmetic checks for the endpoint proof and finite-bank obstruction.

Python standard library only. These checks certify finite identities; the
uniform analytic estimates are proved in math/ENDPOINTS.md, not by this script.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse, hashlib, json, time
import exact_core as a
import duplicate_workspace as dw

def enc(x):return dw.encoded(x)
def perm(i,k,s):return 5*((i//5+s)%2)+(i%5+k)%5
def pv(v,k,s):
 i,j=divmod(v,5)
 if s:i,j=j,i
 return 5*((i+k)%5)+(j+k)%5

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
 root=Path(__file__).resolve().parents[1];data=root/'data';tic=time.perf_counter()
 seeds=json.loads((data/'seeds.json').read_text())
 rawzero=json.loads((data/'zero_ridges.json').read_text());rawridge=json.loads((data/'ridge_certificates.json').read_text())
 cache={}
 def seed(index,k=0,s=0):
  key=(index,k,s)
  if key not in cache:
   r=seeds[index];cache[key]=a.Section(a.A,[perm(i,k,s) for i in r['sigma']],[a.VALUES[w] for w in r['weights']],r['pivot'])
  return cache[key]
 def contact(sec,br,v):
  for b in [[a.ZERO]*4]+a.BASIS:
   L,R=a.insertion(sec,br,b)
   a.require(L==2*a.Q0*(a.dot(a.V[v],b)-1),'full affine insertion contact')
 # Every neighbor j of vertex a0 in the polar must be present.
 expected={j for j in range(1,10) if any(a.dot(a.A[0],v)==a.dot(a.A[j],v)==a.ONE for v in a.V)}
 a.require(expected=={1,4,5,6,7,8,9},'seven polar neighbors of a0')
 zero_outputs=[];vertex_contacts={}
 for j in [1,4,5]:
  chosen=None
  for edge in [(0,1),(0,5)]:
   for s in [0,1]:
    for k in range(5):
     if {perm(i,k,s) for i in edge}=={0,j}:chosen=(edge,k,s);break
    if chosen:break
   if chosen:break
  a.require(chosen is not None,'zero-edge symmetry')
  edge,k,s=chosen;rows=[r for r in rawzero if tuple(r['edge'])==edge];vs=[]
  for r in rows:
   br=r['branch'];ss=seed(br['seed'],k,s);v=pv(r['vertex'],k,s);contact(ss,br,v);vs.append(v)
   for u in [a.ZERO,a.K(F(1,2)),a.ONE]:
    b=a.add(a.scale(1-u,a.A[0]),a.scale(u,a.A[j]));L,R=a.insertion(ss,br,b)
    a.require(R==a.ZERO,'identically zero quadratic edge cost')
   a.require(a.insertion(ss,br,a.A[0])[1]==a.ZERO,'zero duplicate cost')
   vertex_contacts.setdefault(v,dict(seed=br['seed'],rotation=k,swap=s,branch=br))
  want=[i for i,v in enumerate(a.V) if a.dot(a.A[0],v)==a.dot(a.A[j],v)==a.ONE]
  a.require(set(vs)==set(want),'complete zero-edge contact coverage')
  zero_outputs.append(dict(neighbor=j,vertices=vs,rotation=k,swap=s))
 facet_vertices=[i for i,v in enumerate(a.V) if a.dot(a.A[0],v)==a.ONE]
 a.require(set(vertex_contacts)==set(facet_vertices),'all ten facet vertices have flat duplicate insertion')
 print('PASS all 10 facet vertices have exact contact and R(a0)=0',flush=True)
 ridge_outputs=[]
 for j in [6,7,8,9]:
  chosen=None
  for rec in rawridge:
   endpoint=rec['half']
   for s in [0,1]:
    for k in range(5):
     e=rec['edge']
     if perm(e[endpoint],k,s)==0 and perm(e[1-endpoint],k,s)==j:
      chosen=(rec,k,s);break
    if chosen:break
   if chosen:break
  a.require(chosen is not None,'nonzero endpoint chart covered')
  rec,k,s=chosen;gradient=[a.ZERO]*40;mass=a.ZERO
  d=[];u=[a.K(F(x)) for x in rec['u']]
  M=[[a.ZERO]*4 for _ in range(4)]
  for tri in [(0,1,3),(0,2,3)]:
   for i in tri:
    for l in tri:M[i][l]+=a.K(F(2 if i==l else 1,24))
  d=[a.dot(M[i],u)/u[i] for i in range(4)]
  sos=[[a.ZERO]*4 for _ in range(4)]
  from itertools import combinations
  for i,l in combinations(range(4),2):
   vv=[(1/u[i] if p==i else -1/u[l] if p==l else a.ZERO) for p in range(4)]
   for p in range(4):
    for q in range(4):sos[p][q]+=M[i][l]*u[i]*u[l]*vv[p]*vv[q]
  a.require(sos==[[(d[i] if i==l else a.ZERO)-M[i][l] for l in range(4)] for i in range(4)],'square quadrature SOS')
  vertices=[pv(v,k,s) for v in rec['vertices']];gain={v:a.ZERO for v in vertices};count=0
  for term in rec['terms']:
   lam=a.decode(term['weight']);a.require(a.sign(lam)>0,'positive cancellation weight');mass+=lam
   ss=seed(term['seed'],k,s);gq=ss.gradient();G=[-2*x/a.Q0-a.VOL_GRAD[i]/a.V0 for i,x in enumerate(sum(gq,[]))]
   gradient=a.add(gradient,a.scale(lam,G));br=term['branch']
   if br is None:continue
   v=pv(term['vertex'],k,s);contact(ss,br,v);Rs=[]
   for z in [a.ZERO,a.K(F(1,2)),a.ONE]:
    b=a.add(a.scale(1-z,a.A[0]),a.scale(z,a.A[j]));Rs.append(a.insertion(ss,br,b)[1])
   a.require(Rs[0]==a.ZERO and a.sign(Rs[1])<0 and a.sign(Rs[2])<=0,'endpoint cost signs')
   gamma=-a.Q0/(2*Rs[1]);gain[v]+=lam*gamma;count+=1
  a.require(mass==a.ONE and gradient==[a.ZERO]*40,'exact aggregate old-gradient cancellation')
  theta=a.decode(rec['theta'])
  a.require(a.sign(theta-a.K(F(2,25)))>0,'strict rescaled coefficient gap')
  for v,dd in zip(vertices,d):a.require(a.sign(gain[v]-theta*dd)>=0,'vertex-resolved gain dominates quadrature')
  ridge_outputs.append(dict(neighbor=j,vertices=vertices,terms=len(rec['terms']),insertions=count,theta=enc(theta),coefficient_gap=enc(theta-a.K(F(2,25))),rotation=k,swap=s,source_half=rec['half']))
  print('PASS rescaled nonzero-pairing chart (0,%s), positive coefficient gap'%j,flush=True)
 endpoint_seconds=time.perf_counter()-tic
 # Regenerate the exact 147-section supplied bank rather than trust rounded rows.
 tic2=time.perf_counter();bank=dw.prepare();a.require(bank['section_count']==147,'147 supplied-bank sections')
 D0=a.add(a.add(a.A[4],a.A[7]),a.add(a.A[8],a.scale(-3,a.A[0])))
 eps=a.K(F(1,10));D=a.add(D0,a.scale(eps,a.A[0]));v=dw.volume_response(D)
 vals=[a.dot(D0,a.V[i]) for i in facet_vertices]
 a.require(vals[facet_vertices.index(3)]==a.ZERO and all(a.sign(x)<0 for i,x in zip(facet_vertices,vals) if i!=3),'unique exposed facet vertex')
 a.require(a.sign(v)>0,'strict positive cap slope')
 used=0;unused=0;minimum=None;max_strict=None
 for row in bank['sections']:
  c=list(map(a.decode,row['c']));be=list(map(a.decode,row['beta']))
  if 10 not in row['sigma']:
   a.require(c==[a.ZERO]*4,'unused duplicate response zero');unused+=1;continue
  used+=1;beta=be[row['sigma'].index(10)]
  a.require(a.dot(c,a.A[0])==4*beta,'midpoint response mass')
  threshold=-a.dot(c,D0)/(4*beta)
  a.require(a.sign(threshold-eps)>0,'all active bank responses strictly negative at witness')
  if minimum is None or a.sign(threshold-minimum)<0:minimum=threshold
  cd=a.dot(c,D)
  if max_strict is None or a.sign(cd-max_strict)>0:max_strict=cd
 # The old cancellation relation with all c=0 proves bank support is exactly 0,
 # not merely <=0. Obtain it by merging duplicate labels in the sector relation.
 secdata=json.loads((data/'facet_cone_certificate.json').read_text())
 # A primal relation is not needed for failure of containment: h<=0<v suffices.
 # We assert only <=0 here; no unverified membership of a merged word is used.
 finite_seconds=time.perf_counter()-tic2
 print('PASS exact finite-bank separation: every c.D <= 0 < volume_response(D)',flush=True)
 out=dict(status='Finite exact identities checked; analytic statements are in math/.',all_checks_passed=True,
  endpoint_charts=dict(neighbors=sorted(expected),facet_vertex_contacts=vertex_contacts,zero_pairing=zero_outputs,nonzero_pairing=ridge_outputs,seconds=endpoint_seconds),
  finite_bank_obstruction=dict(sections=147,used_duplicate=used,unused_duplicate=unused,exposed_vertex=3,D0=[enc(x) for x in D0],epsilon=enc(eps),D=[enc(x) for x in D],minimum_activation_threshold=enc(minimum),minimum_activation_threshold_nominal=a.nominal(minimum),largest_active_c_dot_D=enc(max_strict),volume_response_exact=enc(v),volume_response_nominal=a.nominal(v),oscillation_exact=enc(a.K(5)),normalized_mu=enc(a.K(F(1,50))),support_upper_bound=0,seconds=finite_seconds),
  input_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(data.glob('*.json'))},total_seconds=time.perf_counter()-tic)
 args.out.parent.mkdir(parents=True,exist_ok=True)
 with args.out.open('w') as f:json.dump(out,f,indent=2);f.write('\n')
 print('ALL NEW EXACT CHECKS PASSED in %.3f s'%out['total_seconds'],flush=True)
if __name__=='__main__':main()
