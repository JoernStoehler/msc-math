# Exact core theorem and finite predicate

See PROOF.md Sections 2--3 for notation. Every D with osc_F(D)=1 and 1/10<=max_F D<=9/10 has a finite positive-section cancellation response c with

    c.D - v(D) >= 1/1,000,000.

This is a whole-domain statement. The proof does not use random rays or a numerical grid extension estimate.

The unit-oscillation tilt domain is the join of the two interval-axis directions with the boundary of the polar of W-W. This gives twenty tilt triangles, each extruded through the offset interval [1/10,9/10]. The sixty root tetrahedra are reconstructed exactly in `code/exact_tools.py::exact_prisms`. Their geometry follows directly from

    osc_F D = |D_q.(U_1-U_0)| + h_W(D_p)+h_W(-D_p).

`data/tree.json` records midpoint bisections. The verifier starts at every root, traverses every child once, and checks that all and only terminal nodes have a certificate. The 1,968 leaf tetrahedra therefore cover the core. A convex function v lies below affine interpolation of its vertex values, so one response beating v at a tetrahedron's four vertices beats it throughout that tetrahedron.

`data/rows.json` identifies positive algebraic weights in stored flat families. The verifier independently checks each actual weight vector, rather than relying on family completeness: positivity, closure, normalization, Q=Q_H, invertible five-column minor, and stationarity. It computes the derivative from the literal quadratic and linear solve formula, with additional direct differentiated-section crosschecks.

Each relation has nonnegative rational weights of total one. Its remaining tiny algebraic gradient residual is removed using the 65-row positive old anchor. All forty coordinates and the mass are checked after correction. The resulting exact response is compared with exact positive-part facet integrals at every leaf vertex.

A merely stationary but infeasible section, a rounded cancellation, or a zero-weight base point would not suffice. The accepted core certificate contains none of those substitutes. Its small positive base weights may lead to a small spatial radius, but no numerical radius is needed for the existence theorem.
