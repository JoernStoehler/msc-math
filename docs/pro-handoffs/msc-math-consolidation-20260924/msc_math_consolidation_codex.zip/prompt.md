# Codex consolidation assignment

## Objective

Absorb the new results into JoernStoehler/msc-math and the main MSc manuscript.
Optimize the mathematical narrative for a human reader, not the number of
imported pages or passed scripts. The user explicitly wants specialized proofs
kept for posterity in the repo while the PDF focuses on the general result.

This is not a request for another search, another opinion about the whole
thesis, or an exhaustive literature survey. Mathematical corrections and small
proof closures necessary for integration are in scope. Keep unrelated thesis
work intact unless a direct dependency requires a change.

## First actions

1. Inspect the real checkout, current instructions, branch/worktree and dirty
   state. Reconcile with REPOSITORY.md; never reset newer work to the pinned SHA.
2. Inventory incoming/ using ARCHIVE_REGISTRY.json. Extract to a scratch area;
   do not blindly vendor nested input ZIPs or duplicate copied proof trees.
3. Read the proof-to-claim map. Decide which statements are accepted inputs,
   independently checked project results, newly proposed corollaries, or open.
4. Build the unmodified selected thesis once if practical; record source/PDF
   identity. This provides a comparison, not a readiness verdict.

## Parallelism

Use subagents where available, with disjoint ownership and one integrating
editor. Suggested independent tasks:
- non-HKO local family: exact witness, full neighborhood implication, equality;
- global affine HKO theorem: compare both proofs, review rigidity and the
  affine-shape neighborhood corollary;
- cover material: audit the newly discovered nested restricted-class packet,
  the new local-cover lemma/certificate, and correct scope of the cut lifting;
- source/artifact integration and tests, with no edits to mathematics assigned
  to another worker;
- a final reader-facing audit of only the changed chapters and cross-references.
Do not have multiple writers concurrently rewrite main.tex or the same chapter.
Independent checking need not mean repeatedly performing the same full search.

## Proof and trust requirements

Read the mathematical implication as well as the code. Exact verification does
not prove an unstated continuum argument. Distinguish original authorship,
proposed certificate data, an independent implementation, independent
mathematical review, and human acceptance. Shared exact-arithmetic libraries
and reused witness data should remain visible without verbose ritual caveats.

The added LOCAL_COVER_RIGIDITY.md is new in this session. Review its local
winding/area estimate, the positive-marginal-to-interior-convex-hull implication,
and the passage from translations to all nearby convex covers. Fix or demote
it if needed. Its exact check passed; it is not externally refereed.

The original global fixed-partner partial packet is nested in the continuation
return; it is now exposed separately in incoming/. Its full exact run was
reproduced in this session. That is not an independent implementation of the
whole finite-fan proof. Give its continuum proof an independent read before
using it to narrow a stated unresolved region.

## Main manuscript scope

Follow EDITORIAL_MAP.md as a recommendation, not a forced table of contents.
Lead with mathematical phenomena and theorem statements. Explain the capacity
inequality direction once where it is used. Give finite predicates and the
reason they imply a neighborhood/global result, but do not print huge meshes,
all 804 inequalities, 92,323 simplices, raw search logs, or redundant variants.

The non-HKO local theorem is a real new landscape result: a two-parameter
family near its specified base, ratio 1, strict transverse decrease in the
full ten-facet chart. Do not call it a new Viterbo counterexample or global max.

The full affine theorem supersedes weaker AFFINE-CLASS BOUNDS, not every
specialized capacity formula. A bound plus rigidity does not reproduce the
complete rotated capacity profile or the independent-affine formula. Keep a
short statement/example if it adds explanatory value; preserve the derivation
in the repository. The generic product-position result concerns arbitrary
factors and is not logically subsumed by an HKO-only affine theorem.

The shorter analytic affine proof should normally carry the main exposition.
The exact polytope/polarized-Pfaffian proof is useful alternative mathematics,
not another theorem. Archive it with a short pointer and proof idea, rather
than making the reader traverse both proofs.

Decide explicitly whether the restricted normal-cover results belong in the
main PDF or a companion research note. They must not consume the manuscript
merely because they exist. The new local-cover result may justify a compact
corollary/subsection once independently accepted. Do not integrate an unproved
full F=11 theorem. Small cut lemmas belong in a clearly scoped note unless they
serve a current main result.

## Repository integration

Use ordinary owner directories and the repository's artifact policy. Preserve
original return ZIP bytes or a durable, verified registered location with hashes;
avoid committing duplicate datasets in nested handoffs. Give each retained
proof, checker, certificate and summary a canonical source owner and runnable
command. Keep original evidence immutable; new reruns use fresh directories.

Use small auditable commits on a suitable work branch. No force pushes, resets
or destructive deletion of unrelated work. Do not upload private material to
new services. Report local versus committed/pushed state literally.

Reconcile claims in the abstract, introduction, local-max section, affine section,
conclusion and code/data availability. Update AI/provenance disclosure with
actual source roles, not fabricated human review or timing claims. Track which
old labels/theorems moved and why; fix citations and cross references.

## Completion

Build using `sh thesis/build.sh`. Inspect changed rendered pages, especially
long equations, tables, code listings, section transitions and bibliography.
A successful TeX build is necessary but not a readability or correctness proof.

Return one result ZIP or the project-standard equivalent containing:
- the updated PDF and exact source/commit identity;
- a patch/branch summary and canonical paths of integrated material;
- theorem/claim disposition including any demotions or unresolved blocker;
- actual test/build commands and logs;
- a compact human reading guide: what changed, which old proofs left the PDF,
  and where they were preserved.

Do not spend this assignment trying to prove uniqueness/global optimality
outside the solved affine class. Do not end with only an implementation plan.
