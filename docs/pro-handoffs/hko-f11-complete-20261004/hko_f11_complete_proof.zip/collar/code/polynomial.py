"""Exact full-collar polynomial inequality using the prepared exact response policies.
Separate policy-feasibility verifier is required; this proves the analytic volume
comparison once those response polynomials have been established.
"""
from geometry import *
import integer_bernstein as ip
import argparse,sys

class Checker:
 def __init__(self,cone):
  pol=json.load(open(ROOT/'collar/data/policies.json'))['policies'][cone];self.av=list(map(a.decode,pol['av']));self.bv=[list(map(a.decode,r)) for r in pol['bv']];self.T,self.dep,self.geo=build(cone);self.gamma=a.K(F(1,1000));self.edges=[a.add(a.W[(i+1)%5],a.scale(-1,a.W[i])) for i in range(5)];mid=[sum((p[k] for p in self.T),ZERO)/3 for k in range(4)];self.sgn=[a.sign(a.dot(mid[2:],e)) for e in self.edges];a.require(all(self.sgn),'nonzero interior edge projections');self.qmax=0 if a.sign(a.dot(self.T[0][:2],a.add(a.U[0],a.scale(-1,a.U[1]))))>0 else 1
  self.vcoeff=[]
  for qi in range(2):
   for j in range(5):
    e0=a.scale(-1,self.edges[(j-1)%5]);e1=self.edges[j];dt=a.det2(e0,e1);dt=a.K(a.sign(dt))*dt;coeff=dt/(60*a.area(a.W))*(-self.sgn[(j-1)%5]*self.sgn[j])*(1 if qi==self.qmax else -1);self.vcoeff.append(coeff)
  self.pden=ip.common_den(self.av+sum(self.bv,[])+self.vcoeff+[self.gamma]);self.ai=[ip.convert(x,self.pden) for x in self.av];self.bi=[[ip.convert(x,self.pden) for x in r] for r in self.bv];self.vi=[ip.convert(x,self.pden) for x in self.vcoeff];self.gi=ip.convert(self.gamma,self.pden);self.fv=[u+w for u in a.U[:2] for w in a.W]
 def D(self,X):
  return [a.add(a.add(a.add(self.T[2],a.scale(x[0],a.add(self.T[0],a.scale(-1,self.T[2])))),a.scale(x[1],a.add(self.T[1],a.scale(-1,self.T[2])))),a.scale(x[2],a.A[0])) for x in X]
 def coefficients(self,X):
  D=self.D(X);xs=[[a.dot(d,v) for d in D] for v in self.fv];ls=[[a.dot(d[2:],e)*sg for d in D] for e,sg in zip(self.edges,self.sgn)];al=[x[0] for x in X];mu=[x[2] for x in X];gden=ip.common_den(sum(D,[])+sum(xs,[])+sum(ls,[])+al+mu);di=[[ip.convert(x,gden) for x in r] for r in D];xx=[[ip.convert(x,gden) for x in r] for r in xs];ll=[[ip.convert(x,gden) for x in r] for r in ls];aa=list(map(lambda x:ip.convert(x,gden),al));mm=list(map(lambda x:ip.convert(x,gden),mu));pos=[]
  for r in xs:
   signs=[a.sign(x) for x in r];a.require(not(1 in signs and -1 in signs),'simplex stays in one sign cell');pos.append(1 in signs)
  for r in ls:a.require(all(a.sign(x)>=0 for x in r),'positive denominator factors')
  resp=[ip.Z]*len(ip.IND[3])
  for k in range(10):
   if not pos[k]:continue
   kapp=[ip.add(ip.scale(gden,self.ai[k]),tuple(sum(ip.mul(self.bi[k][j],di[l][j])[i] for j in range(4)) for i in range(4))) for l in range(4)]
   resp=ip.sum_polys(resp,ip.product([xx[k],xx[k],kapp]))
  neg=ip.product([mm,mm,[ip.scale(-gden,self.gi)]*4]);resp=ip.sum_polys(resp,neg)
  ans=resp
  for n,L in enumerate([aa]+ll,start=3):ans=ip.mul_linear(ans,L,n)
  vol=[ip.Z]*len(ip.IND[7])
  for k in range(10):
   if not pos[k]:continue
   pi=k%5;pr=(pi-1)%5;p=ip.product([xx[k]]*4+[ll[j] for j in range(5) if j not in [pi,pr]]);p=[ip.mul(self.vi[k],x) for x in p];vol=ip.sum_polys(vol,p)
  vol=ip.mul_linear(ip.mul_linear(vol,[ip.O]*4,7),[ip.O]*4,8);ans=[ip.add(x,ip.scale(-gden*gden,y)) for x,y in zip(ans,vol)]
  self.last_denominator=self.pden*gden**9
  return ans

