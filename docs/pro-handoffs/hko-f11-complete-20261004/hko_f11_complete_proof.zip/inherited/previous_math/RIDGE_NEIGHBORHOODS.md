# Full coupled neighborhoods for all 35 primal two-faces

## Theorem R

Assume the ten-facet sharpness input (A1) in `SETUP_AND_AUDIT.md`. For every
point \(b_0\) in the relative interior of any edge of the HKO polar, there
is an actual neighborhood \(\mathcal U_{b_0}\) of \((A_0,b_0)\) such that

\[
 \rho(K(A,b))\leq\rho_0 \qquad ((A,b)\in\mathcal U_{b_0}).
\]

The old ten normals and the added normal may all move arbitrarily. The
extra inequality may be redundant. The neighborhood includes cuts entering
from neighboring polar faces and all relative scales of the motions.
After the accepted geometric normalization, a possibly smaller
neighborhood satisfies

\[
 \rho(K(A,b))/\rho_0-1\leq-c_{b_0}(r+\delta^2),
 \quad r=\|A-A_0\|,\quad
 \delta=(h_{P(A)}(b)-1)_+.                          \tag{R1}
\]

The constants may depend on \(b_0\). In particular this statement does not
assert a common radius as \(b_0\) approaches a polar vertex. The duplicate
endpoint charts remain a separate obligation.

## 1. A relative tilted-cap estimate

Fix an old codimension-two face \(F(A)\), with equations
\(a_i(A)\cdot x=a_j(A)\cdot x=1\), and fix positive
\(\lambda_1,\lambda_2\) with sum one. Write

\[
 b_*(A)=\lambda_1a_i(A)+\lambda_2a_j(A),\quad
 \eta=b-b_*(A),\quad f(z)=b\cdot z-1\quad(z\in F(A)).
\]

The face and all of its vertex labels persist because the old polytope is
simple. In a neighborhood of the fixed edge point, the support maximum of
\(b\) is attained among these vertices; therefore
\(\delta=\max_{v\in\operatorname{vert}F(A)} f(v)_+\).

Let \(N_A\) have rows \(a_i(A),a_j(A)\), and choose the orthogonal right
inverse \(T_A=N_A^T(N_AN_A^T)^{-1}\). For a point of the old polytope set

\[
 y=(1-a_i(A)\cdot x,1-a_j(A)\cdot x)\geq0,\qquad
 z'=x+T_Ay\in\operatorname{aff}F(A).
\]

For all sufficiently small \(y\geq0\), the possible \(z'\)'s form a polygon
with the same combinatorics as \(F(A)\). Indeed its inequalities are the
other old inequalities with right sides changed affinely in \(y\); each
vertex of \(F(A)\) has two additional independent active constraints, and
all its other constraints are strictly inactive. Thus its vertices move
affinely in \(y\). Triangulate \(F(A)\) by fixed vertex labels and map the
vertices to these moving vertices. The resulting piecewise-affine map
\(\Phi_{A,y}\) is a homeomorphism onto the section polygon and satisfies

\[
 \Phi_{A,y}(z)-z=O(|y|),\qquad
 D_z\Phi_{A,y}=I+O(|y|),                            \tag{R2}
\]

uniformly in \(A\). A removed point has \(|y|=O(\delta)\): the uniform
support-gap/tube argument (A6) applies to this fixed two-face, and the slacks
vanish on it. We may therefore use these coordinates on the entire cap.

In the coordinates \(x=\Phi_{A,y}(z)-T_Ay\), the crucial identity is

\[
 b\cdot x-1=f(z)-\lambda\cdot y+
       \eta\cdot(\Phi_{A,y}(z)-z-T_Ay).             \tag{R3}
\]

The last term is bounded by \(C\|\eta\||y|\), not by an absolute error
independent of \(y\). Since both \(\lambda_i\) are bounded below in this
fixed chart, removal implies

\[
 (1-C\|\eta\|)\lambda\cdot y<f(z).
\]

In particular \(f(z)>0\). Coarea supplies the factor
\(1/\|a_i(A)\wedge a_j(A)\|\); on each triangle (R2) supplies a further
factor \(1+O(|y|)\). Integrating the containing positive quadrant triangle
in \(y\) proves

\[
 \Delta V\leq
 \frac{1+C(\|\eta\|+\delta)}
      {2\lambda_1\lambda_2\|a_i(A)\wedge a_j(A)\|}
 \int_{F(A)} f(z)_+^2\,dS(z).                     \tag{R4}
\]

Extending the containing quadrant triangle beyond the actual section only
increases the upper bound. The integral formula follows from its area
\(f_+^2/[2(1-C\|\eta\|)^2\lambda_1\lambda_2]\).
This proves (R4) uniformly even if \(\delta\) is arbitrarily smaller than
\(\|b-b_0\|\), or some vertex signs change. No remainder of the form
\(O(\|b-b_0\|^3)\) is substituted for a relative error.

## 2. Square quadrature with an asymmetric sum of squares

For a nonzero-pairing polar edge, \(F(A_0)\) is an edge times an edge.
Order its four vertices as \(00,01,10,11\), using slots \(0,1,2,3\), and
triangulate along the diagonal \(0,3\). The normalized mass matrix for
piecewise-affine functions is

\[
 M=\begin{pmatrix}
 1/6&1/24&1/24&1/12\\
 1/24&1/12&0&1/24\\
 1/24&0&1/12&1/24\\
 1/12&1/24&1/24&1/6
 \end{pmatrix}.                                   \tag{R5}
\]

For any affine \(f\), let \(x_v=f(v)_+\). On each triangle, the positive
part of \(f\) is at most the affine interpolant of its nonnegative vertex
values. Squaring and integrating gives

\[
 \operatorname{avg}_{F(A_0)} f_+^2\leq x^TMx.
\]

For any vector \(u>0\), put \(d_v=(Mu)_v/u_v\). Then

\[
 \sum_v d_vx_v^2-x^TMx
 =\sum_{v<w}M_{vw}u_vu_w
       \left(\frac{x_v}{u_v}-\frac{x_w}{u_w}\right)^2\geq0.    \tag{R6}
\]

This exact identity, rather than an assertion about sampled directions,
is the quadrature certificate. For the two representative edges we use

\[
\begin{array}{c|c|c|c}
 (i,j)&\text{primal vertex indices}&u&d\\ \hline
 (0,6)&(1,2,6,7)&(1,1,1,1)&(1/3,1/6,1/6,1/3)\\
 (0,7)&(2,3,7,8)&(1,5/2,1/2,1)&(3/8,7/60,1/4,3/8).
\end{array}                                                   \tag{R7}
\]

For the moving quadrilateral use the same two labelled triangles. Their
area-weighted mass matrices differ from their values at \(A_0\) by \(O(r)\).
Since \(0\leq x_v\leq\delta\), this changes the bound by \(O(r\delta^2)\),
including sign transitions. The coarea and area factors also change by
\(O(r)\). The exact base factor, checked by the verifier, is

\[
 \frac{\operatorname{area}(F(A_0))}
      {2\|a_i\wedge a_j\|V_0}=\frac2{25}.         \tag{R8}
\]

For \(b_0=(1-s)a_i+sa_j\), with fixed \(0<s<1\), combine (R4)--(R8) to get

\[
 \frac{\Delta V}{V_0}\leq
 \frac{2/25}{s(1-s)}\sum_v d_vx_v^2
       +O((r+\|b-b_0\|+\delta)\delta^2),          \tag{R9}
\]
where \(x_v=(b\cdot v(A)-1)_+\). All constants here are uniform in the
fixed chart; their allowed dependence on \(s\) is explicit.

## 3. The exact vertex-resolved capacity certificates

A selected insertion term consists of an old seed \(k\), a pivot, a slot,
and a primal vertex \(v\). The checker establishes the affine identity

\[
 L_v(b)=2Q_0(v\cdot b-1).
\]

Let \(R(s)=R((1-s)a_i+sa_j)\). It is a polynomial of degree at most two.
For the lower half-edge the chosen term has

\[
 R(0)=0,\quad R(1)\leq0,\quad R(1/2)<0.
\]
Consequently

\[
 R(s)-4R(1/2)s(1-s)=2R(1)s(s-1/2)\geq0
             \quad(0\leq s\leq1/2).              \tag{R10}
\]
For the upper half-edge the analogous identity follows by replacing
\(s\) with \(1-s\), using \(R(1)=0\). Thus the conservative quadratic
cost is

\[
 C_k(s)=-4R_k(1/2)s(1-s)>0,\qquad
 \gamma_k=-\frac{Q_0}{2R_k(1/2)}>0.                \tag{R11}
\]

Using \(z=Q_0x_v/C_k(s)\) gives, to leading order, a relative
capacity-squared improvement
\(\gamma_k x_v^2/[s(1-s)]\). The exact expansion and feasibility in the
moving chart are dealt with below, rather than assumed here.

Each of the four data records supplies positive weights on insertion terms
and on optional pure old-seed tests. The records verify

\[
 \sum_k\lambda_k=1,\qquad
 \sum_k\lambda_kG_{\mathrm{seed}(k)}=0\in\mathbb R^{40},        \tag{R12}
\]
\[
 \sum_{k\text{ assigned to }v}\lambda_k\gamma_k\geq\theta d_v
                    \quad\text{for all four vertices}.       \tag{R13}
\]

The exact values are

\[
\begin{array}{c|c|c|c}
\text{edge}&\text{half}&\text{number of terms}&\theta\\ \hline
(0,6)&[0,1/2]&26&24/175\\
(0,6)&[1/2,1]&26&24/175\\
(0,7)&[0,1/2]&24&(1308-36\sqrt5)/14795\\
(0,7)&[1/2,1]&24&(1308-36\sqrt5)/14795.
\end{array}
\]

Both coefficients exceed \(2/25\). The exact tests use the still strict
rational thresholds \(13/100\) and \(33/400\), respectively; the smaller
certified gap above the volume coefficient is more than \(1/400\).
The four lambda lists and the branch descriptors, not rounded versions of
them, are in `data/ridge_certificates.json`.

Only the hypotheses of (R10), not numerical sampling of \(s\), are needed.
The contact identity is checked on five affine probes. The quadratic
identities are checked at three points. Degree bounds make these continuum
identities. Every stationarity and every one of the 40 cancellations is
recomputed over \(\mathbb Q(\tau)\).

## 4. Full coupling and all cut-depth scales: nonzero pairings

Fix \(s\in(0,1)\) and the corresponding half-edge certificate. Monotonicity,
(A1), and the elementary bound \(\Delta V\leq C\delta^2\) give

\[
 S(A,b)\leq-\kappa r+C\delta^2.                    \tag{R14}
\]

Choose \(D>2C/\kappa\). If \(r>D\delta^2\), (R14) is negative, and bounds
\(S\) by a negative multiple of \(r+\delta^2\). This handles old-normal
motions that are large relative to the cap scale.

It remains to consider \(r\leq D\delta^2\). For a selected term continue
its old seed by (A4), and insert the new weight \(z\) using the indicated
pivot. The identity for the objective is exactly quadratic in \(z\), with
smooth coefficients in \(A,b\). At \(A=A_0\) these are (A5). Smoothness,
the contact identity, and (R10) imply, with \(v(A)\) the labelled vertex,

\[
 Q(A,b,z)\geq Q_k(A)+2Q_0x_vz-C_k(s)z^2
                  -C(rz+\varepsilon z^2),         \tag{R15}
\]

when \(x_v>0\), where \(\varepsilon=r+\|b-b_0\|\). Indeed
\(b\cdot v(A)-b\cdot v=O(r)\). When \(x_v=0\), choose \(z=0\) and no
replacement of a negative vertex value is needed. Take
\(z=Q_0x_v/C_k(s)\). It is nonnegative and \(O(\delta)\). Bounded pivot
inverses and strictly positive base weights give simultaneous feasibility
for all selected terms on a common neighborhood. In particular no
optimizer branch with unverified nonnegative weights is being continued.

Expansion of (A3), using \(Q_k(A)=Q_0+DQ_k[H]+O(r^2)\), now gives

\[
 S(A,b)\leq G_k\cdot H+\frac{\Delta V}{V_0}
       -\frac{\gamma_k}{s(1-s)}x_v^2
       +O(r^2+r\delta+\varepsilon\delta^2+\delta^4).           \tag{R16}
\]

For a pure test omit the \(x_v^2\) term. Any base/moving positive-part
replacement has error \(O(r\delta+r^2)\), since a term is used only at a
vertex with positive moving value. This observation avoids an erroneous
\(O(r\|b-b_0\|)\) remainder when the cut depth is much smaller than the
tilt. In the current regime the remainder in (R16) is \(o(\delta^2)\)
**uniformly**, with an upper bound
\(C_D(\delta+\varepsilon)\delta^2\) after shrinking the neighborhood.

Take the positive weighted sum (R12). The true ratio is bounded above by
every test, hence by this weighted sum. All linear old-normal terms cancel.
Using (R9) and (R13) yields

\[
 S(A,b)\leq
 -\frac{\theta-2/25}{s(1-s)}\sum_vd_vx_v^2
             +o(\delta^2).                        \tag{R17}
\]

At least one \(x_v=\delta\), and every \(d_v>0\). The negative term is
therefore at most \(-c\delta^2\). Its uniform relative remainder is absorbed
on a common neighborhood. Since \(r\leq D\delta^2\), this proves (R1) in
the remaining regime too. For \(\delta=0\), monotonicity and (A1) apply
directly. No path regularity or straight-ray assumption is used.

## 5. Zero pairings: amplification rather than gradient cancellation

There are two representative zero-pairing edges, \((0,1)\) and \((0,5)\).
Their exposed faces have five and four vertices, respectively. The data
`zero_ridges.json` contain one selected insertion term for **each** vertex.
The checker establishes the contact identity and

\[
 R((1-s)a_i+sa_j)\equiv0\quad\text{for every selected term}.    \tag{R18}
\]

Fix an interior point \(b_0\) of either edge. Set
\(e=\|b-b_0\|\), \(\delta_0=(h_{P_0}(b)-1)_+\). If \(e>0\), then
\(\delta_0\leq Ce\). For a maximizing vertex in the exposed face, use its
zero-cost term and choose

\[
 z=\mu\delta_0/e.
\]

Since \(R(b)=O(e)\), a sufficiently small fixed \(\mu>0\) makes all old
weights positive and yields

\[
 Q(b,z)-Q_0\geq a\delta_0^2/e.                    \tag{R19}
\]

The new weight is bounded by a small constant; it need not tend to zero.
This is legitimate because (R18) gives a flat feasible family at the base.
The gain in (R19) is \(O(e)\), so the quadratic error in converting it to a
ratio bound is absorbed. The cap volume is \(O(\delta_0^2)\), also absorbed
for sufficiently small \(e\). Thus

\[
 S(A_0,b)\leq-a'\delta_0^2/e.
\]

To couple the old normals, use **the fixed depth \(\delta_0\)** in this
quotient. Replacing it by the moving depth divided by \(e\) without a scale
check would be invalid. Lipschitz comparison at the same \(b\) gives

\[
 S(A,b)\leq Lr-a'\delta_0^2/e.                    \tag{R20}
\]

The moving depth satisfies \(\delta\leq\delta_0+Cr\), so monotonicity,
(A1), and the two-face tube bound give

\[
 S(A,b)\leq-\kappa r+C\delta_0^2+Cr^2.             \tag{R21}
\]

Multiply (R21) by \(L+\kappa\), (R20) by \(\kappa\), and add. The positive
terms are absorbed by shrinking \(e\) and \(r\), giving

\[
 S(A,b)\leq-c r-c\delta_0^2/e.                    \tag{R22}
\]

This covers all \(r/e\) ratios. At \(e=0\), use (R21) with
\(\delta_0=0\) instead; it is negative for small positive \(r\).
Finally \(\delta^2\leq2\delta_0^2+Cr^2\) shows that (R22) implies the
weaker but convenient bound (R1). This proves the entire zero-pairing
neighborhood, not only its radial subfamily.

## 6. Coverage and scope

The simultaneous pentagon rotation and the symplectic swap
\((q,p)\mapsto(J_2p,-J_2q)\) preserve \(P_0\). On normal indices they act
by adding one modulo five in each group, and by interchanging the groups.
The orbits of \((0,6)\) and \((0,7)\) are disjoint sets of ten nonzero-pairing
edges. The orbits of \((0,1)\) and \((0,5)\) give the other fifteen edges.
The checker reconstructs the incidences and verifies all these statements,
including symplecticity, over the exact field.

Sections 1--5 therefore prove Theorem R at every point in the relative
interior of all 35 polar edges. Radii may be chosen uniformly on any compact
subinterval of an edge by the displayed estimates. Nothing here replaces
the distinct duplicate-normal analysis needed when the edge parameter
approaches zero or one together with the perturbation. See `BLOCKER.md`.
