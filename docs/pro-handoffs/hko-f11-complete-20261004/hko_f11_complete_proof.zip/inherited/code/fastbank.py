from explore import *
from scipy.optimize._highspy import _core as hc
from scipy.sparse import csc_matrix
class FastBank(Bank):
    def __init__(self,rows,G,C):
        super().__init__(rows,G,C)
        h=hc._Highs(); h.setOptionValue('output_flag',False)
        h.setOptionValue('threads',1)
        h.setOptionValue('primal_feasibility_tolerance',1e-9)
        h.setOptionValue('dual_feasibility_tolerance',1e-9)
        lp=hc.HighsLp();lp.num_col_=len(G);lp.num_row_=len(self.rhs)
        lp.col_cost_=np.zeros(len(G));lp.col_lower_=np.zeros(len(G));lp.col_upper_=np.full(len(G),hc.kHighsInf)
        lp.row_lower_=self.rhs;lp.row_upper_=self.rhs
        a=csc_matrix(self.eq)
        lp.a_matrix_.format_=hc.MatrixFormat.kColwise
        lp.a_matrix_.num_col_=a.shape[1];lp.a_matrix_.num_row_=a.shape[0]
        lp.a_matrix_.start_=a.indptr;lp.a_matrix_.index_=a.indices;lp.a_matrix_.value_=a.data
        h.passModel(lp);self.h=h;self.cols=np.arange(len(G),dtype=np.int32)
    def support(self,D):
        self.h.changeColsCost(len(self.cols),self.cols,-self.C@D)
        self.h.run()
        if self.h.getModelStatus()!=hc.HighsModelStatus.kOptimal:raise ValueError(str(self.h.getModelStatus()))
        sol=self.h.getSolution();self.dual=np.array(sol.row_dual)
        return -self.h.getObjectiveValue(),np.array(sol.col_value)

if __name__=='__main__':
    tic=time.perf_counter();data=np.load(str(WORK/'enriched.npz'));b=FastBank(None,data['G'],data['C'])
    rng=np.random.default_rng(20260924);ds=rng.normal(size=(400,4));ds/=np.linalg.norm(ds,axis=1)[:,None]
    ans=[]
    for d in ds:
        vv=FV@d;mu=max(vv)/(max(vv)-min(vv))
        if not 0<mu<1:continue
        g,s,l=b.gap(d)
        ans.append(dict(D=d.tolist(),mu=mu,gap=g,volume=vol(d),support=s))
    ans.sort(key=lambda r:r['gap'])
    print('n',len(ans),'negative',sum(r['gap']<-1e-8 for r in ans),'worst',ans[:4],'seconds',time.perf_counter()-tic)
    json.dump(ans,open(str(WORK/'broad_scan.json'),'w'),indent=2)
