# Why a finite bank cannot give global zonoid containment

## Theorem B

Consider any **finite** bank of the stationary, positive-on-used-support,
rank-five touching sections used in the assignment, at the duplicate
\(a_{10}=a_0\). Let \(G_k,c_k\) be its aggregate old gradients and duplicate
covectors. Its cancellation body

\[
 C_{\rm bank}=\left\{\sum_k\lambda_k c_k:
 \lambda\geq0,\ \sum_k\lambda_k=1,\ \sum_k\lambda_kG_k=0\right\}
\]

cannot contain the positive-part volume zonoid \(Z\) of the facet \(F_H\).
If the cancellation set is empty, the conclusion is immediate. Otherwise
there are genuinely sign-changing directions \(D\) with

\[
 h_{C_{\rm bank}}(D)\leq0<h_Z(D)=v(D).
\]

This is a limitation of finite global containment by such positive sections,
**not** a counterexample to local maximality. It does not preclude a finite
cover of an interior angular compact set, a continuous bank, an endpoint
insertion argument, or a different geometric method.

## 1. The duplicate response is a positive segment-midpoint moment

Write \(J(q,p)=(p,-q)\), so \(\omega(x,y)=x^TJy\). For a touching word,
let \(u_r=\sum_{j<r}\beta_j a_{\sigma_j}\) be the prefix. Rank-five
stationarity gives a unique multiplier \((\ell,\ell_5)\) with
\(\nabla_\beta Q=C^T(\ell,\ell_5)\). Euler's identity and closure give
\(\ell_5=2Q_H\). Set

\[
 x_r=\frac{-2Ju_r-\ell}{2Q_H}.
\]

Inserting a velocity \(b\) at this slot, and correcting a fixed invertible
five-column pivot, has first weight derivative

\[
 L_r(b)=2Q_H(b\cdot x_r-1).                               \tag{B1}
\]

All old weights are positive, so this insertion is feasible for sufficiently
small positive inserted weight. Apply it at the base body with \(b=a_j\),
for each old normal. Its objective cannot exceed \(Q_H\), by the polar-loop
principle and the known value of \(c_H\). Hence \(L_r(a_j)\leq0\), and
\(x_r\in H\). This argument permits repeated velocities; it is not restricted
to words of eleven distinct geometric normals.

Stationarity for the original row \(a_{\sigma_r}\) gives
\(a_{\sigma_r}\cdot x_r=1\). The next point is

\[
 x_{r+1}=x_r-\frac{\beta_r}{Q_H}Ja_{\sigma_r},
\]

and also lies in \(H\). Thus, when \(\sigma_r=10\), these are distinct
points of \(F_H\). Differentiating the objective with respect to that normal,
including the differentiated closure equations, gives

\[
 (g_Q)_{10}
 =\beta_r\{J(-2u_r-\beta_ra_0)-\ell\}
 =2Q_H\beta_r\frac{x_r+x_{r+1}}2.
\]

Consequently

\[
 c_k=4\beta_{10}\,\frac{x_r+x_{r+1}}2,
 \qquad a_0\cdot c_k=4\beta_{10}>0.                      \tag{B2}
\]

An unused duplicate has \(c_k=0\). In particular an active duplicate response
cannot point along an exposed vertex ray of \(F_H\): the midpoint of a
nonconstant segment in a convex polytope is not one of its vertices.

## 2. A finite activation threshold leaves a genuine cap uncovered

Choose a facet vertex \(v\) and a linear form \(D_0\) that has unique maximum
zero on \(F_H\), at \(v\). For every active section, (B2) gives
\(D_0\cdot c_k<0\). There are only finitely many such sections, so

\[
 \epsilon_*=
 \min_{k:\beta_{10}>0}\frac{-D_0\cdot c_k}{a_0\cdot c_k}>0
\]

when any are active. If none are active, all responses vanish and any small
positive choice below serves instead. For \(0<\epsilon<\epsilon_*\), put
\(D_\epsilon=D_0+\epsilon a_0\). Every bank response satisfies
\(c_k\cdot D_\epsilon\leq0\), so every cancellation point does too.
But \(D_\epsilon\cdot v=\epsilon>0\), and this remains positive on a
positive-measure part of the facet. For sufficiently small \(\epsilon\)
other facet points retain negative values. Hence
\(v(D_\epsilon)>0\), and the claimed separation follows. \(\square\)

This explains why adding a fixed finite number of positive split weights
cannot close the redundant-limit boundary, regardless of how those weights
were discovered. Theorem E closes that boundary by inserted weights tending
to zero at the cap-dependent scale instead.

## 3. An exact witness for the supplied 147-section bank

Take the primal facet vertex \(v_3=(U_0,W_3)\) and

\[
 D_0=a_4+a_7+a_8-3a_0,\qquad D=D_0+\tfrac1{10}a_0.
\]

On \(F_H\), \(D_0\) is the sum of three nonpositive old slacks and vanishes
only at \(v_3\). Its minimum is \(-5\); therefore \(D\) is genuinely
sign-changing, has oscillation 5, and normalized split parameter \(\mu=1/50\).

The exact checker regenerates all 147 sections from the supplied seeds and
sector terms, verifies their constraints and stationarity, and checks every
response. There are 60 active-duplicate and 87 unused-duplicate sections.
The minimum active threshold is exactly

\[
 \epsilon_*=(5-\sqrt5)/8>1/10.
\]

Every active \(c_k\cdot D\) is strictly negative; every unused response is
zero. Exact integration gives

\[
 h_{C_{\rm bank}}(D)\leq0,
 \qquad v(D)=\frac{3+\sqrt5}{15\,000\,000}>0.               \tag{B3}
\]

Only the upper bound on the bank support is asserted by the exact checker;
no additional primal cancellation relation is needed for this separation.
The evidence file contains the unreduced algebraic coefficients and the
largest active response. The numerical continuous-weight experiment repairs
this same failure, obtaining a positive surrogate margin about
\(1.762876\times10^{-4}\) for its larger family bank. That last number is
numerical evidence, not a capacity lower bound and not a global certificate.
