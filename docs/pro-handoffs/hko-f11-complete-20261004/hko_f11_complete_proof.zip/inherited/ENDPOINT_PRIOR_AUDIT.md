# Review of the surviving end-to-end F<=11 return

## Decision summary

The full eleven-facet theorem is still open in the surviving work. The first-return archive is intact and executable. I found no substantive gap in its two new mathematical arguments: exclusion of all redundant-limit sequences, conditional on the accepted ten-facet sharpness theorem and the checked contact/ridge inputs; and impossibility of global containment by a fixed finite bank of the stated positive stationary touching sections.

The second-turn continuation ZIP is not present. Its claimed exhaustive-family classification and any continuation logs therefore have not been reviewed. This does not block resuming the sufficient-upper-bound argument: the first return already contains all 710 verified families and the replayable numerical witnesses, and their completeness is not a prerequisite for a positive proof.

The appropriate unresolved target is a universal *strict* interior comparison, or a treatment of every interior equality case. A weak first-order inequality alone does not finish the theorem. No new Pro call is authorized or scheduled by this review.

## Inputs and checks

The source is `input/turn1_return.zip`, retained byte-for-byte. Its 54 manifest entries matched. The source contains 55 archive members, including the manifest.

Fresh reruns in this review:

| Check | Outcome | Recorded internal seconds |
|---|---|---:|
| Inherited finite ridge/sector checker | PASS | 3.536 |
| New endpoint identities and explicit bank obstruction | PASS | 6.461 |
| Reconstruction and exact checking of all 710 stored weight families | PASS | 10.604 |
| Both deliberate corruptions | Detected | See logs |
| Separately implemented explicit-obstruction calculation | PASS | 1.717 |
| Replayed continuous optimization at all 23 retained directions | Positive numerical margins | 14.717 |

The new implementation imports no submitted module. It uses SymPy's algebraic number field rather than the return's custom field arithmetic. It reconstructs the normal geometry, checks the 147 positive touching sections and 947 loop-node incidences, checks the midpoint response identity and the exact separating direction, and integrates the facet volume by nine tetrahedra and confluent divided differences rather than the submitted Fubini formula. All acceptance comparisons in that checker are exact.

This independence is limited to those finite checks. I did not independently reimplement all 710 family calculations or discover the witnesses independently. I read the analytic endpoint argument and replayed its finite premises. This is not an external referee report, proof-assistant formalization, or novelty assessment.

The numerical replay had minimum final primal margin 0.00017628759802569045, maximum full cancellation residual about 6.99e-12, maximum selected pivot condition about 5.706, and a minimum displayed weight coordinate of -2.78e-17. Some final pricing residuals were still positive (up to about 6.24e-6). These are numerical witnesses, not exact cancellation certificates or a universal direction cover. A positive feasible primal lower estimate does not require solving pricing optimally, but floating-point feasibility must still be certified before theorem use.

The reruns reproduce the already reported 23 successful directions. They do not add new directional coverage.

## Review of Theorem E: uniform redundant-limit control

The normalized split has

    A=A_H+H, r=||H||, b=a_0(A)+d,
    m_+=max_F d.x, m_-=-min_F d.x,
    t=m_++m_-, D=d/t, mu=m_+/t.

For genuine splits m_+,m_->0. The theorem establishes an epsilon>0 and eta>0 such that r+||d||<epsilon and min(mu,1-mu)<eta imply rho(K)<=rho_H. It does not supply explicit values of these constants.

The key proof steps are present:

1. The removed-volume estimate retains the positive cap profile as a factor, rather than using an absolute O(t^2) error.
2. On an improving sequence, the ten-facet linear deficit implies r<=C Delta V.
3. For mu->0, a limiting direction exposes a proper face E of the original three-dimensional facet. Its dimension k is 0, 1 or 2. The positive set is in an O(mu)-tube around E, giving Delta V=O(t mu^(4-k)).
4. For k<=1, a flat endpoint insertion of weight alpha mu gains order t mu^2. Both the volume loss and admissible old-normal error are smaller order. This does not require a cancellation relation.
5. For k=2 the proof rescales the exact ridge certificates with s~t and actual cap depth delta=t mu. It explicitly controls e/s, delta/s and r/s. Both the useful gain and the removed-volume term have scale delta^2/s; the checked coefficient gap has the correct sign.
6. For zero-pairing faces, a fixed sufficiently large multiplier B in the weight B delta/s beats the old-normal and volume constants; the weight still tends to zero. The order of choosing B and shrinking the neighborhood is correct.
7. Duplicate interchange reduces mu->1 to mu->0, with the whole old presentation renormalized. A contradiction-sequence argument then establishes one collar and one neighborhood, without pretending the old open-edge radii were uniform.

The delicate error calculation in the nonzero-pairing case is valid: dividing the displayed errors by delta^2/s gives terms tending to zero under r=O(delta^2/s), delta/s->0 and e/s->0. No free-standing O(t^2) error is silently discarded.

The standard symplectic input permitting repeated/redundant velocities is Haim-Kislev's polar-loop formula, Remark 1.4. The original reference was checked during this review:
https://arxiv.org/html/1712.03494v3

## The finite-bank obstruction is real and changes the proposed method

For a positive stationary touching section, an active duplicate response has

    c=4 beta_new m,

where m is the midpoint of a nonconstant characteristic segment inside the original facet. In particular m is not an exposed vertex of that facet.

Choose D_0 with unique maximum zero at a facet vertex v. Every active fixed response then satisfies c.D_0<0. In a finite bank their activation thresholds have a positive minimum. For D=D_0+epsilon a_0 with epsilon sufficiently small, all bank responses remain nonpositive, yet the volume response integral of (D.x)_+ is strictly positive near v. Thus no such finite bank contains the whole volume zonoid.

The returned explicit example is

    D=a_4+a_7+a_8-(29/10)a_0.

The independent check gives all 60 active responses strictly negative, all 87 unused responses zero, minimum activation threshold (5-sqrt(5))/8, and

    v(D)=(3+sqrt(5))/15000000 > 0.

This refutes the earlier suggestion that a sufficiently large fixed positive-section bank might supply *global* zonoid containment. It is not just a failure of the original 147 choices. The suggestion should be withdrawn in that form.

It does not rule out a finite bank on a compact set separated from redundant directions. Nor does it rule out a continuously parameterized collection of sections, whose inserted weights can tend to zero. Theorem E removes the need to use the failed finite-bank method in its endpoint regimes.

## Exact remaining condition and why it now suffices

For a positive feasible touching section k, write its aggregate old-normal gradient as G_k and its duplicate covector as c_k. With normalized split direction D,

    S <= G_k.H + t(v(D)-c_k.D) + O((r+t)^2),
    S=rho/rho_H-1.

It is sufficient to establish, for every genuinely sign-changing limiting D, finitely many valid sections and weights such that

    lambda_k>=0, sum lambda_k=1,
    sum lambda_k G_k=0,
    (sum lambda_k c_k).D > v(D).

The sections and their weights may depend on D. They need not enumerate all minimizers.

Here is the complete closing implication. If the full theorem failed, the completed strata and Theorem E would leave an improving sequence with r_n=O(t_n), D_n->D, and D genuinely sign-changing. Select a strict finite certificate for this one limiting D. Positivity and rank of its fixed sections provide a common local feasibility radius; continuity keeps its support margin positive for D_n. Average the upper bounds. The old-normal linear terms vanish exactly, and the remainder is O(t_n^2). Thus S_n<=-m t_n/2+O(t_n^2)<0, contradiction.

No explicit endpoint collar size and no global enumeration of all minimum words are needed for this implication. But the strict certificate must be proved for *every* possible interior limiting D. Tests at finitely many directions do not provide that quantifier.

The displayed weak inequality h_C(D)>=v(D) in the second-turn message is not, on its own, a sufficient closing condition. If equality occurs at an interior direction, the remaining higher-order problem must be solved there.

## What not to spend resources on next

- Do not try to recover the expired ZIP just to regain the continuous data: they are in the surviving source.
- Do not make exhaustive classification of all 710 families a prerequisite for the sufficient-bound route. Such a classification could be useful for proving inadequacy or for actual capacity derivatives, but is not required to prove the desired upper bound.
- Do not repeat a broad end-to-end Pro prompt merely to regain an execution environment. This archive replays in an ordinary observable Python process.
- Do not call 23 successful repairs a direction cover, or call the exact family reconstruction a capacity lower bound.
- Do not treat cheap replays as an estimate of the remaining proof-development time. The costs of model reasoning, researcher attention, and unsuccessful unlogged approaches remain unmeasured.

A further research allocation should be justified by a concrete universal-interior certificate strategy or a reproducible obstruction to it, rather than by another bank-size increase. One possible analytic route uses the continuous family parameters to construct cancellation relations depending on D. One finite route is an exact cell cover of a rigorously specified compact interior region, combined with a valid endpoint collar. Neither has been completed here.

## Operational status

No repository files were changed. No Pro session or external job was launched. The second continuation's execution failure cannot be diagnosed from the absent archive; it is reported history, not verified tool telemetry. The current first return and all the checks reported here are observable and preserved.
