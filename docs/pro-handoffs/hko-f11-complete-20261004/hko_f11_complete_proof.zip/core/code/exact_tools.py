"""Exact response and direction-cover tools; all acceptance signs use Q(tau)."""
import sys,itertools,json,time
from fractions import Fraction as F
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import exact_core as a
from duplicate_workspace import encoded,volume_response
ZERO=a.ZERO;ONE=a.ONE;A=a.A+[a.A[0]]

def calc_exact(sig,be,pivot=None,check=True):
 a.require(len(set(sig))==len(sig) and all(isinstance(i,int) and 0<=i<11 for i in sig),'distinct valid normal labels')
 m=len(sig);aa=[A[i] for i in sig];C=[[x[c] for x in aa] for c in range(4)]+[[ONE]*m]
 if pivot is None:
  for inds in itertools.combinations(range(m),5):
   try:ci=a.inv([[r[j] for j in inds] for r in C]);pivot=list(inds);break
   except ArithmeticError:continue
  else:raise ValueError('no rank5 pivot')
 else:ci=a.inv([[r[j] for j in pivot] for r in C])
 if check:
  a.require(all(a.sign(b)>0 for b in be),'positive interior weights')
  a.require(a.mv(C,be)==[ZERO]*4+[ONE],'constraints')
  a.require(a.qeval(A,sig,be)==a.Q0,'touching')
 H=[[ZERO if i==j else a.omega(aa[min(i,j)],aa[max(i,j)]) for j in range(m)] for i in range(m)]
 gb=a.mv(H,be)
 ell=a.mv(list(map(list,zip(*ci))),[gb[j] for j in pivot])
 if check:a.require(a.mv(list(map(list,zip(*C))),ell)==gb,'stationarity')
 prefix=[ZERO]*4;gq=[[ZERO]*4 for i in range(11)]
 for label,al,beta in zip(sig,aa,be):
  ve=a.add(a.scale(2,prefix),a.scale(beta,al))
  explicit=[-ve[2],-ve[3],ve[0],ve[1]] # omega(ve,e_c)
  gq[label]=a.scale(beta,[explicit[c]-ell[c] for c in range(4)])
  prefix=a.add(prefix,a.scale(beta,al))
 c=a.scale(2/a.Q0,gq[10]);agg=[r[:] for r in gq[:10]];agg[0]=a.add(agg[0],gq[10])
 G=[-2*x/a.Q0-a.VOL_GRAD[j]/a.V0 for j,x in enumerate(sum(agg,[]))]
 return G,c,pivot

def hull2(points):
 from functools import cmp_to_key
 def cmp(x,y):
  s=a.sign(x[0]-y[0]);return s if s else a.sign(x[1]-y[1])
 ps=sorted({tuple(p) for p in points},key=cmp_to_key(cmp))
 def cross(p,q,r):return a.det2([q[k]-p[k] for k in range(2)],[r[k]-p[k] for k in range(2)])
 lo=[]
 for p in ps:
  while len(lo)>1 and a.sign(cross(lo[-2],lo[-1],p))<=0:lo.pop()
  lo.append(p)
 up=[]
 for p in ps[::-1]:
  while len(up)>1 and a.sign(cross(up[-2],up[-1],p))<=0:up.pop()
  up.append(p)
 return [list(p) for p in lo[:-1]+up[:-1]]

def exact_prisms(eta):
 dif=hull2([[p[c]-q[c] for c in range(2)] for p in a.W for q in a.W]);pp=hull2([a.mv(a.inv([dif[i],dif[(i+1)%len(dif)]]),[ONE,ONE]) for i in range(len(dif))]);assert len(pp)==10
 qm=a.scale(a.K(F(1,2)),a.add(a.U[0],a.U[1]));qd=a.add(a.U[1],a.scale(-1,a.U[0]));qinv=a.inv([qd,qm]);out=[]
 for sign in [-1,1]:
  for i in range(len(pp)):
   ts=[(a.K(sign),[ZERO,ZERO]),(ZERO,pp[i]),(ZERO,pp[(i+1)%len(pp)])];vs=[]
   for mu in [eta,ONE-eta]:
    for x,w in ts:
     mx=a.dot(a.W[0],w)
     for p in a.W[1:]:
      v=a.dot(p,w)
      if a.sign(v-mx)>0:mx=v
     q=a.mv(qinv,[x,mu-a.K(a.sign(x))*x/2-mx]);vs.append(q+w)
   out.extend([[vs[j] for j in ix] for ix in [[0,1,2,5],[0,1,4,5],[0,3,4,5]]])
 return out

