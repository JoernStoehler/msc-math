import sys,json,time,argparse
from pathlib import Path
import numpy as np
from scipy.sparse import lil_matrix
from scipy.optimize import linprog
from scipy.linalg import qr
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'inherited/code'))
from explore import *
from continuous import families
from policy_paths import build_paths
from directions import prisms
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args();args.out.parent.mkdir(parents=True,exist_ok=True);assert not args.out.exists(), 'Use a fresh output path'
 tic=time.perf_counter();eta=.1;fs=families();paths=build_paths(fs,fractions=(.125,.25,.5,1.));nn=len(paths);old=json.load(open(ROOT/'data/seeds.json'));G=np.array([calc(r['sigma'],[VALUES[x] for x in r['weights']])[0] for r in old]);m=len(G)
 EE=np.vstack([np.ones(m),G.T]);_,R,ix=qr(EE.T,pivoting=True,mode='economic');ix=sorted(ix[:26]);E=EE[ix];rhs0=np.r_[1.,np.zeros(40)][ix]
 nz=31*m;N=nz+nn+1;eq=lil_matrix((21*26,N));eq[:26,:m]=E;rhs=np.zeros(21*26);rhs[:26]=rhs0
 for v in range(10):
  ia=m*(1+3*v);ib=ia+m;ic=ib+m
  eq[:26,ia:ia+m]=E
  eq[(1+2*v)*26:(2+2*v)*26,ia:ia+m]=-2*E;eq[(1+2*v)*26:(2+2*v)*26,ib:ib+m]=2*E
  eq[(2+2*v)*26:(3+2*v)*26,ia:ia+m]=E;eq[(2+2*v)*26:(3+2*v)*26,ib:ib+m]=-2*E;eq[(2+2*v)*26:(3+2*v)*26,ic:ic+m]=E
 for k,p in enumerate(paths):
  b0,b1,b2=p['G'];coeff=[b0,2*(b1-b0),b0-2*b1+b2];v=p['vertex'];eq[:26,nz+k]=np.r_[1.,coeff[0]][ix,None]
  eq[(1+2*v)*26:(2+2*v)*26,nz+k]=np.r_[0.,coeff[1]][ix,None]
  eq[(2+2*v)*26:(3+2*v)*26,nz+k]=np.r_[0.,coeff[2]][ix,None]
 eq=eq.tocsc();obj=np.zeros(N);obj[-1]=-1
 print('built',N,'variables',time.perf_counter()-tic,flush=True)
 rng=np.random.default_rng(87125);tris=[t[:3]-.1*A[0] for t in prisms(.1)[::3]];out=[]
 for j,T in enumerate(tris):
  start=time.perf_counter();tilts=[*T,*[(T[i]+T[(i+1)%3])/2 for i in range(3)],T.mean(axis=0)]
  tilts.extend(rng.dirichlet([.4,.4,.4],80)@T)
  ds=np.array([d+mu*A[0] for d in tilts for mu in [.0005,.003,.015,.05,.1]])
  mu=np.max(FV@ds.T,axis=0);vresp=np.array([vol(d) for d in ds])/mu**2;depth=np.maximum(0,ds@FV.T)/mu[:,None]
  coef=np.empty((len(ds),nn))
  for k,p in enumerate(paths):coef[:,k]=depth[:,p['vertex']]**2*(p['C1']@A[0]/eta+(ds@p['C2'])/eta**2)
  ub=lil_matrix((len(ds),N));ub[:,nz:nz+nn]=-coef;ub[:,-1]=1
  sol=linprog(obj,A_eq=eq,b_eq=rhs,A_ub=ub.tocsc(),b_ub=-vresp,bounds=[(0,None)]*(N-1)+[(None,None)],method='highs',options={'time_limit':12})
  rr=dict(cone=j,success=sol.success,message=sol.message,seconds=time.perf_counter()-start)
  if sol.success:
   w=sol.x[nz:nz+nn];rr.update(margin=float(sol.x[-1]),old_bernstein=sol.x[:nz].reshape(31,m).tolist(),paths=[dict(family=p['family'],start_vertex=p['start_vertex'],fraction=p['fraction'],vertex=p['vertex'],weight=float(a)) for p,a in zip(paths,w) if a>1e-9],eq_residual=float(max(abs(eq@sol.x-rhs))))
  out.append(rr);print(j,rr['success'],rr.get('margin'),rr['seconds'],flush=True)
  json.dump(dict(status='NUMERICAL SAMPLES ONLY',eta=eta,seconds=time.perf_counter()-tic,results=out),open(args.out,'w'),indent=2)
if __name__=='__main__':main()
