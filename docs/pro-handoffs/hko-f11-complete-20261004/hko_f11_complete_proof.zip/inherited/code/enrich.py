from explore import *
from scipy.linalg import null_space

def canon(sig,be):
    # Cyclic rotation preserves Q when closure holds.
    ii=int(np.argmin(sig));sig=sig[ii:]+sig[:ii];be=list(be[ii:])+list(be[:ii]);
    return sig,be

def key(sig,be):
    s,b=canon(list(sig),list(be));return (tuple(s),tuple(np.round(b,11)))

def seedrows():
    return [dict(sigma=r['sigma'],be=[VALUES[x] for x in r['weights']],origin=f'seed_{i}') for i,r in enumerate(json.load(open(ROOT/'data/seeds.json')))]

def flat_insertions(row,labels=range(10),fractions=(.5,),endpoints=True):
    sig=row['sigma'];be=np.array(row['be']);m=len(sig);aa=A11[sig];G,c,nodes,H,C=calc(sig,be)
    invs=[]
    for inds in itertools.combinations(range(m),5):
        cc=C[:,inds]
        if abs(np.linalg.det(cc))>1e-8:invs.append((inds,np.linalg.inv(cc)))
    new=[]
    for label in labels:
        if label in sig:continue
        normal=A11[label]
        for pos in range(m):
            if abs(nodes[pos]@normal-1)>1e-8:continue
            ss=sig[:pos]+[label]+sig[pos:];aaa=A11[ss]
            mm=aaa@J@aaa.T;hh=np.triu(mm,1);hh+=hh.T
            for inds,inv in invs:
                h=np.zeros(m);h[list(inds)]=-inv@np.r_[normal,1]
                hv=np.insert(h,pos,1)
                R=hv@hh@hv/2
                if abs(R)>1e-8:continue
                if min(h)>=-1e-10:continue
                zm=min(-be[h<-1e-10]/h[h<-1e-10]);
                fs=list(fractions)+([1.] if endpoints else [])
                for f in fs:
                    z=zm*f;newbe=np.insert(be+z*h,pos,z);idx=np.where(newbe>1e-9)[0]
                    ns=[ss[i] for i in idx];nb=newbe[idx];ns,nb=canon(ns,nb)
                    new.append(dict(sigma=ns,be=nb,origin=dict(parent=row.get('origin'),label=label,pos=pos,pivot=list(inds),fraction=f)))
    return new

def duplicate_rows(row,fractions=(.25,.5,.75)):
    # Feasible flat duplications with arbitrary five-column pivot; returns old unused + replaced too.
    out=[row]
    ss=[10 if i==0 else i for i in row['sigma']];out.append(dict(sigma=ss,be=row['be'],origin={'swap':row.get('origin')}))
    out.extend(flat_insertions(row,labels=[10],fractions=fractions,endpoints=True))
    return out

def make_bank(old,fracs=(.25,.5,.75)):
    allrows={}
    for r in old:
        for rr in duplicate_rows(r,fracs):allrows[key(rr['sigma'],rr['be'])]=rr
    G=[];C=[];rows=list(allrows.values())
    for rr in rows:
        g,c,*_=calc(rr['sigma'],rr['be']);G.append(g);C.append(c)
    return rows,np.array(G),np.array(C)

if __name__=='__main__':
    tic=time.perf_counter();old=seedrows();allold={key(r['sigma'],r['be']):r for r in old}
    for r in old:
        for rr in flat_insertions(r,fractions=(.25,.5,.75)):
            allold[key(rr['sigma'],rr['be'])]=rr
    print('old count',len(allold),'seconds',time.perf_counter()-tic,flush=True)
    rows,G,C=make_bank(list(allold.values()))
    print('duplicate count',len(rows),'seconds',time.perf_counter()-tic,flush=True)
    np.savez(str(WORK/'enriched.npz'),G=G,C=C)
    json.dump(dict(old=list(allold.values()),rows=rows),open(str(WORK/'enriched.json'),'w'))
    bank=Bank(rows,G,C)
    scan=json.load(open(str(WORK/'starting_scan.json')));ans=[]
    for r in scan:
        d=np.array(r['D']);gap,s,l=bank.gap(d)
        ans.append(dict(D=d.tolist(),gap=gap,support=s,volume=vol(d)))
    ans.sort(key=lambda r:r['gap']);print('tested',len(ans),'negative',sum(r['gap']<-1e-7 for r in ans),'worst',ans[0],flush=True)
    print('seconds',time.perf_counter()-tic,flush=True)
    json.dump(ans,open(str(WORK/'enriched_scan.json'),'w'),indent=2)
