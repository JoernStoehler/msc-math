#!/usr/bin/env python3
"""Copy retained numerical discovery inputs to a scratch workspace.
Set HKO_WORK to select the destination. Does not overwrite packaged evidence.
"""
import os,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1];work=Path(os.environ.get('HKO_WORK',str(root/'work')));work.mkdir(parents=True,exist_ok=True)
for src,name in [(root/'data/numerical_bank.npz','enriched.npz'),(root/'data/numerical_bank_rows.json','enriched.json'),(root/'evidence/hull_state.json','hull_state.json')]:
 dst=work/name
 if dst.exists():raise FileExistsError(str(dst))
 shutil.copyfile(src,dst)
print('Prepared retained numerical inputs in',work)
