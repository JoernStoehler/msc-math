import sys, json, time, itertools
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from scipy.linalg import qr
from scipy.spatial import ConvexHull
ROOT=Path(__file__).resolve().parents[1]
import os
WORK=Path(os.environ.get('HKO_WORK',str(ROOT/'work')))
WORK.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'code'))
import exact_core as ex
A=np.array([[ex.nominal(x) for x in r] for r in ex.A]); A11=np.vstack([A,A[0]])
U=np.array([[ex.nominal(x) for x in r] for r in ex.U]); W=np.array([[ex.nominal(x) for x in r] for r in ex.W]);FV=np.array([np.r_[q,p] for q in U[:2] for p in W]);
Q0=ex.nominal(ex.Q0);V0=ex.nominal(ex.V0);VG=np.array([ex.nominal(x) for x in ex.VOL_GRAD])/V0
J=np.array([[0,0,1,0],[0,0,0,1],[-1,0,0,0],[0,-1,0,0]])
AREA=ex.nominal(ex.area(ex.W))
VALUES={k:ex.nominal(v) for k,v in ex.VALUES.items()}

def calc(sig,beta,normals=A11,check=True):
    aa=normals[sig]; n=len(sig); beta=np.array(beta)
    mat=aa@J@aa.T
    H=np.triu(mat,1); H=H+H.T
    C=np.vstack([aa.T,np.ones(n)])
    gb=H@beta
    ell=np.linalg.lstsq(C.T,gb,rcond=1e-12)[0]
    if check:
        assert np.max(np.abs(C@beta-np.r_[np.zeros(4),1]))<1e-8
        assert np.max(np.abs(gb-C.T@ell))<1e-8
        assert abs(beta@gb/2-Q0)<1e-8
    prefix=np.cumsum(aa*beta[:,None],axis=0)-aa*beta[:,None]
    g=beta[:,None]*((-2*prefix-aa*beta[:,None])@J.T-ell[:4])
    gq=np.zeros_like(normals)
    for i,label in enumerate(sig):gq[label]+=g[i]
    agg=gq[:10].copy()
    if len(normals)>10:agg[0]+=gq[10]
    G=-2*agg.reshape(-1)/Q0-VG
    c=2*gq[10]/Q0 if len(normals)>10 else np.zeros(4)
    nodes=(-2*prefix@J.T-ell[:4])/(2*Q0)
    return G,c,nodes,H,C

def clip_moment(c,dp,power):
    vals=c+W@dp;out=[]
    for i,p in enumerate(W):
        q=W[(i+1)%5];fp=vals[i];fq=vals[(i+1)%5]
        if fp>=0:out.append(p)
        if (fp>=0)!=(fq>=0):out.append(p+(q-p)*fp/(fp-fq))
    tot=0.
    for i in range(1,len(out)-1):
        tri=np.array([out[0],out[i],out[i+1]])
        u=tri[1]-tri[0];v=tri[2]-tri[0];area=(u[0]*v[1]-u[1]*v[0])/2
        ff=c+tri@dp
        mean=ff.sum()/3 if power==1 else ((ff.sum())**2+ff@ff)/12
        tot+=area*mean
    return tot

def vol(D):
    c0,c1=U[:2]@D[:2]
    if abs(c1-c0)<1e-8*np.linalg.norm(D):return .4*clip_moment((c0+c1)/2,D[2:],1)/AREA
    return .4*(clip_moment(c1,D[2:],2)-clip_moment(c0,D[2:],2))/(2*(c1-c0)*AREA)

def loadbank():
    path=WORK/'starting_bank.json'
    if not path.exists():
        from duplicate_workspace import prepare
        path.write_text(json.dumps(prepare()))
    bank=json.load(open(path))
    rows=bank['sections']; G=np.array([r['G_f64'] for r in rows]); C=np.array([r['c_f64'] for r in rows]);
    return rows,G,C

class Bank:
    def __init__(self,rows,G,C):
        self.rows=rows;self.G=G;self.C=C
        eq=np.vstack([np.ones(len(G)),G.T]);rhs=np.r_[1.,np.zeros(40)]
        _,R,p=qr(eq.T,pivoting=True,mode='economic')
        rank=np.sum(np.abs(np.diag(R))>1e-8)
        self.inds=sorted(p[:rank]);self.eq=eq[self.inds];self.rhs=rhs[self.inds];self.full=eq
    def support(self,D):
        r=linprog(-self.C@D,A_eq=self.eq,b_eq=self.rhs,bounds=(0,None),method='highs')
        assert r.success,r.message
        return -r.fun, r.x
    def gap(self,D):
        s,l=self.support(D);return s-vol(D),s,l

if __name__=='__main__':
    tic=time.perf_counter();rows,G,C=loadbank()
    for i in range(len(rows)):
        r=rows[i];be=[ex.nominal(ex.decode(x)) for x in r['beta']];g,c,*_=calc(r['sigma'],be)
        assert np.max(abs(g-G[i]))<1e-8 and np.max(abs(c-C[i]))<1e-8
    b=Bank(rows,G,C)
    print('bank',len(rows),'rank',len(b.inds),'calibration',b.gap(np.array([8,6,13,-11]))[:2])
    rng=np.random.default_rng(927)
    ds=rng.normal(size=(300,4));ds/=np.linalg.norm(ds,axis=1)[:,None]
    ans=[]
    for d in ds:
        vals=FV@d
        if min(vals)*max(vals)>=0:continue
        gap,s,l=b.gap(d)
        ans.append(dict(D=d.tolist(),gap=gap,support=s,volume=vol(d),weights=[(i,float(x)) for i,x in enumerate(l) if x>1e-9]))
    ans.sort(key=lambda r:r['gap'])
    print('tested',len(ans),'negative',sum(r['gap']<-1e-7 for r in ans),'worst',ans[0]);print('seconds',time.perf_counter()-tic)
    json.dump(ans,open(str(WORK/'starting_scan.json'),'w'),indent=2)
