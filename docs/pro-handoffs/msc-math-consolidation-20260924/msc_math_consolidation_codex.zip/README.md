# Start at GOAL.md

The ZIP delegates repository/PDF consolidation to Codex; it does not modify the
repository or launch an agent. `prompt.md` is the full assignment.
`CLAIM_LEDGER.md` separates results from open questions. `EDITORIAL_MAP.md`
prevents redundant proof imports. `incoming/` preserves returned bytes.
`new_math/` contains work completed in the packaging session for review.

Use the repository's PDF/rendering tools when actually editing the thesis.
This handoff intentionally contains no newly built thesis PDF.
