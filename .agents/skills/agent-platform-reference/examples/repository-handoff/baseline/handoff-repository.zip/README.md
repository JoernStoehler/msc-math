# Workstation report

Continue development in this Rust project. Run `bash scripts/build.sh` to build and generate `report.html`; build output uses a writable cache selected from the current runtime environment and stays outside tracked source.

If the runtime supports local preview, run `python3 -m http.server 8000` from the repository root and inspect `http://localhost:8000/report.html`.
