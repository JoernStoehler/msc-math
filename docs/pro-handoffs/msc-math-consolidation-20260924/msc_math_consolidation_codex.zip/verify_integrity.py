#!/usr/bin/env python3
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parent
lines=(root/'MANIFEST.sha256').read_text().splitlines()
for line in lines:
 h,p=line.split('  ',1);q=root/p
 if not q.resolve().is_relative_to(root):raise ValueError(p)
 if hashlib.sha256(q.read_bytes()).hexdigest()!=h:raise ValueError('Hash mismatch: '+p)
print('PASS:',len(lines),'file hashes. Integrity is not mathematical validity.')
