#!/usr/bin/env python3
"""Exact check of one HKO HK minimizer and its vertex-covering symmetries.

Run: python hko_single_orbit_check.py   (requires SymPy only)
No files are read, no search or floating-point tests are used.
The external mathematical input is the published HKO capacity c0=5/(2*tau).
This checks Q=tau/5, positive weights, full affine rank, the six orbit nodes,
all insertion derivative identities, and symplectic coverage of all 25 vertices.
The accompanying insertion lemma, not this code alone, proves the cut estimates.
"""
import sympy as sp
from sympy.polys.matrices import DomainMatrix as DM

E = sp.QQ.algebraic_field(sp.sqrt(5-2*sp.sqrt(5)))
tau = E.unit
s = (E(5)-tau*tau)/E(2)
Z, O = E.zero, E.one
half, fourth = O/E(2), O/E(4)


def dot(x, y):
    return sum((u*v for u,v in zip(x,y)), Z)


def omega(x,y):
    return x[0]*y[2]+x[1]*y[3]-x[2]*y[0]-x[3]*y[1]


def add(x,y):
    return [u+v for u,v in zip(x,y)]


def scale(c,x):
    return [c*u for u in x]


def jflow(x):
    """J_c(q,p)=(-p,q), so omega(x,y)=<J_c x,y>."""
    return [-x[2],-x[3],x[0],x[1]]


alpha=(E(3)-s)/E(2)
big_y=tau*(O+s)/E(2)
sec=s-O
A=[[O,tau,Z,Z],[-alpha,big_y,Z,Z],[-sec,Z,Z,Z],
   [-alpha,-big_y,Z,Z],[O,-tau,Z,Z],
   [Z,Z,tau,-O],[Z,Z,big_y,alpha],[Z,Z,Z,sec],
   [Z,Z,-big_y,alpha],[Z,Z,-tau,-O]]
U=[[O,Z],[(s-O)*fourth,tau*(E(3)+s)*fourth],
   [-(O+s)*fourth,tau*(O+s)*fourth],
   [-(O+s)*fourth,-tau*(O+s)*fourth],
   [(s-O)*fourth,-tau*(E(3)+s)*fourth]]
V=[[u[1],-u[0]] for u in U]
# One-based labels for the answer: (1,2,8,4,10,6).
sigma=[0,1,7,3,9,5]
a=[A[i] for i in sigma]
u=(E(5)-s)/E(20)
w=s/E(10)
beta=[u,u,w,w,u,u]
Q0=tau/E(5)
C=[[a[j][k] for j in range(6)] for k in range(4)]+[[O]*6]
assert [dot(row,beta) for row in C]==[Z,Z,Z,Z,O]
# Positive root implies 0<sqrt(5)<5 and all beta_j>0, analytically.
assert E.to_sympy(u).is_positive is True
assert E.to_sympy(w).is_positive is True
Q=sum((beta[i]*beta[j]*omega(a[i],a[j]) for i in range(6) for j in range(i+1,6)),Z)
assert Q==Q0
I=[0,1,2,3,4]
CI=DM([[row[i] for i in I] for row in C],(5,5),E)
assert CI.det()!=Z
inverse=CI.inv().to_list()

pairs=[(1,0),(1,1),(1,2),(4,2),(4,0),(0,0)]
vertices=[U[i]+V[j] for i,j in pairs]
for r in range(6):
    assert add(vertices[r],scale(beta[r]/Q0,jflow(a[r])))==vertices[(r+1)%6]
    assert dot(a[r],vertices[r])==O
    assert dot(a[r],vertices[(r+1)%6])==O
# Q-gradient and exact KKT equation, with nu=2Q0 and ell=-2Q0*v0.
g=[sum((beta[j]*omega(a[j],a[i]) for j in range(i)),Z)
   +sum((beta[j]*omega(a[i],a[j]) for j in range(i+1,6)),Z) for i in range(6)]
ell=scale(-2*Q0,vertices[0])
assert all(g[i]==dot(ell,a[i])+2*Q0 for i in range(6))
# Check the affine insertion identity on 0,e1,...,e4, for all six positions.
probes=[[Z]*4]+[[O if k==j else Z for k in range(4)] for j in range(4)]
for r,v in enumerate(vertices):
    for b in probes:
        rhs=b+[O]
        correction=[-dot(row,rhs) for row in inverse]+[Z]
        assert [dot(row,correction) for row in C]==scale(-O,rhs)
        direct=sum((beta[j]*(omega(a[j],b) if j<r else omega(b,a[j])) for j in range(6)),Z)
        L=dot(g,correction)+direct
        assert L==2*Q0*(dot(v,b)-O)

# Rotation (q,p)->(Rq,Rp) and swap (q,p)->(J2 p,-J2 q).
R=[[U[1][0],-U[1][1]],[U[1][1],U[1][0]]]
def rotate2(x): return [dot(row,x) for row in R]
def rotate4(x): return rotate2(x[:2])+rotate2(x[2:])
def swap4(x): return [-x[3],x[2],x[1],-x[0]]
for i in range(5):
    assert rotate2(U[i])==U[(i+1)%5]
    assert rotate2(V[i])==V[(i+1)%5]
for i in range(5):
    for j in range(5):
        assert swap4(U[i]+V[j])==U[j]+V[i]
basis=probes[1:]
for T in [rotate4,swap4]:
    assert all(omega(T(x),T(y))==omega(x,y) for x in basis for y in basis)
covered={( (j+k)%5,(i+k)%5 ) if swap else ( (i+k)%5,(j+k)%5 )
         for i,j in pairs for k in range(5) for swap in [False,True]}
assert covered=={(i,j) for i in range(5) for j in range(5)}
print('PASS: one positive six-weight HK word with Q=tau/5 and rank(C)=5.')
print('PASS: six explicit characteristic segments and KKT stationarity.')
print('PASS: insertion derivative = 2 Q0 (<v,b>-1) at all six nodes.')
print('PASS: symplectic rotations and swap cover all 25 HKO vertices.')
print('No float arithmetic, optimizer, parameter grid, or external data.')
