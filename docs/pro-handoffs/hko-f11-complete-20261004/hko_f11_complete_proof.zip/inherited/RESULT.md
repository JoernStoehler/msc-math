# Result: the full F ≤ 11 theorem remains unresolved

**No proof of the complete Hausdorff local-maximality theorem, and no rigorous
counterexample to it, was obtained in this attempt.** The exact remaining
blocker is the **compact interior, fully coupled duplicate-normal problem**,
including any interior zero-margin cases. This return does not present another
successful directional sector as completion.

There are two proved global advances, plus an exact continuous-family workspace.

## 1. All redundant-limit regimes are excluded

`math/ENDPOINTS.md` proves Theorem E, using the accepted ten-facet sharpness
input and the supplied finite contact/cancellation data:

> There exist ε > 0 and η > 0 such that a genuine duplicate split near H,
> with all old normals allowed to move, satisfies ρ(K) ≤ ρ(H) whenever
> r + ||d|| < ε and min(μ, 1−μ) < η.

Thus no improving sequence can have μ tending to 0 or 1 at **any relative
rate**. This is one common collar and one common neighborhood radius, not a
radius for each fixed direction. Simultaneous normalization and duplicate
interchange are handled explicitly.

The key estimates retain the actual cap scale. When the limiting contact in
the old facet has dimension zero or one, insertion gain of order tμ² beats
removed volume of order tμ⁴ or tμ³. At a two-dimensional contact, the supplied
ridge certificate is rescaled with s→0: both its useful capacity-squared gain
and cap volume are of order δ²/s. The errors are small **relative to δ²/s**
under δ/s→0 and the tilt error divided by s tending to zero. Zero-pairing
contacts are handled by a separately chosen insertion weight Bδ/s.

This closes the redundant endpoints that the previous open-edge results did
not cover uniformly. It does not assert that all possible zero-margin
directions in the interior have been identified.

## 2. Finite global zonoid containment is structurally impossible

`math/FINITE_BANK_OBSTRUCTION.md` proves that no finite bank of the positive,
rank-five stationary touching sections used in the handoff can have
Z ⊂ C_bank globally. An active duplicate covector is a positive multiple of
the midpoint of a nonconstant characteristic segment in the facet. A finite
collection therefore misses sufficiently small caps near a uniquely exposed
facet vertex. This is a method obstruction, **not** a counterexample to HKO.

For the supplied 147-section bank there is an explicit exact witness:

    D = a4 + a7 + a8 − (29/10) a0.

All bank responses obey c_k·D ≤ 0, whereas

    v(D) = (3 + sqrt(5)) / 15,000,000 > 0.

The normalized split parameter is μ = 1/50. All 147 responses, including the
60 active and 87 unused duplicate rows, are checked exactly. The minimum
activation threshold is (5−sqrt(5))/8 > 1/10.

This rules out the proposed finite-polytope containment strategy **as a global
endpoint solution**. It does not rule out finite certificates on an interior
compact set. Continuous insertions are both geometrically appropriate and
numerically effective here.

## 3. The continuous alternative was actually developed and tested

The new numerical construction has 5,570 sampled rows. Its 710 cyclic word
families have been reconstructed and checked exactly, including their entire
flat weight polytopes, not just their sampled weights:

- 80 zero-dimensional families;
- 322 one-dimensional families;
- 308 two-dimensional families.

The full exact family data, all sampled numerical rows, generation code,
pricing code, and actual outputs are retained. This is not asserted to be a
complete enumeration of HKO minimizing words.

A three-round inner-hull experiment found 22 directions that defeated the
sampled 5,570-row bank. Continuous quadratic pricing repaired all 22 in
floating point. It also repaired the exact separating direction above.
The smallest final numerical primal margin among these 23 tests was about
0.0001762876. The worst original hull-direction gap changed from about
−0.0007255072 to +0.0015111221.

A separate replay retains the actual positive LP weights, selected words,
weight vectors, full old-gradient residuals, and pivot conditioning. Its
largest reported cancellation residual was about 9.44×10⁻¹² and its largest
selected pivot condition number about 5.706. Some numerical boundary weight
entries are as low as −2.78×10⁻¹⁷ from rounding; these floating-point rows
are **not** promoted to exact feasible-section certificates. Pricing was
limited to seven rounds per targeted replay, and some final pricing residuals
remained above tolerance. Positive primal margins are evidence, not a claim
that all these support optimizations were solved exactly.

## 4. The one remaining mathematical obligation

After the completed cases and Theorem E, any improving Hausdorff sequence
would reduce to a normalized duplicate chart with

    t_n → 0,   r_n = O(t_n),   η ≤ μ_n ≤ 1−η,
    D_n → D,   H_n/t_n → h,

for some η > 0, with all old-normal motions retained. Excluding **all** such
sequences is the remaining neighborhood theorem.

A sufficient first-order route is an exact cancellation relation with
Σλ_k G_k = 0 and (Σλ_k c_k)·D > v(D) for every genuinely sign-changing
interior D. Strict pointwise certificates would give a finite uniform cover
of the remaining compact direction set. No such universal comparison or
validated covering was obtained. If there are interior equality cases, their
higher-order behavior remains part of this same blocker.

`math/REMAINING_AND_HAUSDORFF.md` derives the necessary limiting inequalities,
explains exactly what the numerical evidence does not prove, and writes the
final polarity/labeling argument. That Hausdorff argument stops only at the
interior duplicate neighborhood, rather than at an unproved endpoint
uniformity claim.

## 5. Verification and scope

The supplied finite ridge/sector checks passed in this attempt. The new exact
endpoint and bank-obstruction checks passed; both deliberate corruption
controls failed as intended. All 710 continuous-family checks passed.
Commands and measured costs are in `REPRODUCE.md` and `evidence/COSTS.json`.
Analytic proofs are readable mathematical arguments, not proof-assistant
formalizations or claims of independent referee approval.

The accepted F=10 theorem and the previously completed F=11 neighborhoods
remain inputs. No actual-capacity lower bound, improving family, exhaustive
minimizer classification, or full F≤11 theorem is claimed. No additional Pro
call, external compute job, or scheduled continuation was used or assumed.
