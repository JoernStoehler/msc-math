# Measured work and why this attempt finished

These are elapsed times in the present execution environment. They are not API prices, model-inference costs, researcher salaries, or promises for another machine. Numerical jobs used one BLAS/OpenMP thread. The final clean-check ledger gives the exact commands, interpreter, platform and observed wall times.

## Decisive steps

| Step | Result | Observed time |
|---|---|---:|
| Complete adaptive numerical core, mu in [0.1,0.9] | 1,968 covered tetrahedra; no open or failed cell | 69.87 s |
| Exact construction/reconstruction of that core | All finite predicates passed | 92.83 s |
| Portable core verification, including extra literal checks | Passed | 145.48 s |
| Twenty separate depth-adaptive policy LPs | Positive sampled margins in every cone | 26.34 s |
| Adversarial collar probes, including rescaled thin layers | All tested policy margins positive; minimum about 0.00838 after dividing by mu^2 | 13.52 s |
| Exact reconstruction and uniform positivity of the twenty policies | 257 entire paths, all polynomial cancellation identities | 24.52 s |
| All-cone exact polynomial discovery (separate processes) | 887 accepted tetrahedra; no unresolved cell | 24.71 s including interpreter overhead |
| Portable combined policy and polynomial verification | Passed, including 160 exact formula crosschecks | 35.51 s |

The executed logs are included. Some steps overlap in purpose; adding their times is not a defensible estimate of the total research cost. This turn also required mathematical design, debugging, interpretation, and several discarded models. No aggregate inference-compute or monetary total is available.

## The failed restricted methods, and the information they supplied

- **One uniformly averaged family measure.** A fixed averaged model did not cover all 1,788 tested directions; allowing its mixing relation to depend on direction still left ten numerical failures. This was evidence that the averaging discarded useful weight dependence, not a counterexample to HKO.
- **One global depth-adaptive mixture for every tilt cone.** The sampled LP produced a negative margin. A more permissive version with signed polynomial old coefficients, constrained positive on sample directions, also failed after 223.48 seconds. These are failures of restricted model classes, not an impossibility theorem for continuous-weight certificates.
- **A common collapsed vertex for an entire tilt cone.** This lost the distributed contacts needed in thin layers near adjacent faces. Enlarging the list of endpoints did not repair all cones. Using each vertex's actual positive depth instead repaired this defect.
- **Raw dyadic extension toward a smaller cutoff.** At mu in [0.02,0.98], a 160-second capped run had 3,573 accepted numerical cells, no rejected cell, and forty open cells. It was incomplete and is not part of the proof. Even finishing it would not, by itself, join an existential endpoint collar.
- **Nonnegative second derivative of the proposed gap.** This stronger sufficient condition failed numerically in several cones. The gap itself remained positive. Checking the integrated polynomial rather than imposing this unnecessary curvature condition resolved the issue.

No finite positive fixed-weight bank can handle all redundant limits: the earlier return proved that structural obstruction. The solution does not evade it by more rows. It changes the representation to finitely many recipes with continuously varying internal weights.

## What made the successful computation manageable

The free variables in the collar comparison are only two tilt coordinates and one offset. The positive-part signs produce eight cells per tilt cone, not an uncontrolled high-dimensional arrangement. Exact integration turns the volume comparison into degree-nine polynomial positivity. Clearing denominators converts the hot loop to integer arithmetic, and a few angular midpoint subdivisions remove the remaining negative Bernstein coefficients.

The final problem therefore had a measured, finite workload: 160 sign cells and 195,140 coefficient signs. A cluster was not needed. Before this reduction existed, an estimate based only on the speed of a pointwise capacity evaluator would have been misleading.

## Remaining expenditure

There is no remaining proof-search obligation in the F<=11 theorem claimed here. What remains before publication/integration is an independent review of the new continuum argument and reproducibility checks. No literature-priority determination or external review is claimed. Further facet counts are separate research questions and are not automatically authorized by this success.
