# Claim ledger and recommended disposition

| ID | Statement | Evidence/status | Recommended home |
|---|---|---|---|
| L10-H | HKO locally maximal for exactly ten genuine facets, equality on local symmetry orbit | Accepted user/repository input; exact 26-section certificate | Existing local chapter, generalized exposition if useful |
| L10-N | Non-HKO hexagon/quadrilateral local maxima at rho=1, near the stated rational base | Returned exact proof + independent audit | New main result in same local chapter |
| L10-N+ | Local equality set is symmetry saturation of a two-parameter family; linear/quadratic transverse deficit | Independent audit's shorter uniform argument | Main statement/proof after review |
| AFF | Entire GL(4) orbit of HKO has rho<=rho_H | Two returned proofs, independently audited | One main general theorem |
| AFF-E | Equality is one conformal symplectic class; anti-symplectic images add no class | Equality addendum + independent alternative proof | Main theorem |
| AFF-S | A neighborhood in ten-facet affine shape works uniformly over all affine positions | Analytic compactness corollary requiring L10-H and AFF-E | Short corollary or companion note |
| COVER-R | Difference-body, prescribed ten-direction fan, affine-fivefold, central-partner bounds | Previously nested return; exact run reproduced now; give continuum audit | Companion note unless central to selected narrative |
| COVER-O | Ordinary inscribed-polygon averaging obstruction through seven vertices | Exact original + strengthened independent audit | Research note; not counterexample to target |
| COVER-L | Local arbitrary-convex-partner rigidity for fixed regular Q | NEW current derivation, positive exact marginal certificate; independent continuum review pending | Promote only after independent review |
| CUT-34 | Coupled one-cut neighborhoods for exposed primal edges/vertices | Current deduction from accepted L10-H and checked insertion lemma | Scoped research note |
| L11 | Full HKO local maximality for at most eleven facets | NOT ESTABLISHED in any returned packet available here | Open, never theorem |
| GLOBAL | HKO global maximality over all convex four-bodies | OPEN | Conjecture/question |
| PARTNER | Sharp bound/equality for every convex partner of fixed regular Q | OPEN globally; local and restricted results differ | Open residual statement |

Naming: HKO2024/HKO2025 refer to the same original pentagon-product body.
Use the published bibliographic record consistently, not the filename year.

For L10-N, do not confuse upper-section second derivatives with an exact second
derivative of actual rho. The full product capacity is known along the equality
family, not throughout the nonproduct deformation chart.

For AFF, a finite polarized-Pfaffian bound is stronger than the diagonal bound.
Failure of such a relaxation elsewhere does not certify a counterexample.

For COVER-R, the next finite-VERTEX area gap is not a uniform gap for all
nonoptimal covers; convex combinations can approach H. New local rigidity plus
compactness yields existential buffers for hypothetical competitors, not
numerical pruning radii.
