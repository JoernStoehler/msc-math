# Repository and source status

Repository: https://github.com/JoernStoehler/msc-math
Read baseline: 3929a8c7f0f766640ea78372848a5752a0ae7e08 (main read on 23 September 2026).
Inspect the actual checkout before acting; this pin is provenance, not permission
to reset a newer checkout. Current main thesis entry is thesis/main.tex;
build from repository root with `sh thesis/build.sh`.

Read AGENTS.md, ARCHITECTURE.md, thesis/README.md, and docs/WORK_REMAINING.md
before repository edits. The current user assignment supersedes historical
research allocation choices, but does not silently erase unrelated obligations.
The chatgpt-pro handoff skill was read from
.agents/skills/chatgpt-pro/SKILL.md. This is a human-mediated handoff: no new
session, background work, or external transfer has been launched by this ZIP.

Useful math/code paths:
- formal/hko-feasible-section-upper-branches.tex
- experiments/hko-local-maximum/theorem/
- formal/pentagon-affine-products/research.tex
- docs/capacity-calculation-map.md
- crates/symplectic/src/algorithms/capacity_4d/
- experiments/local-maxima-check/control-calibration/PILOT-REPORT.md

The public production solver documents bounded size/geometry/candidate coverage
and typed failure cases. Read its actual contract; a local QP solution or a
product-specific word family is not a general capacity lower bound.
