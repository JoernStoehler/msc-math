# HKO F ≤ 11: one end-to-end return

Start with **RESULT.md**. The target theorem remains unresolved; the return
proves a uniform redundant-limit collar, proves a structural obstruction to
finite global bank containment, and leaves one precisely identified compact
interior coupled-split blocker.

The readable arguments are `math/ENDPOINTS.md`,
`math/FINITE_BANK_OBSTRUCTION.md`, and `math/REMAINING_AND_HAUSDORFF.md`.
`REPRODUCE.md` gives exact checks and optional numerical experiments.

`data/continuous_families.json` contains 710 **exact** flat touching-weight
families. `data/numerical_bank_rows.json` and `data/numerical_bank.npz` preserve
all 5,570 **numerical** sampled rows and their construction provenance. Exact
field elements use descending rational coefficients of tau, with
`tau^4 − 10 tau^2 + 5 = 0` and `0 < tau < 1`.

The `evidence/` directory contains executed logs, numerical witnesses, exact
check outputs, measured costs, and deliberate negative controls. New numerical
runs write to a scratch `work/` directory, not to the packaged evidence.
This is a focused return, not another copy of the historical packet tree.
