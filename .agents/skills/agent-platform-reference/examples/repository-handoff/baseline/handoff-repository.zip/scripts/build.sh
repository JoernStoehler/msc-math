#!/usr/bin/env bash
set -euo pipefail

if [[ -n "${CARGO_TARGET_DIR:-}" ]]; then
  target_dir="$CARGO_TARGET_DIR"
elif [[ -n "${XDG_CACHE_HOME:-}" ]]; then
  target_dir="$XDG_CACHE_HOME/cargo/project-alpha"
else
  target_dir="${HOME:?HOME must be set to select a runtime cache}/.cache/cargo/project-alpha"
fi

mkdir -p "$target_dir"
if [[ ! -w "$target_dir" ]]; then
  echo "Cargo target directory is not writable: $target_dir" >&2
  exit 1
fi

cargo build --target-dir "$target_dir"
python3 scripts/report.py
