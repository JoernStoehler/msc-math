import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"inherited/code"))
from explore import *
def build_paths(fs,fractions=(.125,.25,.5,1.)):
 paths=[]
 for fi,f in enumerate(fs):
  if 10 not in f.sig or f.dim==0:continue
  k=f.sig.index(10)
  for vi,z0 in enumerate(f.verts):
   be0=f.be+f.T@z0
   if abs(be0[k])>1e-8:continue
   g0,c0,n,*_=calc(f.sig,be0)
   vlabel=int(np.argmin(np.linalg.norm(FV-n[k],axis=1)))
   if np.linalg.norm(FV[vlabel]-n[k])>1e-7:continue
   for fraction in fractions:
    be1=be0+fraction*(f.be-be0)
    gm,cm,*_=calc(f.sig,(be0+be1)/2);g1,c1,*_=calc(f.sig,be1)
    # power coefficients c=s cc1 + s^2 cc2
    cc1=4*cm-c1;cc2=2*c1-4*cm
    gb=np.array([g0,2*gm-(g0+g1)/2,g1])
    assert max(abs(c0))<1e-8
    assert np.linalg.norm(cc1-4*be1[k]*FV[vlabel])<1e-7
    assert abs(cc2@A[0])<1e-8
    paths.append(dict(family=fi,start_vertex=vi,fraction=fraction,vertex=vlabel,G=gb,C1=cc1,C2=cc2,be0=be0,be1=be1))
 return paths

