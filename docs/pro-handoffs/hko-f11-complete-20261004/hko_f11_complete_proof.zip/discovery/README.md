# Discovery material (not proof input)

The provided LP script is the actual twenty-cone search with paths changed to relative ones and a fresh output argument. It reconstructs numerical touching-family paths, solves twenty finite sampled LPs, and records the proposed polynomial policies. Sampling is not universal verification; the exact data and universal polynomial checks in `collar/` are the proof.

```sh
python -m pip install -r discovery/requirements.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python discovery/search_policies.py --out /tmp/new-policies.json
```

The returned policies may differ because of solver tie-breaking. They must be exactly reconstructed and checked before use. The checked exact result is pinned in `collar/data/policies.json`. Its validity is independently recomputed from definitions by `collar/verify.py`, so reproducing numerical discovery is not a theorem prerequisite.

The evidence directory retains the successful policy searches, adversarial probes, stronger-condition failures, and the capped smaller-core trial. All have their precise numerical or incomplete status preserved. The core was proposed by adaptive LP-supported tetrahedral bisection, then converted to exact positive sections; its full accepted tree is in `core/data/tree.json`. The final verifier does not trust discovery hulls or signs.
