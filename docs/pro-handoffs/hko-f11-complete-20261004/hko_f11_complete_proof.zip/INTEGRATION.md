# Integration instructions

The mathematical task is complete in this packet, subject to independent review of the new proof. Do not commission another finishing search for the same residual.

1. Independently review PROOF.md, especially the closure correction, depth-dependent weights, complete sign-cell construction, and endpoint-to-Hausdorff assembly. Re-run the exact checks. A clean run is not a substitute for this mathematical review.
2. Integrate the full F<=11 theorem, with the accepted F=10 theorem named as an input. Supersede the previous claim that an arbitrary duplicate-normal interior inequality is unresolved.
3. Keep the successful method visible: actual positive vertex depths drive the internal touching weights; a finite polynomial mixture cancels old-normal motion; the volume comparison is a small fixed-degree positivity problem. Do not describe the proof as exhaustive enumeration of all capacity minimizers.
4. Preserve the endpoint proof and the other-face lemmas as dependencies. The new proof does not erase their role or extract an explicit endpoint radius from them.
5. Retain failed fixed-bank and over-averaged approaches as repository research history, not as additional theorem statements. The finite-bank obstruction remains valid; the new construction uses continuous weights.
6. Do not infer equality rigidity for all eleven-facet bodies, an exact capacity Taylor formula, F=12 stability, arbitrary-convex-body local maximality, or global maximality.
7. Prefer a readable account of the finite predicate and full continuum implication in the thesis. The thousands of rows and polynomial coefficients belong in reproducible artifacts; printing them is not the proof's explanatory center.

Repository reference: https://github.com/JoernStoehler/msc-math . The earlier handoffs referenced commit 3929a8c7f0f766640ea78372848a5752a0ae7e08; the user has since reported a successful merge. Inspect the actual checkout before choosing current file paths or claiming its status.
