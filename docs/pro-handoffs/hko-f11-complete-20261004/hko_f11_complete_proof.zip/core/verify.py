#!/usr/bin/env python3
"""Verify a full directional core using exact Q(tau) arithmetic, standard library.

Input data are untrusted witnesses. No optimizer, floating point, or network is
used for acceptance. Decimal output fields are informational only. Read
../math/CORE_THEOREM.md for the continuum implication and source hypotheses.
"""
import argparse, hashlib, json, platform, sys, time
from pathlib import Path
from fractions import Fraction
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'code'))
from exact_tools import a,ZERO,ONE,calc_exact,exact_prisms,volume_response,encoded

def run(data, out, perturb=None):
 tic=time.perf_counter();load=lambda n:json.loads((data/(n+'.json')).read_text())
 tree=load('tree');seeds=load('old_seeds');anchor=load('anchor');families=load('families')['families'];rows=load('rows');relations=load('relations')
 if perturb=='leaf':tree['leaves'].pop()
 if perturb=='negative_weight':relations[0]['weights'][0]='-1'
 if perturb=='response':relations[0]['corrected_c'][0]=['1000']
 # Check the entire combinatorial cover before any lengthy row reconstruction.
 eta=a.K(Fraction(tree['eta']));threshold=a.K(Fraction(tree['minimum_gap']))
 a.require(a.sign(eta)>0 and a.sign(a.K(Fraction(1,2))-eta)>0,'valid core interval')
 roots=exact_prisms(eta);perm=tree['root_permutation'];a.require(sorted(perm)==list(range(60)),'complete exact root permutation')
 nodes=tree['nodes'];coords={};pending=list(range(60));visited=set();leafset=set()
 while pending:
  nd=pending.pop();a.require(nd not in visited and 0<=nd<len(nodes),'tree node unique and in range');visited.add(nd);node=nodes[nd]
  if 'root' in node:
   a.require(nd<60 and node['root']==nd,'root identity');T=roots[perm[nd]]
  else:
   a.require(nd>=60 and nd in coords,'reachable nonroot');T=coords[nd]
  coords[nd]=T
  if 'children' not in node:leafset.add(nd);continue
  i,j=node['edge'];a.require(0<=i<4 and 0<=j<4 and i!=j,'bisected edge');children=node['children'];a.require(len(children)==2,'two children')
  m=a.scale(a.K(Fraction(1,2)),a.add(T[i],T[j]))
  for child,k in zip(children,[i,j]):
   a.require(0<=child<len(nodes) and nodes[child].get('parent')==nd and nodes[child].get('replace')==k,'child incidence')
   tr=[p[:] for p in T];tr[k]=m;coords[child]=tr;pending.append(child)
 a.require(len(visited)==len(nodes),'every node reached');a.require(leafset==set(c['node'] for c in tree['leaves']) and len(leafset)==len(tree['leaves']),'every leaf certified exactly once')
 print('PASS entire subdivision tree:',len(leafset),'leaf tetrahedra',flush=True)
 # Exact positive anchor spanning the old gradient row space.
 oldG=[]
 for r in seeds:oldG.append(calc_exact(r['sigma'],[a.VALUES[x] for x in r['weights']])[0])
 a.require(oldG==[[a.decode(x) for x in row] for row in anchor['G']],'old gradients rebuilt')
 E=[[ONE]*len(oldG)]+list(map(list,zip(*oldG)));ow=[a.decode(x) for x in anchor['weights']];ci=anchor['column_indices'];ri=anchor['row_indices'];inv=[[a.decode(x) for x in r] for r in anchor['inverse']]
 a.require(len(set(ci))==len(set(ri))==26,'independent index counts');matrix=[[E[i][j] for j in ci] for i in ri]
 for col in range(26):a.require(a.mv(matrix,[inv[i][col] for i in range(26)])==[a.K(i==col) for i in range(26)],'exact 26 by 26 inverse')
 a.require(a.mv(E,ow)==[ONE]+[ZERO]*40 and all(a.sign(x)>0 for x in ow),'strict positive old anchor and full cancellation')
 print('PASS exact old anchor',flush=True)
 exact={};minbeta=None;literal_crosschecks=0
 for n,r in enumerate(rows):
  f=families[r['family']];base=[a.decode(x) for x in f['beta']];T=[[a.decode(x) for x in col] for col in f['directions']];zz=list(map(Fraction,r['parameters']));a.require(len(zz)==len(T),'family parameter dimension')
  be=[base[k]+sum((a.K(z)*col[k] for z,col in zip(zz,T)),ZERO) for k in range(len(base))]
  G,c,_=calc_exact(f['sigma'],be,f['pivot']);a.require(r['row'] not in exact,'row unique');exact[r['row']]=(G,c)
  for x in be:
   if minbeta is None or a.sign(x-minbeta)<0:minbeta=x
  # Additional literal differentiated-constraint checks, not an independent implementation.
  if n%257==0:
   sec=a.Section(a.A+[a.A[0]],f['sigma'],be,f['pivot']);gq=sec.gradient();agg=[x[:] for x in gq[:10]];agg[0]=a.add(agg[0],gq[10]);gg=[-2*x/a.Q0-a.VOL_GRAD[j]/a.V0 for j,x in enumerate(sum(agg,[]))]
   a.require(G==gg and c==a.scale(2/a.Q0,gq[10]),'literal gradient crosscheck');literal_crosschecks+=1
  if (n+1)%500==0:print('PASS positive touching rows',n+1,'/',len(rows),flush=True)
 cc={};maxmix=ZERO
 for n,r in enumerate(relations):
  ids=r['rows'];w=list(map(Fraction,r['weights']));a.require(len(ids)==len(w) and sum(w)==1 and all(x>=0 for x in w),'convex raw relation')
  g=[sum((a.K(weight)*exact[i][0][k] for i,weight in zip(ids,w)),ZERO) for k in range(40)]
  c=[sum((a.K(weight)*exact[i][1][k] for i,weight in zip(ids,w)),ZERO) for k in range(4)]
  target=[ZERO]+[-x for x in g];delta=a.mv(inv,[target[k] for k in ri]);Esub=[[E[k][i] for i in ci] for k in range(41)];a.require(a.mv(Esub,delta)==target,'correction in every old coordinate')
  mix=a.decode(r['mix']);a.require(a.sign(mix)>=0 and a.sign(ONE-mix)>0,'anchor mix in [0,1)')
  added=a.scale(mix,ow)
  for i,d in zip(ci,delta):added[i]+=(ONE-mix)*d
  a.require(all(a.sign(x)>=0 for x in added),'all corrected old weights nonnegative')
  a.require(sum(added,ZERO)+(ONE-mix)==ONE,'full convex mass')
  fullres=a.add(a.scale(ONE-mix,g),a.mv(list(map(list,zip(*oldG))),added));a.require(fullres==[ZERO]*40,'actual full forty-coordinate cancellation')
  corrected=a.scale(ONE-mix,c);a.require(corrected==list(map(a.decode,r['corrected_c'])),'claimed covector equals constructed covector');a.require(r['relation'] not in cc,'relation unique');cc[r['relation']]=corrected
  if a.sign(mix-maxmix)>0:maxmix=mix
 print('PASS all',len(cc),'relations exactly',flush=True)
 cache={};minimum=None
 for n,cell in enumerate(tree['leaves']):
  c=cc[cell['relation']]
  for D in coords[cell['node']]:
   key=tuple(D)
   if key not in cache:cache[key]=volume_response(D)
   gap=a.dot(c,D)-cache[key];a.require(a.sign(gap-threshold)>=0,'strict uniform vertex gap >= '+tree['minimum_gap'])
   if minimum is None or a.sign(gap-minimum)<0:minimum=gap
  if (n+1)%500==0:print('PASS tetrahedra',n+1,'/',len(tree['leaves']),flush=True)
 result=dict(passed=True,scope='All normalized split directions 1/10 <= mu <= 9/10. NOT the full F<=11 theorem.',eta=tree['eta'],uniform_margin=tree['minimum_gap'],exact_minimum_gap=encoded(minimum),minimum_gap_nominal=a.nominal(minimum),positive_touching_rows=len(exact),relations=len(cc),leaf_tetrahedra=len(leafset),exact_volume_points=len(cache),literal_gradient_crosschecks=literal_crosschecks,minimum_beta_nominal=a.nominal(minbeta),maximum_anchor_mix_nominal=a.nominal(maxmix),seconds=time.perf_counter()-tic,python=sys.version,platform=platform.platform(),dependencies='Python standard library only',data_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(data.glob('*.json'))})
 if out.exists():raise FileExistsError('Refusing to overwrite evidence: '+str(out))
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['data_sha256','exact_minimum_gap']},indent=2),flush=True)
 return result

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',type=Path,default=HERE/'data');p.add_argument('--out',type=Path,required=True);p.add_argument('--negative-control',choices=['leaf','negative_weight','response']);q=p.parse_args();run(q.data,q.out,q.negative_control)
if __name__=='__main__':main()
