# An exact, fully coupled open sector of a facet-splitting chart

This is an additional result, not a solution of the whole duplicate-normal
case. The complete ridge result does not rely on this section.

## Theorem F-sector

Use the same local normalization as the accepted F=10 theorem. Write
\(r=\|A-A_0\|\), and let

\[
 b=a_0(A)+tD,\qquad t\geq0,\qquad
 \|D-D_*\|_1\leq1/100,\quad D_*=(8,6,13,-11).
                                                               \tag{F1}
\]

There are \(c,\epsilon>0\), independent of \(D\) in the displayed ball,
such that

\[
 \frac{\rho(K(A,b))}{\rho_0}-1\leq-c(r+t)
            \quad\text{when }r,t<\epsilon.         \tag{F2}
\]

Thus this is a common angular-sector neighborhood with unrestricted old
motions, including all relative \(r/t\) scales and nonlinear paths. It is
not a result just for \(A=A_0\) or for one fixed straight ray. Its images
under the HKO symmetries, and under interchange of the two duplicate
inequalities, also hold. For unnormalized old coordinates one may take
\(\|D-D_*\|_1\leq1/200\) and a sufficiently small neighborhood: the local
normalization changes \(D\) by a quantity tending uniformly to zero, leaving
it in the verified ball of radius \(1/100\). Alternatively, the full
pullback of (F1) under the accepted normalization is a chart-invariant
formulation. The quantity \(r\) in (F2) is always the normalized distance;
no deficit along a geometric symmetry orbit is claimed.

At \(D_*\), six of the ten facet-vertex values are positive and four are
negative, all with absolute value greater than \(1/100\), as checked exactly.
The signs persist on a sufficiently small moving chart. For small positive
\(t\), both the old and new inequalities therefore define genuine facets;
the other nine facets retain interior points away from the old label-0 facet.
This is a genuine eleven-facet split, not a disguised whole-facet motion.

## 1. Positive-part volume, with a uniform remainder

The old facet is
\(F_0=[U_0,U_1]\times\operatorname{conv}(W)\). Put

\[
 v(D)=\frac1{V_0\|a_0\|}\int_{F_0}(D\cdot x)_+\,dS(x)
     =\frac25\operatorname{avg}_{[0,1]\times W}
        \bigl(D\cdot((1-u)U_0+uU_1,p)\bigr)_+.     \tag{F3}
\]

The factor \(2/5\) is checked exactly. In particular the signed whole-facet
integral is not substituted for (F3).

Uniformly for bounded \(D\) and nearby \(A\), the cap volume satisfies

\[
 \frac{V(P(A))-V(K(A,a_0(A)+tD))}{V_0}
       =t\,v(D)+O(rt+t^2).                        \tag{F4}
\]

Here is one justification including sign changes. Use the single slack
\(y=1-a_0(A)\cdot x\), with the orthogonal projection to the moving facet.
For small \(y\geq0\), the parallel section has the same face incidences;
triangulate it by a fixed triangulation of the facet vertices. Its
piecewise-affine parametrization is \(x=\Phi_{A,y}(z)-T_Ay\), with
\(\Phi_{A,y}(z)-z=O(y)\) and tangential Jacobian \(1+O(y)\).
The cutting condition is

\[
 tD\cdot z-y+tD\cdot(\Phi_{A,y}(z)-z-T_Ay)>0.
\]

On each simplex its last coefficient is uniformly bounded times \(ty\).
The positive allowed thickness is consequently
\(t(D\cdot z)_+(1+O(t))\), uniformly even where the affine function changes
sign or vanishes. Integrating proves the first-order facet integral at
\(F(A)\) with an \(O(t^2)\) error. The integral and its geometric factor
change by \(O(r)\), because the facet triangulation varies Lipschitzly and
positive part is Lipschitz. This proves (F4). The tube/support-gap argument
ensures that all removed points are in these local sections.

## 2. Tight duplicate-normal sections and the coupling identity

The data `facet_cone_certificate.json` contain 26 words in the eleven
labels, with label 10 equal to \(a_0\) at the base. Zero weights at the
endpoint of a construction have been discarded: every weight actually
stored is strictly positive, and every stored five-column minor is
invertible. Direct exact checks show, for each word,

\[
 \sum\beta=1,\qquad\sum\beta_i a_{\sigma_i}=0,\qquad
 Q=Q_0,\qquad\nabla_\beta Q=C^T\lambda.
\]

They therefore define actual smooth feasible sections in a neighborhood of
\((A_0,a_0)\). No classification of all minimizers is asserted.

Let \(g_{Q,k,i}\) be the four-component normal derivative of a section.
The derivative relevant to the old motion in (F1) must add the new-normal
derivative to the old label 0 derivative. Define

\[
 \widetilde g_{Q,k,0}=g_{Q,k,0}+g_{Q,k,10},\qquad
 \widetilde g_{Q,k,i}=g_{Q,k,i}\ (i\ne0),
\]
\[
 G_k=-2\widetilde g_{Q,k}/Q_0-DV/V_0,
 \qquad c_k=2g_{Q,k,10}/Q_0.                        \tag{F5}
\]

The exact positive weights \(\lambda_k\) in the data satisfy

\[
 \sum\lambda_k=1,\qquad
 \sum\lambda_kG_k=0\in\mathbb R^{40}.              \tag{F6}
\]

With \(\bar c=\sum\lambda_kc_k\), the checker also proves

\[
 \|\bar c\|_\infty<1,\qquad
 \bar c\cdot D_*-v(D_*)>1/10.                      \tag{F7}
\]

These are exact algebraic inequalities. The observed decimal response is
about 3.54116, while the volume slope is about 3.42768; the exact expressions,
not these decimals, are used in every assertion. The certificate was found
by enriching the original six-support seeds with flat insertions of absent
old normals, then inserting the duplicate. Its discovery history is not
needed to trust the stored, independently checked weights.

Every coordinate of every point of \(F_0\) has absolute value at most one.
Consequently (F3) is \(2/5\)-Lipschitz in the \(\ell^1\) norm. From (F7),
for every \(D\) in (F1),

\[
 \bar c\cdot D-v(D)
 >\frac1{10}-\left(1+\frac25\right)\frac1{100}
 =\frac{43}{500}>\frac1{20}.                       \tag{F8}
\]

This is the source of the explicit open-sector coverage. A single certified
center direction has been extended by a quantified Lipschitz estimate, not
by an unsupported compactness argument.

## 3. Exact evaluation of the facet integral

The verifier decomposes the pentagon into triangles
\((0,1,2),(0,2,3),(0,3,4)\). For each bottom triangle \((a,b,c)\), its prism
is decomposed into the three tetrahedra

\[
 (a,b,c,c+5),\quad(a,b,b+5,c+5),\quad(a,a+5,b+5,c+5).
\]

The indices \(0,\ldots,4\) are the bottom pentagon and
\(5,\ldots,9\) the top pentagon. The pieces have disjoint interiors and
cover the prism. The code checks their positive determinant volumes and
that their sum is the pentagon area.

For a tetrahedron and affine vertex values \(f_0,\ldots,f_3\) that are
pairwise distinct,

\[
 \operatorname{avg}_{T} f_+
   =\frac14\sum_{i=0}^3
       \frac{(f_i)_+^4}{\prod_{j\ne i}(f_i-f_j)}.   \tag{F9}
\]

For clarity, this identity does not depend on a numerical triangulation or
quadrature. The divided-difference integral formula follows by iterating
the fundamental theorem of calculus: the divided difference of a function
\(g\) at \(f_0,\ldots,f_n\) equals the integral of
\(g^{(n)}(\sum\lambda_i f_i)\) over the standard barycentric simplex, with
Lebesgue volume \(1/n!\). Taking
\(g(x)=x_+^{n+1}/(n+1)!\), whose \(n\)-th derivative is \(x_+\), and
multiplying by \(n!\) to normalize the volume gives
\((n+1)^{-1}\sum_i(f_i)_+^{n+1}/\prod_{j\ne i}(f_i-f_j)\).
This proves (F9); repeated nodes follow by continuity but are not needed
for \(D_*\). Pairwise distinction and all required signs are checked
exactly. The nine tetrahedra therefore give the exact positive-part prism
integral in (F7).

## 4. Full old-normal coupling and uniform radius

Each stored section gives, by smoothness, (A3), and (F4),

\[
 S(A,a_0(A)+tD)
 \leq G_k\cdot H+t\bigl(v(D)-c_k\cdot D\bigr)
                       +O((r+t)^2),               \tag{F10}
\]

uniformly on the fixed compact \(D\)-ball. Combining with the positive
weights in (F6) and (F8) yields

\[
 S\leq-t/20+C(r+t)^2.                             \tag{F11}
\]

It would be wrong to use (F11) alone when \(r\) is much larger than \(t\).
Instead, monotonicity, the accepted F=10 deficit, and the bounded facet cap
give a second estimate

\[
 S\leq-\kappa r+C't.                              \tag{F12}
\]

Choose \(D_0>2C'/\kappa\). If \(r>D_0t\), (F12) is bounded above by a
negative multiple of \(r+t\). If \(r\leq D_0t\), the remainder in (F11)
is at most \(C(D_0+1)^2t^2\) and is absorbed by \(t/20\) for all
sufficiently small \(t\). Then \(r+t\leq(D_0+1)t\), proving (F2).
For \(t=0\) use F=10 directly.

There are finitely many positive sections, each with a fixed invertible
minor, and a compact set of \(D\)'s. Feasibility and the error bounds
therefore have a common radius, supplied by the estimates above. Arbitrary
higher-order paths and all old-facet motions are included.

The local normalization acts smoothly on normalized normals. Applied to
\(b-a_0(A)=tD\), it gives \(t(D+o(1))\), uniformly for bounded \(D\), as
the chart approaches its base point. The inner ball of radius \(1/200\)
therefore maps into the proved ball of radius \(1/100\). This justifies the
unnormalized formulation stated after (F2). Interchanging the duplicate
labels replaces the difference by its negative and gives the corresponding
opposite sector, without imposing a restriction on old motion.

No claim is made about the directions outside these sectors. In particular,
their symmetry images are not asserted to cover the normalized direction
space of the duplicate chart.
