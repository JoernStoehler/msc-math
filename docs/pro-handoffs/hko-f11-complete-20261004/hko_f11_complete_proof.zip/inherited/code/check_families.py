#!/usr/bin/env python3
"""Exact reconstruction of the 710 continuous touching-weight families.

The original numerical generator selected flat insertions by tolerances. This
checker reconstructs every retained word from its exact seed and rational
insertion fraction, then verifies touching, stationarity, and all flat-family
identities without floating point. It does NOT verify directional coverage.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from collections import Counter
import argparse,json,time,hashlib
import exact_core as a
from duplicate_workspace import encoded

def canonical(sig,be):
 p=sig.index(min(sig));return sig[p:]+sig[:p],be[p:]+be[:p]

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--families',type=Path);args=p.parse_args()
 root=Path(__file__).resolve().parents[1];tic=time.perf_counter()
 seeds=json.loads((root/'data/seeds.json').read_text());records=json.loads((root/'data/continuous_family_origins.json').read_text());AA=a.A+[a.A[0]]
 cache={};zero=[a.ZERO]*4
 def reconstruct(o):
  key=json.dumps(o,sort_keys=True)
  if key in cache:return cache[key]
  if isinstance(o,str):
   r=seeds[int(o.split('_')[-1])];sig=r['sigma'][:];be=[a.VALUES[x] for x in r['weights']]
  elif 'swap' in o:
   sig,be=reconstruct(o['swap']);sig=[10 if x==0 else x for x in sig]
  else:
   sig,be=reconstruct(o['parent']);label=o['label'];pos=o['pos'];I=o['pivot'];normal=AA[label]
   C=[[AA[i][k] for i in sig] for k in range(4)]+[[a.ONE]*len(sig)]
   inv=a.inv([[r[j] for j in I] for r in C]);h=[a.ZERO]*len(sig)
   for i,v in zip(I,a.mv(inv,[-x for x in normal]+[-a.ONE])):h[i]=v
   candidates=[-be[i]/h[i] for i in range(len(sig)) if a.sign(h[i])<0]
   a.require(bool(candidates),'bounded positive insertion interval')
   zm=candidates[0]
   for z in candidates[1:]:
    if a.sign(z-zm)<0:zm=z
   z=zm*a.K(F(str(o['fraction'])))
   ss=sig[:pos]+[label]+sig[pos:];bb=[be[i]+z*h[i] for i in range(len(sig))];bb.insert(pos,z)
   a.require(all(a.sign(x)>=0 for x in bb),'exact insertion nonnegativity')
   sig=[i for i,b in zip(ss,bb) if b];be=[b for b in bb if b]
  sig,be=canonical(sig,be);cache[key]=(sig,be);return sig,be
 out=[];stats=Counter();minweight=None
 for n,rec in enumerate(records):
  sig,be=reconstruct(rec['origin']);a.require(sig==rec['sigma'],'exact reconstruction word agrees')
  C=[[AA[i][k] for i in sig] for k in range(4)]+[[a.ONE]*len(sig)]
  I=None
  for ii in combinations(range(len(sig)),5):
   try:a.inv([[r[j] for j in ii] for r in C]);I=list(ii);break
   except ArithmeticError:pass
  a.require(I is not None,'rank five');sec=a.Section(AA,sig,be,I)
  m=len(sig);free=[j for j in range(m) if j not in I];B=[]
  for j in free:
   v=[a.ZERO]*m;v[j]=a.ONE
   for i,x in zip(I,a.mv(sec.ci,[-r[j] for r in C])):v[i]=x
   B.append(v)
  H=[[a.ZERO if i==j else (a.omega(AA[sig[i]],AA[sig[j]]) if i<j else a.omega(AA[sig[j]],AA[sig[i]])) for j in range(m)] for i in range(m)]
  R=[[a.dot(u,a.mv(H,v)) for v in B] for u in B]
  pp=next((j for j in range(len(B)) if R[j][j]),None)
  a.require(pp is not None and a.sign(R[pp][pp])<0,'one negative curvature direction')
  a.require(all(R[i][j]*R[pp][pp]==R[i][pp]*R[j][pp] for i in range(len(B)) for j in range(len(B))),'restricted Hessian exactly rank one')
  T=[]
  for j in range(len(B)):
   if j==pp:continue
   v=a.add(B[j],a.scale(-R[pp][j]/R[pp][pp],B[pp]));T.append(v)
   a.require(a.mv(C,v)==[a.ZERO]*5 and a.dot(sec.gb,v)==a.ZERO,'flat tangent closure and stationarity')
  for u in T:
   for v in T:a.require(a.dot(u,a.mv(H,v))==a.ZERO,'identically constant objective on whole flat family')
  # Therefore beta=be+sum z_j T_j, beta>=0 is an exact continuous family,
  # with Q identically Q_H on its entire compact parameter polytope.
  dim=len(T);stats[(m,dim)]+=1
  for w in be:
   if minweight is None or a.sign(w-minweight)<0:minweight=w
  out.append(dict(sigma=sig,beta=[encoded(x) for x in be],pivot=I,directions=[[encoded(x) for x in col] for col in T],dimension=dim))
  if (n+1)%100==0:print('PASS',n+1,'exact continuous families',flush=True)
 a.require(dict(stats)=={(6,0):80,(7,1):322,(8,2):308},'expected support and dimension counts')
 result=dict(all_checks_passed=True,families=len(out),counts=[dict(support=m,dimension=d,count=c) for (m,d),c in sorted(stats.items())],minimum_base_weight=encoded(minweight),seconds=time.perf_counter()-tic,
  scope='Exact positive touching families and their entire flat weight polytopes. No global direction coverage or completeness of minimizers.',input_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in [root/'data/seeds.json',root/'data/continuous_family_origins.json']})
 document=dict(coefficient_order='descending powers of tau',families=out)
 stored=root/'data/continuous_families.json'
 if stored.exists():a.require(json.loads(stored.read_text())==document,'retained exact family data equals reconstruction')
 args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(json.dumps(result,indent=2)+'\n')
 if args.families:args.families.write_text(json.dumps(document,indent=2)+'\n')
 print('ALL',len(out),'EXACT FAMILY CHECKS PASSED in %.3f s'%result['seconds'],flush=True)
if __name__=='__main__':main()
