"""Exact homogeneous simplex coefficients over Z[tau], tau^4=10tau^2-5.
Signs use nested-square-root comparisons in integers, no approximate acceptance.
"""
from math import lcm
Z=(0,0,0,0);O=(1,0,0,0)
def add(x,y):return tuple(a+b for a,b in zip(x,y))
def scale(k,x):return tuple(k*a for a in x)
def mul(x,y):
 if x==Z or y==Z:return Z
 if y[1:]==(0,0,0):return scale(y[0],x)
 if x[1:]==(0,0,0):return scale(x[0],y)
 a,b,c,d=x;e,f,g,h=y
 t4=b*h+c*g+d*f;t5=c*h+d*g;t6=d*h
 return (a*e-5*t4-50*t6,a*f+b*e-5*t5,a*g+b*f+c*e+10*t4+95*t6,a*h+b*g+c*f+d*e+10*t5)
def si(n):return (n>0)-(n<0)
def sign5(a,b):
 sa,sb=si(a),si(b)
 if not sa:return sb
 if not sb or sa==sb:return sa
 return sa*si(a*a-5*b*b)
def m5(x,y):a,b=x;c,d=y;return(a*c+5*b*d,a*d+b*c)
def sign(x):
 u,v,w,z=x;A=(u+5*w,-2*w);B=(v+5*z,-2*z);sa=sign5(*A);sb=sign5(*B)
 if not sa:return sb
 if not sb or sa==sb:return sa
 aa=m5(A,A);bb=m5(m5(B,B),(5,-2));return sa*sign5(aa[0]-bb[0],aa[1]-bb[1])
IND=[];NEXT=[]
for n in range(10):IND.append([(i,j,k,n-i-j-k) for i in range(n+1) for j in range(n-i+1) for k in range(n-i-j+1)])
for n in range(9):
 mp={x:i for i,x in enumerate(IND[n+1])};table=[]
 for x in IND[n]:
  row=[]
  for k in range(4):y=list(x);y[k]+=1;row.append(mp[tuple(y)])
  table.append(row)
 NEXT.append(table)
def mul_linear(p,L,n):
 out=[Z]*len(IND[n+1]);idx=NEXT[n]
 for j,x in enumerate(p):
  if x==Z:continue
  for k,l in enumerate(L):
   if l!=Z:out[idx[j][k]]=add(out[idx[j][k]],mul(x,l))
 return out
def product(lins):
 p=[O]
 for n,L in enumerate(lins):p=mul_linear(p,L,n)
 return p
def sum_polys(p,q):return list(map(add,p,q))
def convert(K,den):
 return tuple(int(c.numerator*(den//c.denominator)) for c in K.a)
def common_den(vals):
 n=1
 for x in vals:
  for c in x.a:n=lcm(n,c.denominator)
 return n
