# Current-session findings and decision

Prepared 23 September 2026. No repository write, session launch or external
transfer has occurred. The user reports no other Pro sessions currently open.

## Work completed here rather than delegated

1. Exposed the previously nested hko_fixed_pentagon_results.zip and reproduced
   every requested exact stage, including complete finite-fan adjacency closure,
   actual polygon capacity witnesses, compact domain and the missing-orbit
   rejection test. This is a fresh rerun plus a mathematical read, not a newly
   independent implementation of the full restricted theorem.
2. Derived local rigidity of the HKO normal-triangle placement, using a local
   two-copy-per-corner polygon lower bound and a compressed positive relation.
   The exact 50 marginal probabilities have minimum
   33/218 - 39sqrt(5)/1090 >0; the difference rank is 18. A clean-extraction rerun
   passed. The proof yields local maximality/equality for arbitrary convex
   partners of the FIXED regular pentagon, not all convex four-bodies.
   Independent review of the continuum lemma is explicitly requested.
3. Combined the insertion bound with a uniform cap tube estimate to extend the
   known coupled Case IV proof to Case III: exposed primal vertices AND edges.
   Cases I/II still need their volume/capacity coefficients compared.
4. Recorded a simple global-search reduction: a local hull-area minimum in an
   open generic hull-cycle cell is flat and can be moved to a contact boundary.
   This does not complete contact classification or establish a fan reduction.

## Consolidation decision

Consolidate now. Use the non-HKO local family and one full affine HKO theorem
with equality as central new results. Keep the other affine proof and specialized
proof ideas in normal repository homes; do not print both proofs or huge meshes.
A stronger upper bound does not subsume exact special-family capacity formulas
or the generic arbitrary-factor product-position theorem. Make an explicit
reader-value decision about those, rather than mechanically deleting them.
The nested restricted cover results and new local result deserve a reviewed
companion note; main-PDF inclusion should remain economical.

A focused human mathematical/novelty review is a separate high-value next action.
Another AI reimplementation of an already twice-checked affine certificate has
lower marginal value. Prepare the short review brief; do not send it externally
without the user's action. No proof here is labelled 100%-certain or formally
verified merely because exact arithmetic passed.

## Research decision

Use two nonoverlapping assignments:
- F<=11 local theorem: remaining facet/ridge neighborhoods and complete coupling.
- Global fixed-pentagon cover: contact reduction/area-threatening region,
  explicitly disallowing another affine-orbit detour.

These are conditional research bets, not forecasts of certain completion. The
first has a concrete low-dimensional residual and existing exact witness data;
the second has higher upside and a larger genuinely geometric gap. Success may
be a full theorem or a decisive new obstruction/reduction. Repeated unsuccessful
random starts or a repackaged affine proof do not count as a useful outcome.

## What remains open

Full F<=11 HKO local maximality; arbitrary convex-body local maximality; global
fixed-pentagon partner optimality; all-convex-body global optimality and equality.
The new local cover proof has not closed any of these global/four-body claims.
