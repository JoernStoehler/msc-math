#!/usr/bin/env python3
"""Deliberately corrupt new-check inputs in temporary copies; both must fail."""
from pathlib import Path
import argparse,json,shutil,subprocess,sys,tempfile,time
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);args=p.parse_args();root=Path(__file__).resolve().parents[1];args.out.mkdir(parents=True,exist_ok=True)
results=[]
for name in ['bad_contact_vertex','bad_cancellation_weight']:
 with tempfile.TemporaryDirectory(prefix='hko_negative_') as temp:
  temp=Path(temp);shutil.copytree(root/'code',temp/'code',ignore=shutil.ignore_patterns('__pycache__'));shutil.copytree(root/'data',temp/'data')
  if name=='bad_contact_vertex':
   path=temp/'data/zero_ridges.json';data=json.loads(path.read_text());data[0]['vertex']=0
  else:
   path=temp/'data/ridge_certificates.json';data=json.loads(path.read_text());w=data[0]['terms'][0]['weight'];from fractions import Fraction
   data[0]['terms'][0]['weight']=[str(2*Fraction(x)) for x in w]
  path.write_text(json.dumps(data));tic=time.perf_counter()
  r=subprocess.run([sys.executable,str(temp/'code/check_new.py'),'--out',str(temp/'bad.json')],capture_output=True,text=True)
  seconds=time.perf_counter()-tic;(args.out/(name+'.log')).write_text(r.stdout+r.stderr)
  if r.returncode==0:raise RuntimeError('Negative control was not detected: '+name)
  results.append(dict(case=name,returncode=r.returncode,seconds=seconds,detected=True));print('PASS detected',name,flush=True)
(args.out/'negative_controls.json').write_text(json.dumps(results,indent=2)+'\n')
