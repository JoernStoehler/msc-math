# External source roles

Haim-Kislev, On the symplectic size of convex polytopes:
https://arxiv.org/html/1712.03494v3
Role: HK inverse-max formula; cut subadditivity. A feasible Q is a capacity UPPER
bound. Cut subadditivity bounds capacity LOSS FROM ABOVE.

Haim-Kislev--Ostrover, A counterexample to Viterbo's conjecture:
https://arxiv.org/html/2405.16513v3
Role: known HKO body and exact benchmark, not its global optimality.

Balitskiy--Mitrofanov--Polyanskii, Triangle covering problems and the Viterbo
inequality in the plane:
https://arxiv.org/html/2603.12495v2
Role: normal-triangle covering equivalence, quadrilateral product theorem,
fixed-pentagon problem. Version 2 and current HTML were checked in this session.

Haim-Kislev, Dynamical extensions of Zoll to nonsmooth convex bodies:
https://arxiv.org/html/2511.16644v1
Role: related cut/dynamical questions. Do not attribute our returned proofs to
this paper or infer that cut extremality implies local ratio maximality.

No literature-novelty or human-referee acceptance claim is made. Original
research ZIPs and audit addenda are project evidence, not published theorems.
