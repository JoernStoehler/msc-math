from fastbank import *
from enrich import canon
from scipy.linalg import null_space
from dataclasses import dataclass

class Family:
 def __init__(self,sig,be):
  self.sig=list(sig);self.be=np.array(be)
  g,c,n,H,C=calc(self.sig,be);N=null_space(C,rcond=1e-10);R=N.T@H@N
  ev,vec=np.linalg.eigh(R);self.T=N@vec[:,abs(ev)<1e-8];self.dim=self.T.shape[1]
  assert self.dim<=2
  if self.dim==0:self.verts=np.empty((1,0))
  elif self.dim==1:
   t=self.T[:,0];lo=max([-be[i]/t[i] for i in range(len(be)) if t[i]>1e-9]);hi=min([-be[i]/t[i] for i in range(len(be)) if t[i]<-1e-9]);self.verts=np.array([[lo],[hi]])
  else:
   vs=[]
   for i,j in itertools.combinations(range(len(be)),2):
    tt=self.T[[i,j]]
    if abs(np.linalg.det(tt))<1e-9:continue
    z=np.linalg.solve(tt,-self.be[[i,j]])
    if min(self.be+self.T@z)>-1e-8 and not any(np.linalg.norm(z-v)<1e-8 for v in vs):vs.append(z)
   vs=np.array(vs);assert len(vs)>=3
   self.verts=vs[ConvexHull(vs).vertices]
  def value(z):
   gg,cc,*_=calc(self.sig,self.be+self.T@z);return np.r_[gg,cc]
  self.coef=[value(np.zeros(self.dim))]
  for j in range(self.dim):
   e=np.eye(self.dim)[j];self.coef.append((value(e)-value(-e))/2)
  for j in range(self.dim):
   e=np.eye(self.dim)[j];self.coef.append((value(e)+value(-e))/2-self.coef[0])
  if self.dim==2:self.coef.append(value(np.ones(2))-sum(self.coef))
  self.coef=np.array(self.coef)
 def row(self,z):
  z=np.asarray(z);mon=np.r_[1,z,z*z,([z[0]*z[1]] if self.dim==2 else [])]
  return mon@self.coef
 def maximize(self,co):
  if self.dim==0:return float(co[0]),np.zeros(0)
  best=-np.inf;bz=None
  vs=self.verts
  for i,x in enumerate(vs):
   y=vs[(i+1)%len(vs)];v=y-x
   if self.dim==1:
    a=co[2]*v[0]**2;b=co[1]*v[0]+2*co[2]*x[0]*v[0];c=co[0]+co[1]*x[0]+co[2]*x[0]**2
   else:
    a=co[3]*v[0]**2+co[4]*v[1]**2+co[5]*v[0]*v[1]
    b=co[1]*v[0]+co[2]*v[1]+2*co[3]*x[0]*v[0]+2*co[4]*x[1]*v[1]+co[5]*(x[0]*v[1]+x[1]*v[0])
    c=co[0]+co[1]*x[0]+co[2]*x[1]+co[3]*x[0]**2+co[4]*x[1]**2+co[5]*x[0]*x[1]
   zz=[0.,1.]
   if a<-1e-12 and 0<-b/(2*a)<1:zz.append(-b/(2*a))
   for t in zz:
    f=c+b*t+a*t*t
    if f>best:best=f;bz=x+t*v
  if self.dim==2:
   H=np.array([[2*co[3],co[5]],[co[5],2*co[4]]])
   if H[0,0]<-1e-12 and np.linalg.det(H)>1e-14:
    z=np.linalg.solve(H,-co[1:3])
    if min(self.be+self.T@z)>-1e-9:
     f=co[0]+co[1:3]@z+z@H@z/2
     if f>best:best=f;bz=z
  return float(best),bz

def families():
 raw=json.load(open(ROOT/'data/continuous_families.json'))['families']
 return [Family(r['sigma'],[ex.nominal(ex.decode(x)) for x in r['beta']]) for r in raw]

def price(fams,bank,D):
 # max primal with y=-min-dual. price=cD+min-dual*(1,G).
 vec=np.r_[np.zeros(40),D];constant=0
 for j,v in zip(bank.inds,bank.dual):
  if j==0:constant+=v
  else:vec[j-1]+=v
 ans=[]
 for k,f in enumerate(fams):
  co=f.coef@vec;co[0]+=constant
  val,z=f.maximize(co)
  ans.append((val,k,z))
 return sorted(ans,key=lambda r:-r[0])

def run_direction(fams,D,maxrounds=12):
 dat=np.load(str(WORK/'enriched.npz'));G=dat['G'];C=dat['C'];added=[];history=[];tic=time.perf_counter()
 for it in range(maxrounds):
  bank=FastBank(None,G,C);s,l=bank.support(D);pr=price(fams,bank,D)
  history.append(dict(iteration=it,rows=len(G),support=s,gap=s-vol(D),max_price=pr[0][0],full_cancellation_residual=float(np.max(np.abs(bank.full@l-np.r_[1.,np.zeros(40)]))),seconds=time.perf_counter()-tic))
  print(history[-1],flush=True)
  if pr[0][0]<1e-9:break
  gg=[];cc=[]
  for val,k,z in pr:
   if val<1e-8:break
   f=fams[k];row=f.row(z);gg.append(row[:40]);cc.append(row[40:]);added.append(dict(family=k,sigma=f.sig,beta=(f.be+f.T@z).tolist(),price=val))
  if not gg:break
  G=np.vstack([G,gg]);C=np.vstack([C,cc])
 original=json.load(open(ROOT/'data/numerical_bank_rows.json'))['rows']
 witnesses=[];conditions=[];minbeta=1.
 for i,weight in enumerate(l):
  if weight<=1e-10:continue
  rec=original[i] if i<len(original) else added[i-len(original)]
  sig=rec['sigma'];beta=rec.get('be',rec.get('beta'))
  aa=A11[sig];cm=np.vstack([aa.T,np.ones(len(sig))]);_,_,pivot=qr(cm,pivoting=True,mode='economic')
  condition=float(np.linalg.cond(cm[:,pivot[:5]]));conditions.append(condition);minbeta=min(minbeta,min(beta))
  witnesses.append(dict(row=i,weight=float(weight),sigma=sig,beta=beta,G=bank.G[i].tolist(),c=bank.C[i].tolist(),pivot=list(map(int,pivot[:5])),pivot_condition_f64=condition))
 return dict(D=D.tolist(),volume=vol(D),history=history,added=added,primal_witness=witnesses,maximum_pivot_condition_f64=max(conditions),minimum_active_word_beta_f64=float(minbeta))

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--rounds',type=int,default=8);p.add_argument('--case',type=int,default=0);p.add_argument('--out',default=str(WORK/'continuous_result.json'));args=p.parse_args()
 tic=time.perf_counter();fs=families();print('families',len(fs),'setup_seconds',time.perf_counter()-tic,flush=True)
 cases=sorted(json.load(open(str(WORK/'hull_state.json')))['bad'],key=lambda r:r['gap'])
 out=run_direction(fs,np.array(cases[args.case]['D']),args.rounds);out['setup_seconds']=time.perf_counter()-tic-out['history'][-1]['seconds'];json.dump(out,open(args.out,'w'),indent=2)
