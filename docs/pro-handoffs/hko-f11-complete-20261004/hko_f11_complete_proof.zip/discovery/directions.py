import sys
from pathlib import Path
import numpy as np
from scipy.spatial import ConvexHull
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"inherited/code"))
from explore import *
def prisms(eta):
 diff=np.array([p-q for p in W for q in W]);dd=diff[ConvexHull(diff).vertices]
 pp=[]
 for i in range(len(dd)):
  pp.append(np.linalg.solve(np.array([dd[i],dd[(i+1)%len(dd)]]),np.ones(2)))
 pp=np.array(pp);pp=pp[ConvexHull(pp).vertices]
 qmid=(U[0]+U[1])/2;qdiff=U[1]-U[0];qmatrix=np.array([qdiff,qmid]);out=[]
 for sign in [-1,1]:
  for i in range(len(pp)):
   tilts=[(sign,np.zeros(2)),(0.,pp[i]),(0.,pp[(i+1)%len(pp)])]
   verts=[]
   for mu in [eta,1-eta]:
    for x,w in tilts:
     const=mu-abs(x)/2-max(W@w);q=np.linalg.solve(qmatrix,[x,const]);verts.append(np.r_[q,w])
   verts=np.array(verts)
   assert max(abs(np.ptp(FV@verts.T,axis=0)-1))<1e-9
   out.extend([verts[[0,1,2,5]],verts[[0,1,4,5]],verts[[0,3,4,5]]])
 return out

