# Consolidate the new mathematics into msc-math and its selected thesis

This is an execution assignment for Codex with repository access. Independently
check the returned mathematics, integrate supported results into their normal
repository homes, and revise/build the selected thesis so a human reader sees
the strongest relevant statements and their shortest sound proofs. Preserve
specialized/alternative ideas in the repository, not repeated in the PDF.

Read prompt.md, CLAIM_LEDGER.md, and EDITORIAL_MAP.md. Input ZIPs are immutable
provenance under incoming/. The current session also supplied a new local-cover
certificate and a small cut-lifting deduction; review them before promotion.
Do not reopen a solved affine-orbit search or claim the global conjecture or
full F=11 theorem is proved. Deliver actual edits, a built PDF, and a concise
review/result ledger; no plan-only completion.
