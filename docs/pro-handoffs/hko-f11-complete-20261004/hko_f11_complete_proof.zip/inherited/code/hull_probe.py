from fastbank import *
import argparse
p=argparse.ArgumentParser();p.add_argument('--rounds',type=int,default=4);p.add_argument('--out',default=str(WORK/'hull_state'));args=p.parse_args()
tic=time.perf_counter();dat=np.load(str(WORK/'enriched.npz'));bank=FastBank(None,dat['G'],dat['C'])
rng=np.random.default_rng(78319);ds=np.vstack([np.eye(4),-np.eye(4),rng.normal(size=(40,4))]);points={};weights={};stats=[]
for d in ds:
 s,l=bank.support(d);c=bank.C.T@l;k=tuple(np.round(c,10));points[k]=c;weights[k]=[(i,float(x)) for i,x in enumerate(l) if x>1e-10]
misscache={}
for it in range(args.rounds):
 pp=np.array(list(points.values()));h=ConvexHull(pp);fac={tuple(np.round(eq,9)):eq for eq in h.equations};bad=[];new=0;failed=0;queries=0
 for eq in fac.values():
  d=eq[:4];v=vol(d);b=-eq[4]
  if v<=b+1e-8:continue
  vk=tuple(np.round(d,9));vals=FV@d;mu=max(vals)/(max(vals)-min(vals))
  if vk in misscache:s,c,l=misscache[vk]
  else:
   s,l=bank.support(d);c=bank.C.T@l;queries+=1
  if s<v+1e-8:
   misscache[vk]=(s,c,l);failed+=1
  if s>b+1e-8:
   k=tuple(np.round(c,10))
   if k not in points:new+=1;points[k]=c;weights[k]=[(i,float(x)) for i,x in enumerate(l) if x>1e-10]
  bad.append(dict(D=d.tolist(),mu=mu,volume=v,inner=b,bank_support=s,gap=s-v))
 st=dict(iteration=it,points=len(pp),facets=len(fac),violated=len(bad),bank_failures=failed,queries=queries,new_points=new,seconds=time.perf_counter()-tic)
 stats.append(st);print(st,flush=True)
 json.dump(dict(stats=stats,points=[dict(c=points[k].tolist(),weights=weights[k]) for k in points],bad=bad),open(args.out+'.json','w'),indent=2)
 if new==0:break
