from pathlib import Path
Path("report.html").write_text("<!doctype html><title>Report</title><h1>Build status</h1><p>Sample report for handoff fixture.</p>")
