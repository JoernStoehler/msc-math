# Final clean-extraction verification

On 24 September 2026 the complete mathematical checking pipeline was run from a separate archive extraction. All seven stages passed. Total observed elapsed time was **217.321 seconds**.

| Stage | Result | Seconds |
|---|---|---:|
| `inherited_ridges` | PASS | 4.404 |
| `inherited_endpoints` | PASS | 7.084 |
| `core` | PASS | 146.477 |
| `collar` | PASS | 36.233 |
| `reject_missing_core_leaf` | PASS | 0.822 |
| `reject_negative_policy_weight` | PASS | 0.656 |
| `reject_false_polynomial_bound` | PASS | 21.645 |

The three negative controls deliberately remove a coverage leaf, introduce a negative policy mass, and replace the valid comparison constant by a false one. Each was rejected at the intended predicate, not merely by an unrelated execution error. No success output was created for the corrupted run.

Commands, stdout/stderr, return codes, per-stage timing, interpreter, platform and exact mathematical output are retained in `evidence/clean_replay/`. `evidence/verified_code_data_sha256.json` records the hashes of proof code and data, which were compared byte-for-byte between that extraction and this final archive source. Subsequent additions are reports and numerical discovery logs; no mathematical acceptance code or input changed.

The optional portable numerical policy search was separately rerun: all twenty LPs returned positive sampled margins in 26.61 seconds. This is a discovery reproduction, not an additional universal proof. Its output is `discovery/evidence/portable/`.

The exact checkers reconstruct the declared finite predicates and complete coverings. Their implication for local maximality is PROOF.md, with its explicit accepted ten-facet input and inherited endpoint/other-face lemmas. No external mathematical review or proof-assistant formalization is claimed. Literal derivative checks and independent integration identities are additional implementation checks, not a claim that a second team independently proved the theorem.
