# The exact remaining blocker and the final Hausdorff implication

## 1. What remains after Theorem E

The main \(F\leq11\) local-maximality theorem is **not proved or falsified**
by this return. Theorem E excludes every improving sequence with a duplicate
limit and \(\mu\to0\) or 1. The remaining assertion is the following actual
neighborhood statement, not merely a statement about linear paths:

> In a normalized duplicate chart, exclude improving bodies with \(r,t\to0\),
> \(r=O(t)\), and \(\mu\) in a compact subinterval of \((0,1)\), uniformly over
> all split directions and all normalized old-normal motions.

This is **one compact interior coupled-split problem**. Possible interior
zero-margin directions and any higher-order behavior along them belong to
this same blocker; they have not been classified or excluded.

To make the compactness precise, failure of the original theorem, together
with the supplied completed cases and Theorem E, would produce a sequence
with

\[
 0<\eta\leq\mu_n\leq1-\eta,\qquad
 r_n\leq M t_n,\qquad
 D_n\to D,\quad H_n/t_n\to h                             \tag{H1}
\]

for some \(\eta>0\) and finite \(M\). Here \(D\) has oscillation 1 on \(F_H\),
and both its positive and negative extrema have magnitude at least \(\eta\).
The cap estimate and ten-facet sharpness give \(r_n\leq Mt_n\); the normalized
slice and bounded facet vertex values then give the displayed convergent
subsequences. Neither the existence of a collar nor this compactness proves
that the remaining interior is covered.

## 2. A necessary limiting system and a sufficient certificate

For any fixed positive rank-five stationary touching section \(k\), feasible
continuation gives, uniformly on bounded directions,

\[
 S\leq G_k\cdot H+t[v(D)-c_k\cdot D]+O((r+t)^2).           \tag{H2}
\]

The derivative of the extra normal induced by moving old \(a_0\) must be
aggregated into \(G_k\); these are the same conventions checked by the
supplied packet and the new exact workspace. On a sequence (H1), improvement
and (H2) imply the necessary inequalities

\[
 G_k\cdot h+v(D)-c_k\cdot D\geq0
        \quad\hbox{for every such touching section }k.   \tag{H3}
\]

It is enough to show that this system has no solution with \(D\) genuinely
sign-changing and \(h\) in the old-normal transverse slice. A particularly
usable sufficient condition is, for every such \(D\), a finite relation

\[
 \lambda_k\geq0,\quad\sum\lambda_k=1,\quad
 \sum\lambda_kG_k=0,\qquad
 \left(\sum\lambda_kc_k\right)\cdot D>v(D).               \tag{H4}
\]

The chosen sections and weights may depend on \(D\). This condition is **not
asserted to be necessary for the true local-maximality theorem**. Failure
of this particular certificate route would not settle the capacity problem.
Nor is it proved here for every interior \(D\).

If (H4) were proved pointwise on the interior, strictness and continuity would
give an open directional neighborhood for each of its certificates. The
compact set in (H1) would admit a finite subcover. The resulting finite
sections would have one common feasibility radius and a positive minimum
margin. Averaging (H2), using \(r\leq Mt\), would then give
\(S\leq-mt+O(t^2)<0\). Thus **Theorem E removes the redundant-endpoint
uniformity obstruction to this final compactness step**. It does not supply
its missing hypothesis (H4). If interior equality cases replace strictness,
they require an actual additional relative or higher-order argument.

## 3. What the computation does and does not establish

The supplied 147-section bank was checked exactly. Its global-containment
failure is now proved both structurally, for every finite bank of this type,
and by the exact witness in `FINITE_BANK_OBSTRUCTION.md`.

The new exploration generated a 5,570-row numerical bank by flat insertions
into the supplied seeds and by splitting/interchanging the duplicate. Its
710 distinct cyclic word types admit **exactly verified continuous touching
families**: 80 of dimension zero, 322 of dimension one, and 308 of dimension
two. This is not an enumeration of all HKO minimizers.

For each word, the checker reconstructs an exact positive touching weight
vector \(\beta_0\). On \(\ker C\), the weight Hessian is checked to be negative
semidefinite of rank one. Its kernel gives an exact matrix \(T\), and

\[
 \{\beta=\beta_0+Tz:\beta\geq0\}                         \tag{H5}
\]

is a compact interval, polygon, or point on which closure, normalization and
\(Q=Q_H\) hold identically. These full weight families, not only sampled
weights, are supplied in `data/continuous_families.json`.

The numerical column-generation method optimizes the dual reduced cost over
these parameter polytopes. Gradients are quadratic in \(z\). On an interval,
check endpoints and a feasible concave-quadratic stationary point. On a
polygon, check vertices, stationary points on edges, and an interior negative-
definite quadratic stationary point. This covers all possible maxima: a
nonconcave interior stationary point is not a strict maximum; a singular
flat maximum reaches the boundary. The implemented pricing, nullspaces,
polygon vertices, master LPs, and margins use floating point. Exact family
validity does not turn their numerical LP solutions into exact cancellation
certificates.

In the executed tests, all 22 negative directions found in the third round
of the inner-hull experiment were repaired by this continuous pricing. The
additional algebraic separating direction for the 147-row bank was also
repaired. The minimum final numerical margin among those 23 tests was about
\(1.762876\times10^{-4}\). Some seven-round tests stopped before the pricing
residual reached the requested threshold; their positive primal margins
are still numerical evidence, but no global optimality is claimed for them.

**The missing evidence is a universal interior inequality/cover, not another
selected positive LP.** No exhaustive exact containment certificate, validated
angular covering, or analytic comparison for all interior directions was
obtained. No lower bound on the capacity of an improving family was obtained.
The finite-bank separation and the numerical repairs must not be called a
counterexample or a proof of the target theorem.

## 4. Why this is the only Hausdorff blocker

Here is the final assembly, with its dependency left explicit. Suppose there
were improving convex four-polytopes \(K_n\to H\), each with at most eleven
genuine facets. All contain a common ball around the origin and lie in a
common outer ball. Their polars therefore converge to \(H^\circ\), and have
at most eleven vertices.

For each of the ten exposed vertices \(a_i\) of \(H^\circ\), choose an exposing
functional. A maximizing vertex of \(K_n^\circ\) for that functional converges
to \(a_i\): any different subsequential limit would also maximize that
functional on \(H^\circ\), contradicting unique exposure. Choose disjoint
neighborhoods of the ten vertices to make these ten labelled vertices distinct.
There is at most one remaining polar vertex. With none, the accepted ten-
facet theorem applies. With one, pass to a subsequence and write its limit
as \(b_*\in H^\circ\).

An interior limit is redundant. A limit in the relative interior of a polar
facet, triangle, or edge is excluded by the supplied completed neighborhood
theorems, which allow arbitrary old-normal motions. There is no use of
compactness of a punctured edge or of an unproved uniform endpoint radius.
The only other possibility is \(b_*=a_i\), a duplicate limit. HKO symmetry
reduces it to label 0, and the simultaneous local normalization leaves the
ratio unchanged.

The redundant cases reduce to at most ten genuine facets. In a genuine
split, Theorem E excludes either redundant-endpoint regime. The cap bound
and (E2) give the bounded scale ratio, so any surviving improving subsequence
has precisely the form (H1). A solution of the interior neighborhood blocker
would exclude it and complete the contradiction, proving one common
Hausdorff neighborhood for all \(F\leq11\).

Conversely, none of the results in this return excludes all sequences of
form (H1). This is exactly where the final Hausdorff proof stops. There is
no scheduled continuation or assumption of another research call.
