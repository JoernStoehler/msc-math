# Build cache policy

Keep cache directories out of tracked source. Select writable cache paths from the current runtime environment, not a previous machine. The build script honors `CARGO_TARGET_DIR`; when it is unset, it uses `${XDG_CACHE_HOME:-${TMPDIR:-/tmp}}/handoff-example/cargo-target`.
