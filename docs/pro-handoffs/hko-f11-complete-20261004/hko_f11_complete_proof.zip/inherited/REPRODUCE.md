# Reproduce the checks and the new experiments

## Exact checks: Python standard library only

Run from the ZIP's extracted root. Use fresh output paths for repeat runs.

```sh
python code/exact_core.py --data data --out work/baseline.json
python code/check_new.py --out work/new_checks.json
python code/check_families.py --out work/family_checks.json \
    --families work/reconstructed_families.json
python code/negative_controls.py --out work/negative_controls
```

The first command replays the supplied independent finite audit. The second
checks all endpoint contact/cancellation identities at duplicate a0 and the
exact 147-row separation. The third reconstructs all 710 families from exact
seeds and rational insertion fractions, checks the rank-one restricted Hessian
and all flat-family identities, and checks equality with the retained exact
family data. The last command must detect both deliberate corruptions.

The analytic uniform-neighborhood argument is in `math/ENDPOINTS.md`; arithmetic
checks alone are not that theorem. These are not proof-assistant checks.

## Replay the continuous-weight experiment

The executed numerical environment used Python 3.13.5, NumPy 2.3.5 and SciPy
1.17.0. Optional dependencies are pinned in `requirements-numeric.txt`.
The persistent LP wrapper uses SciPy 1.17.0's bundled private HiGHS interface;
other SciPy versions may require adapting `fastbank.py`.

```sh
python -m pip install -r requirements-numeric.txt
python code/prepare_numeric.py
OPENBLAS_NUM_THREADS=1 python code/continuous_batch.py
```

`prepare_numeric.py` copies the retained bank and targeted hull state to `work/`
and refuses to overwrite existing inputs. Set `HKO_WORK` to a fresh directory
to select another workspace. The batch runs the 22 negative third-round hull
directions and the additional algebraic separation direction. It writes
`work/continuous_batch.json`, including the final primal numerical witnesses,
full cancellation residuals, and pivot conditioning. Packaged discovery and
replay outputs are in `evidence/continuous_batch.*` and
`evidence/continuous_replay.*`, respectively.

The exact family domains are valid; the LP solutions, pricing coordinates,
residuals and directional margins are floating-point calculations. No universal
coverage follows from this replay. Some seven-round runs stop with unresolved
pricing residuals; the output records them.

## Regenerate the sampled bank and exploratory coverage tests

In a separate fresh `HKO_WORK`, run:

```sh
OPENBLAS_NUM_THREADS=1 python code/explore.py
OPENBLAS_NUM_THREADS=1 python code/enrich.py
OPENBLAS_NUM_THREADS=1 python code/fastbank.py
OPENBLAS_NUM_THREADS=1 python code/hull_probe.py --rounds 3
OPENBLAS_NUM_THREADS=1 python code/continuous_batch.py
```

The first script generates the exact 147-row starting bank from the retained
input data, then performs the initial numerical panel. The second regenerates
the 470 old-weight samples and 5,570 duplicate rows and repeats that panel.
The third performs a separate seeded 400-direction draw (362 genuinely split
cases). The fourth grows an inner hull for three rounds. The last repairs its
negative directions using complete continuous weight polytopes of the retained
710 word types.

The numerical generator used tolerances to discover flat insertions. Do not
accept tolerance tests as algebraic proofs. `check_families.py` is the separate
exact reconstruction step that validates the retained word families. The
sampled bank and hull are not claimed complete; new LP bases can differ by
solver version even when support values agree.

## Integrity

`PROVENANCE.json` records the uploaded ZIP hash, reused source hashes, and the
public primary references checked during this attempt. `MANIFEST.sha256`
covers every other packaged file. Verify it on systems with `sha256sum` using:

```sh
sha256sum -c MANIFEST.sha256
```

Measured discovery and verification durations are in `evidence/COSTS.json`.
They are records of actual runs, not runtime guarantees.
