# Draft brief for an independent human mathematical review

Purpose: ask for a targeted correctness/novelty assessment after canonical
repository integration, not imply acceptance or request a review of raw logs.
No message has been sent.

## Main theorem 1: suboptimal local-maximizing family

There is a rational simple ten-facet hexagon/quadrilateral product at rho=1,
with a two-dimensional local equality family modulo continuous symmetries and
strict transverse decrease under ALL nearby ten-facet deformations. The proof
uses 24 touching HK feasible sections, rank 22, a positive relation, a full
40-dimensional coordinate check and one negative quadratic upper-section
coefficient. Product capacity equality is independently established on the
family. The theorem refutes uniqueness of ten-facet local maxima, not Viterbo's
inequality or HKO global optimality.

Main review question: uniform local equality/curvature argument, especially
continuation of the kernel and feasibility off the product family.

## Main theorem 2: affine HKO optimality and rigidity

Every GL(4) image of the regular pentagon-product affine shape has rho<=rho_H.
Equality is one conformal symplectic class; anti-symplectic copies add no new
body class because HKO has an anti-symplectic self-symmetry. Two independent
proof routes are available: a short explicit-word/averaging argument and a
larger six-dimensional polytope/polarized-Pfaffian certificate. A compactness
corollary gives a ten-facet shape neighborhood uniform over all affine positions.

Main review question: the general-skew HK bound, sharpness and equality, and
novelty relative to existing affine-position work. The shorter proof should be
sent first, with the other available as corroboration.

## Additional result needing fresh review

A newly derived positive-marginal area certificate gives local rigidity of the
ten normal-triangle HKO cover, hence local maximality among arbitrary convex
partners of a FIXED regular pentagon. The finite algebra is checked exactly.
The key geometric step is a local signed-polygon lower estimate with O(r^2)
error; an elementary small-loop deletion proof is supplied. This is neither a
global partner theorem nor full four-dimensional local maximality.

## Do not conflate

Computer-assisted proof, independent exact-arithmetic implementation, independent
mathematical reading, human referee acceptance, and proof-assistant formalization
are different statuses. None of the packets claims the all-body HKO conjecture
or a complete F=11 theorem. Earlier restricted capacity formulas may contain
information beyond the new upper-bound theorem.

After integration, replace archive-relative pointers by permanent proof and
verifier paths/commit before using this brief.
