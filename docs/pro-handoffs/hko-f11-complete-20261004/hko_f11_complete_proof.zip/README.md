# Complete HKO eleven-facet proof packet

## Read in this order

- `RESULT.md`: exact scope and new contributions.
- `PROOF.md`: the entire closing argument and explicit accepted inputs.
- `math/CORE_THEOREM.md`, `math/COLLAR_THEOREM.md`: mapping from mathematics to finite predicates.
- `FINAL_VERIFICATION.md`: clean-extraction acceptance and input identities.
- `RESEARCH_COSTS.md`: measured work, failed restricted methods, and what was actually expensive.
- `INTEGRATION.md`: how to update the project without overstating the result.

## Verify

From this directory, using Python 3.11 or newer:

```sh
python run_checks.py --out /tmp/hko-f11-fresh --negative-controls
```

The output directory must not already exist. Verification uses the Python standard library only. The optional discovery files use NumPy/SciPy/SymPy; they are not part of proof acceptance. Interpreter/version and stage times are in the actual output logs. No CPU-hour or time limit needs changing to run the proof checks.

For the new parts separately:

```sh
python core/verify.py --out /tmp/hko-f11-core.json
python collar/verify.py --out /tmp/hko-f11-collar.json
```

A PASS checks the stated finite predicates. The implication from them to the theorem is the written proof, not a claim to have formally verified the mathematics in a proof assistant.

## Contents and trust boundaries

`core/` contains exact positive rows, convex relations, the full dyadic covering tree, and a standard-library checker. Every candidate is recomputed, not accepted from a floating-point hint.

`collar/` contains the exact weight paths, polynomial mixture data, twenty response functions, exact sign-cell geometry, subdivision trees, and integer coefficient verification. The geometry enumerates every cell rather than trusting a numerical hull.

`inherited/` preserves the earlier endpoint proof and finite data. `inherited/previous_math/` contains the earlier ridge and lifting proofs. The sharp F=10 theorem is an accepted input, not a new result claimed here.

`source/` preserves the original return ZIPs byte-for-byte. `evidence/` and each code packet's `evidence/` preserve actual executed outputs. Historical paths and elapsed times inside old logs have not been rewritten.

`discovery/` contains selected new proposal scripts and their records. They illustrate how the certificates were found; their numerical outputs are not proof premises. Reproducing the exact theorem does not require rerunning them or enumerating all 710 previously stored families.

All mathematical arithmetic is in Q(tau), tau^4 - 10 tau^2 + 5 = 0, 0<tau<1. JSON field coefficients are in descending powers, as defined by `encoded`/`decode`; internal integer arithmetic uses ascending coefficients. Normal and vertex labels are zero-based.

This packet does not update a GitHub repository, start a new Pro session, or schedule work. It supplies a finished mathematical result for review and integration.
