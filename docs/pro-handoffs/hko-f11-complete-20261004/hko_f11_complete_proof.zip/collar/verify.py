#!/usr/bin/env python3
"""Exact continuous-weight collar proof. Standard library, no optimizer/network.
Checks polynomial feasible response policies, the entire sign-cell arrangement,
and all homogeneous simplex coefficients. See ../math/COLLAR_THEOREM.md.
"""
import argparse,hashlib,json,platform,random,sys,time
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(HERE/'code'));sys.path.insert(0,str(ROOT/'core/code'))
from exact_tools import a,ZERO,ONE,calc_exact,encoded,volume_response
from polynomial import Checker
import integer_bernstein as ip

def verify_policies(data,negative=None):
 tic=time.perf_counter();load=lambda p:json.loads(p.read_text());raw=load(data/'policies.json');families=load(ROOT/'core/data/families.json')['families'];anc=load(ROOT/'core/data/anchor.json');seeds=load(ROOT/'core/data/old_seeds.json')
 if negative=='negative_weight':raw['policies'][0]['paths'][0]['weight']='-1'
 a.require(raw['eta']=='1/10','policy scale');a.require(sorted(p['cone'] for p in raw['policies'])==list(range(20)),'all twenty policies')
 for p in raw['policies']:
  a.require(all(F(t['weight'])>=0 for t in p['paths']),'nonnegative path weight')
 oldG=[calc_exact(r['sigma'],[a.VALUES[x] for x in r['weights']])[0] for r in seeds];a.require(oldG==[[a.decode(x) for x in r] for r in anc['G']],'anchor gradients rederived');ow=list(map(a.decode,anc['weights']));E=[[ONE]*65]+list(map(list,zip(*oldG)));ci=anc['column_indices'];sub=[[E[k][i] for i in ci] for k in range(41)];a.require(all(a.sign(x)>0 for x in ow) and a.mv(E,ow)==[ONE]+[ZERO]*40,'positive old anchor')
 fv=[u+w for u in a.U[:2] for w in a.W];paths={};crosschecks=0
 for it in raw['paths']:
  f=families[it['family']];sig=f['sigma'];base=list(map(a.decode,f['beta']));T=[list(map(a.decode,r)) for r in f['directions']];z0=list(map(a.decode,it['start_parameters']));frac=F(it['fraction']);a.require(len(T)==len(z0) and 0<frac<=1,'exact affine path definition');a.require(10 in sig and len(set(sig))==len(sig),'new normal appears once')
  start=[base[k]+sum((z*t[k] for z,t in zip(z0,T)),ZERO) for k in range(len(base))];end=a.add(a.scale(ONE-a.K(frac),start),a.scale(a.K(frac),base));mid=a.scale(a.K(F(1,2)),a.add(start,end));a.require(all(a.sign(x)>=0 for x in start) and start[sig.index(10)]==ZERO,'collapsed nonnegative start');a.require(all(a.sign(x)>0 for x in end),'strictly positive endpoint')
  G=[];C=[]
  for beta in [start,mid,end]:
   a.require(a.qeval(a.A+[a.A[0]],sig,beta)==a.Q0,'constant quadratic at three interpolation nodes');g,c,_=calc_exact(sig,beta,f['pivot'],check=all(a.sign(x)>0 for x in beta));G.append(g);C.append(c)
  # The two positive points establish the affine constraint/stationarity identities;
  # the third objective value establishes the full constant quadratic.
  a.require(C[0]==[ZERO]*4,'zero response at collapsed start');c1=a.add(a.scale(4,C[1]),a.scale(-1,C[2]));c2=a.add(a.scale(2,C[2]),a.scale(-4,C[1]));v=it['vertex'];a.require(0<=v<10 and c1==a.scale(4*end[sig.index(10)],fv[v]),'specified vertex contact');a.require(a.dot(c2,a.A[0])==ZERO,'second response has no radial term')
  gb=[G[0],a.add(a.scale(2,G[1]),a.scale(a.K(F(-1,2)),a.add(G[0],G[2]))),G[2]];key=(it['family'],it['start_vertex'],it['fraction']);a.require(key not in paths,'unique path key');paths[key]=(gb,c1,c2)
  if len(paths)%83==0:
   sec=a.Section(a.A+[a.A[0]],sig,mid,f['pivot']);gq=sec.gradient();agg=[x[:] for x in gq[:10]];agg[0]=a.add(agg[0],gq[10]);gg=[-2*x/a.Q0-a.VOL_GRAD[j]/a.V0 for j,x in enumerate(sum(agg,[]))];a.require(gg==G[1] and a.scale(2/a.Q0,gq[10])==C[1],'literal midpoint derivative check');crosschecks+=1
 print('PASS',len(paths),'entire touching-weight paths',flush=True)
 maxmix=ZERO
 for po in raw['policies']:
  bern=[[a.decode(x) for x in row] for row in po['old_bernstein']];a.require(len(bern)==31 and all(len(r)==65 for r in bern),'Bernstein weight dimensions');a.require(all(a.sign(x)>=0 for r in bern for x in r),'all old Bernstein coefficients nonnegative');coef=[[ZERO]*65 for _ in range(21)];coef[0]=bern[0][:]
  for v in range(10):
   q0,q1,q2=bern[1+3*v:4+3*v];coef[0]=a.add(coef[0],q0);coef[1+2*v]=a.add(a.scale(-2,q0),a.scale(2,q1));coef[2+2*v]=a.add(a.add(q0,a.scale(-2,q1)),q2)
  residual=[a.mv(E,r) for r in coef];residual[0][0]-=ONE;av=[ZERO]*10;bv=[[ZERO]*4 for _ in range(10)]
  for it in po['paths']:
   lam=a.K(F(it['weight']));gb,c1,c2=paths[(it['family'],it['start_vertex'],it['fraction'])];v=it['vertex'];a.require(c1==a.scale(a.dot(c1,a.A[0]),fv[v]),'policy uses the correct vertex parameter')
   residual[0]=a.add(residual[0],a.scale(lam,[ONE]+gb[0]));residual[1+2*v]=a.add(residual[1+2*v],a.scale(lam,[ZERO]+a.scale(2,a.add(gb[1],a.scale(-1,gb[0])))));residual[2+2*v]=a.add(residual[2+2*v],a.scale(lam,[ZERO]+a.add(a.add(gb[0],a.scale(-2,gb[1])),gb[2])))
   av[v]+=10*lam*a.dot(c1,a.A[0]);bv[v]=a.add(bv[v],a.scale(100*lam,c2))
  delta=[[a.decode(x) for x in r] for r in po['correction']];a.require(len(delta)==21 and all(len(r)==26 for r in delta),'correction dimensions')
  for e,d in zip(residual,delta):a.require(a.mv(sub,d)==a.scale(-1,e),'all 41 polynomial coefficient identities')
  mix=a.decode(po['mix']);a.require(a.sign(mix)>=0 and a.sign(ONE-mix)>0,'convex anchor mixing')
  for j,col in enumerate(ci):
   bound=sum((a.K(a.sign(r[j]))*r[j] for r in delta),ZERO);a.require(a.sign(mix*ow[col]-(ONE-mix)*bound)>=0,'uniform positivity for all independent s_v in [0,1]')
  av=a.scale(ONE-mix,av);bv=[a.scale(ONE-mix,r) for r in bv];a.require(av==list(map(a.decode,po['av'])) and bv==[list(map(a.decode,r)) for r in po['bv']],'response polynomial reconstructed exactly')
  if a.sign(mix-maxmix)>0:maxmix=mix
 print('PASS twenty complete polynomial cancellation policies',flush=True)
 return dict(paths=len(paths),policies=20,literal_gradient_crosschecks=crosschecks,maximum_anchor_mix_nominal=a.nominal(maxmix),seconds=time.perf_counter()-tic)

def verify_inequalities(data,negative=None):
 tic=time.perf_counter();trees=json.loads((data/'trees.json').read_text());a.require(sorted(t['cone'] for t in trees)==list(range(20)),'all twenty directional cones present');results=[];comparisons=0
 rng=random.Random(91027)
 for _ in range(500):
  x=tuple(rng.randrange(-10**18,10**18) for _ in range(4));a.require(ip.sign(x)==a.sign(a.K(x)),'independent integer field-sign formula')
 for tr in trees:
  cone=tr['cone'];ch=Checker(cone)
  if negative=='false_bound':ch.gamma=a.K(10);ch.gi=ip.convert(ch.gamma,ch.pden)
  roots=[r['vertices'] for r in ch.geo['roots']];nodes=tr['nodes'];coords={};pending=list(range(len(roots)));seen=set();leaves=set();zeros=0;coefficient_count=0
  while pending:
   n=pending.pop();a.require(0<=n<len(nodes) and n not in seen,'unique tree visit');seen.add(n);nd=nodes[n]
   if 'root' in nd:a.require(n<len(roots) and nd['root']==n,'root identity');X=roots[n]
   else:a.require(n>=len(roots) and n in coords,'reachable child');X=coords[n]
   if 'children' in nd:
    i,j=nd['edge'];a.require(0<=i<4 and 0<=j<4 and i!=j,'nontrivial edge');mid=a.scale(a.K(F(1,2)),a.add(X[i],X[j]));a.require(len(nd['children'])==2,'two children')
    for child,k in zip(nd['children'],[i,j]):
     a.require(nodes[child].get('parent')==n and nodes[child].get('replace')==k,'child incidence');Y=[p[:] for p in X];Y[k]=mid;coords[child]=Y;pending.append(child)
   else:
    leaves.add(n);cs=ch.coefficients(X);sg=list(map(ip.sign,cs));a.require(min(sg)>=0,'nonnegative exact homogeneous coefficients');coefficient_count+=len(cs);zeros+=sum(s==0 for s in sg)
  a.require(len(seen)==len(nodes) and leaves==set(tr['passed']) and len(leaves)==len(tr['passed']),'every part of every sign cell covered')
  # Exact independent Fubini / vertex-cone formula / barycentric polynomial checks.
  for cell in ch.geo['cells']:
   X=cell['tetrahedra'][0];cs=ch.coefficients(X);den=ch.last_denominator;x=[sum((v[k] for v in X),ZERO)/4 for k in range(3)];D=ch.D([x])[0];values=[a.dot(D,v) for v in ch.fv];response=sum((z*z*(av+a.dot(bv,D)) for z,av,bv in zip(values,ch.av,ch.bv) if a.sign(z)>0),ZERO);ls=[a.dot(D[2:],e)*sg for e,sg in zip(ch.edges,ch.sgn)];div=x[0]
   for ell in ls:div*=ell
   a.require(a.sign(div)>0,'comparison point has positive denominator');vnum=ZERO
   for k,z in enumerate(values):
    if a.sign(z)<=0:continue
    prod=ONE
    for j in range(5):
     if j not in [k%5,(k-1)%5]:prod*=ls[j]
    vnum+=ch.vcoeff[k]*z**4*prod
   vv=volume_response(D);a.require(vnum/div==vv,'exact Fubini equals planar vertex-cone integral')
   pp=sum((a.K(z) for z in cs),ZERO)/(den*4**9);a.require(pp==div*(response-vv-ch.gamma*x[2]**2),'integer polynomial equals direct rational comparison');comparisons+=1
  result=dict(cone=cone,sign_cells=len(ch.geo['cells']),root_tetrahedra=len(roots),leaves=len(leaves),coefficients=coefficient_count,zero_coefficients=zeros);results.append(result);print('PASS collar cone',cone,':',len(leaves),'tetrahedra',flush=True)
 return dict(cones=results,exact_fubini_polynomial_comparisons=comparisons,field_sign_crosschecks=500,margin='mu^2/1000',seconds=time.perf_counter()-tic)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--negative-control',choices=['negative_weight','false_bound']);q=p.parse_args();a.require(not q.out.exists(),'fresh output path');tic=time.perf_counter();pol=verify_policies(HERE/'data',q.negative_control);ine=verify_inequalities(HERE/'data',q.negative_control)
 out=dict(passed=True,scope='All normalized directions with 0<mu<=1/10. Response polynomials lie in the closure of the valid cancellation-response set. Strict domination implies genuine positive-section witnesses pointwise.',policies=pol,inequalities=ine,seconds=time.perf_counter()-tic,python=sys.version,platform=platform.platform(),dependencies='Python standard library only',data_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for d in [HERE/'data',ROOT/'core/data'] for p in sorted(d.glob('*.json'))})
 q.out.parent.mkdir(parents=True,exist_ok=True);q.out.write_text(json.dumps(out,indent=2)+'\n');print('ALL COLLAR CHECKS PASSED',out['seconds'],'seconds',flush=True)
if __name__=='__main__':main()
