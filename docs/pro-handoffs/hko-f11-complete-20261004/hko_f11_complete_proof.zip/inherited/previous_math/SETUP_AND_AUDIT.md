# Setup, accepted input, and audit of the supplied reductions

## 1. Status and conventions

The accepted ten-facet sharpness theorem is an input, not a conclusion of this
packet. The new results are the complete **35 open-polar-edge charts** in
`RIDGE_NEIGHBORHOODS.md` and an explicit, fully coupled **angular sector of a
duplicate-normal chart** in `FACET_SECTOR.md`. The full eleven-facet theorem is
not proved or falsified. The exact unresolved parameters are in `BLOCKER.md`.

Write

\[
 P(A)=\{x\in\mathbb R^4:a_i\cdot x\leq1,\ 0\leq i<10\},\qquad
 K(A,b)=P(A)\cap\{b\cdot x\leq1\}.
\]

All these bodies contain a common ball and are uniformly bounded in the local
charts under discussion. Let

\[
 \omega(x,y)=x_0y_2+x_1y_3-x_2y_0-x_3y_1,\quad
 \tau=\sqrt{5-2\sqrt5},\quad Q_0=\tau/5,
\]
\[
 c_0=1/(2Q_0),\quad V_0=25(5+\sqrt5)/32,\quad
 \rho_0=c_0^2/(2V_0)=(3+\sqrt5)/5.
\]

The exact normal array is `A` in `code/algebra.py`. It is reproduced here to fix
all labels. Put \(\alpha=(3-\sqrt5)/2\),
\(\eta=\tau(1+\sqrt5)/2\), and \(\ell=\sqrt5-1\). Then

\[
\begin{array}{ll}
a_0=(1,\tau,0,0),&a_5=(0,0,\tau,-1),\\
a_1=(-\alpha,\eta,0,0),&a_6=(0,0,\eta,\alpha),\\
a_2=(-\ell,0,0,0),&a_7=(0,0,0,\ell),\\
a_3=(-\alpha,-\eta,0,0),&a_8=(0,0,-\eta,\alpha),\\
a_4=(1,-\tau,0,0),&a_9=(0,0,-\tau,-1).
\end{array}
\]

Let \(U_i=(\cos(2\pi i/5),\sin(2\pi i/5))\) and
\(W_i=((U_i)_1,-(U_i)_0)\). The primal vertices, in code order, are
\(v_{5i+j}=U_i+W_j\), where the plus denotes concatenation into four
coordinates. Thus \(P_0=P(A_0)=\operatorname{conv}(U)\times
\operatorname{conv}(W)\). The exact code uses algebraic coordinates, not
trigonometric approximations.

The relative-ratio variable below is
\(S(A,b)=\rho(K(A,b))/\rho_0-1\). Constants called \(C,L,a,\kappa\)
may change between displayed estimates; each is positive and uniform in the
particular neighborhood being proved.

## 2. Precisely what is accepted from F=10

After the accepted local normalization by translations, linear symplectic
maps, and positive dilations, put \(H=A-A_0\), \(r=\|H\|\). The input is

\[
 \rho(P(A))/\rho_0-1\leq-\kappa r.                 \tag{A1}
\]

The normalization is applied to the entire body, including the extra
inequality. It is a smooth local change of charts and leaves the ratio
unchanged. Consequently a genuine neighborhood theorem in the normalized
chart gives one in the full chart. We do not identify zero-slope directions
in the duplicate-normal coordinates with a linear space.

The derivative used in the certificate algebra is

\[
 DV(A_0)[H]=-v_*\sum_{i=0}^9 a_i\cdot H_i,
 \qquad v_*=25/32+5\sqrt5/16.                       \tag{A2}
\]

This can also be obtained directly from the facet integral. Every facet is
an edge times the other pentagon. Its centroid in the nonzero normal plane
is \(a_i/\|a_i\|^2\), its centroid in the other plane is zero, and its
three-volume divided by \(\|a_i\|\) is
\(\operatorname{area}(U)\sin(2\pi/5)\). The checker verifies the resulting
algebraic coefficient. Stability of the simple old polytope gives
\(V(P(A))=V_0+DV[H]+O(r^2)\).

Neither (A1), its 26 original sections, nor its quotient-rank theorem is
reproved here. In particular the new proof does not substitute an affine
orbit result for the requested eleven-facet problem.

## 3. Why every feasible section is a valid upper bound

For a word \(\sigma\) and weights satisfying

\[
 \beta\geq0,\qquad\sum\beta_i=1,\qquad
 \sum\beta_i a_{\sigma_i}=0,
\]

set
\[
 Q=\sum_{i<j}\beta_i\beta_j
       \omega(a_{\sigma_i},a_{\sigma_j}).
\]
A closed piecewise-affine loop with successive velocities
\(a_{\sigma_i}\), held for times \(\beta_i\), has all velocities in
\(K^\circ\). In the polar-loop dual action principle, its action integral,
with the orientation chosen here, is exactly \(Q\): on each segment the
self-pairing vanishes, leaving precisely the ordered cross terms. Hence

\[
 c_{\rm EHZ}(K)\leq\frac1{2Q},\qquad
 \frac{\rho(K)}{\rho_0}\leq
 \left(\frac{Q_0}{Q}\right)^2\frac{V_0}{V(K)}.       \tag{A3}
\]

This argument only uses membership of the velocities in the polar. It
therefore permits repeated normals and normals that are not genuine
facets. The external input is Haim-Kislev, *On the symplectic size of convex
polytopes*, Remark 1.4; Theorem 1.1 has the equivalent finite formulation for
distinct facets, with order reversed if necessary. No lower capacity bound
is inferred from (A3).

Here is the smooth feasible-section construction used throughout. Set
\(C=(a_{\sigma_i},1)\), with five rows, and choose an invertible five-column
minor \(C_I\). Hold all complementary weights fixed and solve

\[
 \beta_I=C_I^{-1}(e-C_{I^c}\beta_{I^c}),\qquad
 e=(0,0,0,0,1)^T.                                  \tag{A4}
\]

Strictly positive base weights and a nonsingular minor give a common
neighborhood of feasibility for each of the finitely many selected tests.
All positivity, closure, normalization, base objective, and stationarity
identities used in this packet are checked exactly.

If \(g_\beta=\nabla_\beta Q=C^T\lambda\), differentiating (A4) gives

\[
 (g_Q)_i=\beta_i\left[J
   \left(\sum_{j>i}\beta_j a_j-\sum_{j<i}\beta_j a_j\right)
   -\lambda_{0:4}\right],
\]
where \(J(q,p)=(p,-q)\) represents the displayed bilinear form.
The relative-ratio gradient is
\(G=-2g_Q/Q_0-DV/V_0\). This formula is what the verifiers reconstruct;
floating-point gradients are not trusted. Stationarity makes this first
derivative independent of which nonsingular pivot continues the same base
weights; different pivots may have different higher-order terms.

## 4. Audit of the supplied vertex/edge lifting

The supplied `code/hko_single_orbit_check.py` was rerun unchanged, in a copied
scratch tree. It verifies one positive six-weight word, rank five, its six
characteristic segments, the insertion derivative, and symplectic coverage
of all 25 primal vertices. A verbatim copy is included as
`code/verify_insertion.py`.

For each covered vertex \(v\), insert the new normal at its contact slot,
with weight \(z\), and correct the pivot weights by
\(-zC_I^{-1}(b,1)^T\). For fixed \(A_0\) the identity is

\[
 Q(b,z)=Q_0+2Q_0(v\cdot b-1)z+R_v(b)z^2.           \tag{A5}
\]

The remainder is a polynomial of degree at most two in \(b\). On a bounded
shell it is uniformly bounded. Choose a maximizing vertex, put
\(\delta_0=(h_{P_0}(b)-1)_+\), and take \(z=\mu\delta_0\) for a sufficiently
small common \(\mu>0\). Positivity persists and (A5) gives a capacity
improvement of order \(\delta_0^2\), uniformly. This is a lower bound on
capacity **loss**, obtained from an upper bound on the remaining capacity.
Cut subadditivity alone gives the opposite direction and cannot replace it.

For completeness, the supplied tube argument is valid with its stated
quantifiers. Fix \(b_0\) exposing a primal \(k\)-face \(F\). Simplicity makes
the labelled old face \(F(A)\) persist. All vertices outside this face are a
uniform positive support gap below the maximizing vertices, for nearby
\(A,b\). In a convex representation of a removed point, the total weight
on outside vertices is at most \(C\delta\), where
\(\delta=(h_{P(A)}(b)-1)_+\). The cap is therefore in a bounded
\(O(\delta)\)-tube of \(F(A)\), and

\[
 \Delta V\leq C\delta^{4-k}.                        \tag{A6}
\]

The estimate allows tilts, subface exposure, and redundant cuts; it is not a
radial formula. Monotonicity, (A1), and (A6) give
\(S\leq-\kappa r+C\delta^{4-k}\). Comparing the moving and fixed old bodies
at the same \(b\) gives, when \(k\leq1\),
\(S\leq Lr-a\delta^2\). The comparison is Lipschitz: multiplicative
inclusions with factors \(1+O(r)\) persist after intersecting with the same
halfspace containing the origin. Homogeneity and monotonicity bound both
capacity and volume. The two support depths differ by \(O(r)\).

Multiplying these inequalities by \(L+\kappa\) and \(\kappa\), respectively,
and adding gives a negative linear term in \(r\), a negative quadratic term
in \(\delta\), and a positive \(O(\delta^{4-k})\) term. Since \(4-k>2\),
the latter is absorbed in a common neighborhood. Thus the supplied lifting
correctly covers all charts exposing primal vertices and edges.

## 5. Audit of the old ridge evidence

The copied original scripts `uniform_edge_probe.py` and
`exact_edge_check.py` were rerun. All 65 seed/stationarity checks and the 20
old radial coefficient certificates passed. Their original claims remain
limited to radial extra normals, compact open-edge parameters, and the
stated scaled old-normal regime. They do not prove the new tilted-cap
comparison, endpoint uniformity, or any duplicate chart.

The new proof reuses their exact seed words and the same pivot-insertion
algebra, but adds vertex-resolved convex combinations, square quadrature,
a polynomial half-edge inequality, and an explicit full-coupling estimate.
The nine zero-pairing vertex contacts are also checked afresh. Original
certificate inputs were not overwritten: all original scripts were run in
a copied tree.

The supplied fixed-partner pentagon-cover theorem and affine-product work
are not used. No conclusion about general mixed four-dimensional cuts is
drawn from them.
