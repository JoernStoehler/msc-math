# Workstation report

Continue development and demonstrate the generated `report.html` artifact. Start with `AGENTS.md` and `docs/cache-policy.md`; run `bash scripts/build.sh` from the repository root. The build keeps Cargo output in a writable runtime cache and writes a portable HTML report to the checkout.
