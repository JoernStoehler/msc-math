# Independent audit: HKO ridge neighborhoods and one facet-splitting sector

**Date:** 24 September 2026  
**Input:** `hko_f11_proved_ridges_and_facet_sector(1).zip`  
**Verdict:** the returned statements are supported by their exact data and the supplied continuum arguments. I found no substantive gap. This is a mathematical/code audit, not external peer review, a priority determination, or proof-assistant formalization.

## Decision summary

The new theorem closes **every relative-interior polar-edge chart**, not just finitely many sample cuts. Its conclusion permits arbitrary simultaneous motions of the original ten normals and the extra normal. The local radius depends on the limiting point of the edge. The sector theorem also survives review, but covers only its specified angular region and symmetry/copy-interchange images.

Together with the accepted ten-facet theorem and the already supplied vertex/edge lifting, this reduces any possible failure of the at-most-eleven-facet Hausdorff statement to **duplicate-normal limits**. Full local maximality among polytopes with at most eleven facets remains unproved here.

The useful research advance is a finite comparison of **vertex-weighted capacity gains against an entire tilted cap-volume functional**, with cancellation of all old-normal first derivatives. The standalone count “35 edges” is not what makes the result important. The main limitation remains a continuum of sign-changing facet splits and their endpoint scales.

No new research session was launched. No repository files were edited. The accompanying integration note identifies what can be updated without treating the full theorem as proved.

## What was executed

The submitted archive was extracted to a new directory, preserving the original bytes. All 67 entries in its manifest matched. Its positive verification stages and three deliberate-corruption controls all produced the expected outcomes.

| Execution | Measured elapsed time |
|---|---:|
| Submitted vertex-insertion stage | 1.48 s |
| Submitted ridge stage | 3.69 s |
| Submitted facet-sector stage | 1.66 s |
| Three positive stages combined | 6.83 s |
| Positive stages plus three corruption controls | 12.87 s |
| Separate standard-library checker, computation after initialization | 4.58 s |
| Same checker from clean extraction, including interpreter/initialization | 5.30 s |

The clean-extraction mathematical output agreed exactly with the first independent run after removing its timing field. The three corrupted inputs failed at the intended feasibility, cancellation, or contact assertions. These are measurements of verification in this environment, not estimates of discovery cost. Exact commands, return codes, environments and outputs are retained in `logs/`. They exclude reading and mathematical review, writing the second checker, and earlier research time. No researcher-attention or model-inference cost has been measured. The numerical search panels were inspected, not rerun. In particular, the omitted 9,206-row discovery bank was not reconstructed.

The separate checker imports no submitted module and does not use SymPy. It implements arithmetic in Q[t]/(t^4-10t^2+5) with Python `Fraction`, Gaussian elimination, and independently isolated signs for the root t in (0,1). It reads the proposed witness JSON. Independence is of implementation and several derivations, not independent discovery of the witness.

## Independent finite calculations

The code in `code/independent_check.py` performs the following checks.

1. Reconstruct the regular pentagon vertices by exact rotations and the ten normals by solving the planar edge equations, rather than copying the submitted normal list. Intersect every four old hyperplanes to recover exactly 25 feasible vertices. Verify simplicity, the volume, 35 polar edges, and their four symmetry orbits of sizes 10, 10, 10 and 5.
2. Recompute positivity, closure, rank-five pivots, and touching value for all 65 old sections. Test stationarity on an explicitly constructed basis of the constraint kernel.
3. Differentiate the literal fixed-free-weight constraint solves to obtain 2,600 ambient seed-gradient entries. This is not the submitted multiplier-gradient formula. Use those derivatives to check all four weighted cancellations in R^40.
4. Recompute insertion polynomials using ordered prefix sums of weighted velocities. Check 61 contact records, half-edge endpoint signs, their polynomial interpolation (including a fourth evaluation point), and all nine zero-cost contacts for the zero-pairing representatives.
5. Reconstruct the square mass matrix and its weighted sum-of-squares majorization. Check the exact per-vertex gains and the coefficients 24/175 and (1308-36 sqrt(5))/14795 against the volume coefficient 2/25.
6. Differentiate all 26 duplicate-normal sections directly, obtaining 1,144 derivative entries in the eleven-normal chart. Aggregate the old-label-0 and new-normal derivatives, and check the positive relation cancels every one of the 40 old-coordinate entries.
7. Compute the facet's positive-part integral by **Fubini along its q-edge and exact clipped-pentagon quadratic moments**, not the submitted nine-tetrahedron divided-difference formula. The two exact answers agree. The resulting center gap is approximately 0.1134835005; acceptance uses the exact comparison with 1/10. Check the covector norm and the uniform 1/100 direction-ball estimate as well.

The new checker does not independently re-prove the accepted ten-facet certificate. Nor does it enumerate every minimizing HK word. Neither is needed for the returned sufficient-upper-bound argument: touching at the base uses the accepted HKO capacity value, and every selected feasible section is an upper bound.

## Continuum audit: why the exact coefficients imply neighborhoods

Use the packet's notation: S = rho/rho_H - 1, r is the old-normal displacement after the accepted symmetry normalization, and delta is the actual moving positive support depth.

### 1. Repeated or redundant normals

The use of duplicate labels is legitimate. Haim-Kislev's Remark 1.4 expresses reciprocal capacity as a supremum over closed loops with velocities in the polar. A feasible weighted loop remains admissible when some velocities coincide or are nonextreme polar points. Thus no unjustified irredundancy assumption is imported from the finite distinct-facet formulation.

The sign and factor are consistent with Q = sum_{i<j} beta_i beta_j omega(a_i,a_j) and c <= 1/(2Q). This is a capacity **upper** bound; no lower bound is inferred.

### 2. The tilted-cap estimate is relative to actual depth

Fix a point in the interior of a polar edge, with positive barycentric weights lambda_1 and lambda_2. Its primal face is two-dimensional. The old face persists under small old-normal perturbations because the old polytope is simple.

The packet parametrizes nearby parallel sections by the two nonnegative slacks y, then identifies each section with the moving old face. The parametrization is piecewise affine on a fixed triangulation. Its tangential Jacobian is 1+O(|y|). The change in the cutting function is

    f(z) - lambda dot y + O(||eta|| |y|),

not f(z) - lambda dot y plus an absolute error independent of y. Here eta is the deviation from the edge-base combination. Coarea and integration of a containing quadrant triangle give

    Delta V <= [1+O(||eta||+delta)] /
               [2 lambda_1 lambda_2 ||a_i wedge a_j||]
               times integral_face (f_+)^2.

This remains useful when delta is much smaller than the tilt. It is the important repair relative to a radial-only Taylor expansion. The section-combinatorics argument and the support gap justify applying the coordinates to the entire cap.

### 3. Twenty nonzero-pairing edges

Let x_v = (b dot v(A)-1)_+ at the four vertices of the moving two-face. Then max x_v = delta. The square quadrature and coarea estimate yield, at edge parameter s in (0,1),

    Delta V / V_H <= [ (2/25)/(s(1-s)) ] sum_v d_v x_v^2
                     + O((r+||b-b0||+delta) delta^2).

The selected insertion sections give the same weighted-square expression with a larger coefficient theta in the capacity-squared reduction. Their convex combination cancels the 40 old-normal linear terms. In the regime r <= D delta^2, the remainder is uniformly o(delta^2). Since every d_v is positive and some x_v = delta, the gap theta-2/25 proves a negative multiple of delta^2.

The regime r > D delta^2 is instead handled by the accepted ten-facet deficit and monotonicity:

    S <= -kappa r + C delta^2.

Choosing D first, then the neighborhood, proves S <= -c(r+delta^2) in both regimes. It does not assume a fixed ray or any relationship between tilt and depth. All constants are local to a fixed interior edge point; they may deteriorate at an endpoint.

### 4. Fifteen zero-pairing edges

Each vertex of the exposed face has a contact insertion whose quadratic cost vanishes along the entire polar edge. For e=||b-b0|| and fixed-old depth delta_0, taking the new weight proportional to delta_0/e yields a capacity benefit of order delta_0^2/e. The weight stays uniformly small even though it need not tend to zero: the base insertion is flat.

The correct coupled comparison keeps delta_0 in this denominator:

    S <= Lr - a delta_0^2/e,
    S <= -kappa r + C delta_0^2 + Cr^2.

Positive weighting and small e,r give a negative multiple of r+delta_0^2/e. The case e=0 is handled separately. Since delta <= delta_0+Cr, this implies the stated weaker r+delta^2 estimate. The proof does not incorrectly divide a moving-depth error by e.

### 5. Facet sector

At b=a_0(A)+tD, the first volume term is the genuine positive-part integral

    v(D) = [1/(V_H ||a_0||)] integral_F (D dot x)_+ dS.

It is not the signed whole-facet variation. A one-slack version of the section argument gives the uniform error O(rt+t^2), including sign changes.

The aggregate gradient must include the new normal's response in the old a_0 derivative. That aggregation is present and checked. The 26-section relation therefore yields

    S <= -t/20 + C(r+t)^2

throughout the stated compact D-ball. This does not suffice when r is much larger than t. The proof correctly adds S <= -kappa r+C't, splits at r=D_0 t, and obtains a common-radius negative bound -c(r+t).

The exact center gap exceeds 1/10. The capacity-response Lipschitz constant is less than 1 in the l1 norm and the volume-response constant is at most 2/5. Hence the gap throughout the radius-1/100 ball exceeds 43/500, stronger than the stated 1/20. The base vertex signs have a buffer, ensuring this sector is a genuine split rather than a redundant extra row.

### 6. Final Hausdorff reduction

Every sufficiently close polar with at most eleven vertices has at least one vertex in each of the ten separated exposed neighborhoods of HKO's polar vertices. After choosing one in each, there is at most one vertex left. Along a subsequence its limit is in the HKO polar. Existing neighborhood theorems exclude limits in its interior and in all open positive-dimensional faces.

Thus any remaining improving sequence must limit to a duplicate original normal. This compactness argument is sound. It does **not** turn the separate open-edge radii into a uniform radius at their endpoints.

## Exact status to retain

- Accepted input: sharp F=10 theorem modulo the stated symmetries.
- Audited input: all Case III/IV neighborhoods via insertion and the tube-volume estimate.
- New checked result: all Case II neighborhoods, including arbitrary tilt, old-normal motion and relative scales.
- New checked result: the explicit Case I sector at D=(8,6,13,-11), plus its stated images.
- Open: unrestricted duplicate-normal charts; full F<=11 Hausdorff local maximality; facet-independent local maximality.

The bound is on the actual ratio, but the displayed theta values and the facet response are sufficient witness coefficients, not claimed exact capacity Taylor coefficients. Likewise, neither a complete zero-slope classification nor a global capacity formula has been proved by this packet.

## Research-allocation consequence

This is a genuine closure of a whole stratum. It is not evidence that uniformly adding more tiny angular sectors will finish the duplicate case. The first-order witness direction problem can be formulated as a concrete convex containment problem; `DUPLICATE_DIRECTION_REDUCTION.md` spells it out. That is an optional next method, not a new containment theorem or a claim of tractability.

The next decision-bearing target would be global directional coverage with a characterized equality/contact set, followed by the endpoint remainder argument. Another isolated successful direction alone would not answer that question. A failure of a chosen finite witness bank still does not falsify HKO local maximality.

## References

1. P. Haim-Kislev, *On the symplectic size of convex polytopes*, Theorem 1.1 and Remark 1.4, https://arxiv.org/html/1712.03494v3 . Checked for the sign/factor and repeated-normal justification in this review.
2. P. Haim-Kislev and Y. Ostrover, *A Counterexample to Viterbo's Conjecture*, https://arxiv.org/html/2405.16513v3 . External HKO capacity normalization.
3. Submitted mathematical sources preserved in `source_math/`; complete original return in `source/submitted_result.zip`.
4. Exact finite audit outputs and input hashes in `logs/independent.json`, with commands in `README.md`.
