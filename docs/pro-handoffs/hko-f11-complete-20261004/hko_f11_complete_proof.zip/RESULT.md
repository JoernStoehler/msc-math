# Result: the full F <= 11 local-maximality theorem is proved

Using the accepted sharp ten-facet theorem and the retained other-face/endpoint arguments, this packet completes a computer-assisted proof:

**There is a Hausdorff neighborhood of the HKO polytope in which every convex four-polytope with at most eleven genuine facets has EHZ systolic ratio at most (3+sqrt(5))/5.**

The missing universal interior split inequality is now proved, rather than sampled. No additional research session is required to fill that mathematical obligation.

The new ingredients are:

1. An exact complete core certificate for every normalized split direction with 1/10 <= mu <= 9/10. It uses 1,968 tetrahedra, 824 cancellation relations and 3,258 positive touching rows. The uniform response margin is at least 10^-6.
2. Twenty direction-dependent response policies built from 257 entire touching-weight paths. New weights depend on the positive depths at actual facet vertices. Old weights are nonnegative quadratic Bernstein polynomials, with exact cancellation of all forty old-normal derivatives.
3. A complete exact comparison for 0 < mu <= 1/10. It reduces to degree-nine polynomial positivity on 160 sign cells, triangulated into 887 tetrahedra. All 195,140 homogeneous coefficients are nonnegative. The response margin is at least mu^2/1000. Duplicate interchange covers the other collar.
4. A closure-to-positive-sections argument: boundary weights in the policies are not incorrectly treated as two-sided feasible sections. Strict margins and the positive old anchor produce actual positive-section certificates for each interior direction.
5. The final Hausdorff contradiction argument, with all previously missing quantifiers supplied.

Read `PROOF.md` for the argument. Run `python run_checks.py --out /tmp/hko-f11-fresh --negative-controls` for the finite checks. Python's standard library suffices; no optimizer is used for verification.

The new proof is computer-assisted mathematics, not proof-assistant formalization or externally refereed work. The spatial neighborhood radius remains existential. No full eleven-facet equality classification, unlimited-facet theorem, global-maximality theorem, or novelty determination is claimed.

The original endpoint return, ridge return, and prior audits are preserved with their historical status text. Their statements that the interior problem remains open are superseded by `PROOF.md`, not silently edited.

## Final replay

All four positive verification stages and all three deliberate-corruption controls passed from a clean archive extraction in 217.32 seconds. See `FINAL_VERIFICATION.md` and `evidence/clean_replay/`.
