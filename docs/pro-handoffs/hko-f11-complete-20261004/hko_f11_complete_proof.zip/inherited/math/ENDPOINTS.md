# Uniform exclusion of all redundant-limit duplicate splits

## Theorem E (conditional only on the accepted ten-facet sharpness input)

Use the normal coordinates and the simultaneous symmetry normalization in the
assignment. Write

\[
 A=A_H+H,\quad r=\|H\|,\quad b=a_0(A)+d,
 \qquad K=P(A)\cap\{b\cdot x\leq1\}.
\]

For a genuine split of the moving old facet \(F(A)\), set

\[
 m_+=\max_{F(A)}d\cdot x>0,\quad m_-=-\min_{F(A)}d\cdot x>0,
 \quad t=m_++m_-,\quad D=d/t,\quad\mu=m_+/t.
\]

There are **two constants** \(\epsilon>0\) and \(\eta>0\) such that

\[
 r+\|d\|<\epsilon,\qquad
 \min(\mu,1-\mu)<\eta
 \quad\Longrightarrow\quad \rho(K)\leq\rho_H.                 \tag{E1}
\]

The redundant cases themselves also satisfy the conclusion. The constants
are common to all directions in this collar, all old-normal motions, and
all relative scales. The conclusion pulls back to the unnormalized chart
and applies at every duplicate normal by HKO symmetry.

Equivalently, there is **no improving sequence** approaching a duplicate
normal for which \(\mu\to0\) or \(\mu\to1\). This is stronger than a result
on each fixed redundant ray. It does not assert the missing interior-split
theorem, and does not assert that interior zero-margin directions are absent.

### Accepted input and finite data

The sole sharpness input is the supplied ten-facet theorem

\[
 \rho(P(A))/\rho_H-1\leq-\kappa r.                          \tag{E2}
\]

All quantities below use \(Q_H=\tau/5\), \(V_H=25(5+\sqrt5)/32\),
\(\tau=\sqrt{5-2\sqrt5}\). The finite contact and cancellation identities
used here are checked in `code/check_new.py`, over \(\mathbb Q(\tau)\).
They are inherited data, but their endpoint coverage is checked anew.
The rescaled estimates and the common-collar conclusion are the new argument.

A feasible polar-loop section with objective \(Q>0\) gives

\[
 \rho(K)/\rho_H\leq (Q_H/Q)^2 V_H/V(K).                    \tag{E3}
\]

This follows from the polar-loop principle in Haim-Kislev, *On the symplectic
size of convex polytopes*, Remark 1.4; it allows redundant/repeated velocities.
The finite upper-witness convention is exactly the assignment's convention.
No capacity lower bound is used anywhere in this proof.

## 1. Cap estimates that retain the small cap as a factor

All old polytopes in this proof lie in a fixed neighborhood of the simple
polytope \(H\). Their labelled vertices, facets and incidences persist.
Their vertex coordinates and the indicated affine parametrizations depend
smoothly on \(A\). The facet \(F(A)\) has ten vertices spanning \(\mathbb R^4\)
linearly. Consequently \(D\) is uniformly bounded when its values on these
vertices lie between \(-1\) and 1. In particular \(\|d\|=O(t)\).

For \(b\) close to \(a_0\), all support-maximizing old vertices lie on
\(F(A)\): the other old vertices have a fixed support gap. Thus

\[
 \delta=(h_{P(A)}(b)-1)_+=t\mu.                            \tag{E4}
\]

Let \(\Delta V=V(P(A))-V(K)\). There is a uniform relative estimate

\[
 \Delta V\leq (1+C\|d\|)
    \frac1{\|a_0(A)\|}\int_{F(A)}(d\cdot z)_+\,dS(z).      \tag{E5}
\]

Here and below constants can be enlarged after shrinking the fixed chart.
For detail, use slack \(y=1-a_0(A)\cdot x\geq0\), its orthogonal right
inverse \(T_A\), and a fixed labelled triangulation of the facet. The
parallel section at slack \(y\), projected onto \(\operatorname{aff}F(A)\),
is parametrized by a piecewise-affine map \(\Phi_{A,y}\) with

\[
 \Phi_{A,y}(z)-z=O(y),\qquad J_{\rm tang}\Phi_{A,y}=1+O(y).
\]

These statements follow by solving the three other active equations at each
facet vertex; inactive inequalities retain strict gaps. The usual convex
vertex representation puts every removed point in this small-slack region.
In these coordinates the removal condition is

\[
 d\cdot z-y+d\cdot(\Phi_{A,y}(z)-z-T_Ay)>0.
\]

The last term is bounded by \(C\|d\|y\). Removal therefore requires
\(d\cdot z>0\) and allows thickness at most
\((d\cdot z)_+/(1-C\|d\|)\). Also \(y=O(\delta)=O(\|d\|)\).
Coarea and integration prove (E5). This is a relative estimate, not an
absolute \(O(t^2)\) expansion. It remains valid for arbitrarily small
positive caps and for sign-degenerate vertex values.

Monotonicity of capacity and (E2) imply

\[
 S:=\rho(K)/\rho_H-1\leq-\kappa_1r+C\Delta V/V_H.          \tag{E6}
\]

Indeed \(\rho(K)\leq\rho(P(A))V(P(A))/V(K)\), and both volumes stay
bounded above and below. In particular **on an improving sequence**,

\[
 r\leq C\Delta V/V_H.                                    \tag{E7}
\]

## 2. Geometry of a redundant limiting direction

Suppose, toward a contradiction, that an improving sequence has \(\mu\to0\).
Pass to a subsequence so that \(D\to D_*\). Then

\[
 \max_{F_H}D_*\cdot x=0,\qquad \min_{F_H}D_*\cdot x=-1.
\]

The exposed set

\[
 E=\{x\in F_H:D_*\cdot x=0\}
\]

is a proper face of the three-dimensional facet, of dimension
\(k\in\{0,1,2\}\). All vertices outside its moving labelled copy \(E(A)\)
have \(D\)-value at most a fixed negative constant. A point of \(F(A)\)
where \(D\cdot z>0\), represented as a convex combination of facet vertices,
has total coefficient on those outside vertices at most \(C\mu\).
It is therefore in an \(O(\mu)\)-tube of \(E(A)\). Since the facet is
three-dimensional, the measure of that tube is \(O(\mu^{3-k})\), while
\((D\cdot z)_+\leq\mu\). Equation (E5) yields

\[
 \Delta V/V_H\leq C t\mu^{4-k},\qquad
 r\leq C t\mu^{4-k}                                      \tag{E8}
\]

on the putative improving sequence. These estimates are uniform near the
chosen \(D_*\); they do not require the tilt error to be smaller than \(\mu\).

## 3. Uniform insertion formulas and feasibility

For a selected positive old seed, continue its five pivot weights using the
moving closure and normalization equations. Insert the extra normal with
weight \(z\geq0\), correcting those pivot weights. Its objective is **exactly
quadratic in \(z\)**:

\[
 Q(A,b,z)=Q_k(A)+L_k(A,b)z+R_k(A,b)z^2.                    \tag{E9}
\]

The coefficients are smooth with uniformly bounded derivatives on the fixed
chart. For a branch contacting a labelled old vertex \(v\), the exact data give

\[
 L_k(A_H,b)=2Q_H(v\cdot b-1).
\]

Since the moving vertex varies smoothly,

\[
 L_k(A,b)=2Q_H(b\cdot v(A)-1)+O(r).                       \tag{E10}
\]

Every stored base weight is strictly positive; the pivot inverses are bounded.
For the finitely many branches used below, any chosen weights \(z\to0\) are
therefore simultaneously feasible, after shrinking the neighborhood. This
includes sequences where \(z\) tends to zero at a rate different from \(t\).

The new checker verifies, for **every one of the ten vertices of \(F_H\)**,
a branch with the contact identity and

\[
 R_k(A_H,a_0)=0.                                         \tag{E11}
\]

Five contacts come from the zero-pairing edge \((0,1)\); its rotated image
at \((0,4)\) supplies the other five. Thus for these branches

\[
 |R_k(A,b)|\leq C(r+t).                                  \tag{E12}
\]

## 4. Limiting contact dimension zero or one

Choose a maximizing vertex of \(E(A)\), so its cut value is \(\delta=t\mu\),
and use its branch from (E11). Set \(z=\alpha\mu\), with a fixed sufficiently
small \(\alpha>0\). Equations (E9)--(E12) give

\[
 Q(A,b,z)\geq Q_k(A)+2Q_H\alpha t\mu^2
                    -C\alpha r\mu-C\alpha^2(t+r)\mu^2.
\]

Choose \(\alpha\) first, so that the \(t\mu^2\) coefficient is positive.
For \(k\leq1\), (E8) gives \(r=O(t\mu^3)=o(t\mu^2)\), and also
\(\Delta V=o(t\mu^2)\). Since \(Q_k(A)=Q_H+O(r)\), (E3) implies

\[
 S\leq Cr+C\Delta V/V_H-a t\mu^2+o(t\mu^2)<0.
\]

This contradicts improvement. No cancellation of old gradients is needed
in these two contact dimensions.

## 5. A shrinking polar-edge model for contact dimension two

Now \(E=F_H\cap F_j\), where \(j\) is one of the seven polar neighbors of
0. A linear form vanishing on the affine two-face \(E\) is a multiple of
\(a_j-a_0\): the linear span of \(E\) has dimension three, and its annihilator
is that line. The sign condition therefore gives

\[
 D_*=\ell(a_j-a_0),\qquad\ell>0.
\]

Put

\[
 s=\ell t,\qquad b_*=(1-s)a_0(A)+sa_j(A),\qquad e=b-b_*.
\]

Then

\[
 s\to0,\quad \|e\|/s\to0,\quad \delta/s\to0,\qquad
 r=O(\delta^2/s),\quad r/s\to0.                          \tag{E13}
\]

The support maximum is attained among the vertices of \(E(A)\). This follows
from the strict limiting \(D_*\)-gap on the other vertices of \(F_H\) and the
fixed \(a_0\)-gap outside \(F_H\). These observations justify the use of the
moving face even when \(\delta\) is much smaller than \(\|e\|\).

### 5.1 Relative volume estimate with the small coefficient retained

Use the two nonnegative slacks \(y_0,y_j\), the orthogonal right inverse of
the two-row normal matrix, and a labelled triangulation of \(E(A)\).
A convex vertex representation first shows that all removed points have
\(|y|=O(\delta/s)\): vertices outside \(E(A)\) have a support gap at least
\(c s\), whereas the maximum excess is \(\delta\).
This tends to zero, so the same piecewise-affine section parametrizations
used for fixed edges remain available. Their tangential Jacobians are
\(1+O(\delta/s)\).

For \(f(z)=b\cdot z-1\), the exact slack identity is

\[
 b\cdot x-1=f(z)-(1-s)y_0-sy_j
                   +e\cdot(\Phi_{A,y}(z)-z-T_Ay).
\]

The last term is bounded by \(C\|e\||y|\), and hence by
\(C\|e\|/s\) times \((1-s)y_0+sy_j\). Thus its relative size tends to zero.
Coarea and integration of the containing quadrant triangle give

\[
 \Delta V\leq
 \frac{1+O(\|e\|/s+\delta/s)}
      {2s(1-s)\|a_0(A)\wedge a_j(A)\|}
       \int_{E(A)}f_+^2\,dS.                            \tag{E14}
\]

The three small quantities are \(\|e\|/s\), \(\delta/s\), and \(r\), not just
\(\|e\|\), \(\delta\), and \(r\). This is the required strengthening of the
fixed-open-edge argument. Nothing assumes its previously given radii are
uniform at endpoints.

### 5.2 Nonzero symplectic pairings: \(j=6,7,8,9\)

These two-faces are rectangles at the base. The supplied vertex quadrature
has positive numbers \(d_v\), and the checked sum-of-squares identity gives

\[
 \operatorname{avg}_{E(A)}f_+^2
       \leq \sum_v d_v x_v^2+O(r\delta^2),\qquad
 x_v=(b\cdot v(A)-1)_+.
\]

For clarity, triangulate the rectangle along the supplied diagonal. On each
triangle, the positive part is bounded by the affine interpolant of the
positive vertex values. Its integrated square has mass matrix \(M\).
For the positive vector \(u\) in the data, \(d_v=(Mu)_v/u_v\), and

\[
 \sum_vd_vx_v^2-x^TMx
 =\sum_{v<w}M_{vw}u_vu_w(x_v/u_v-x_w/u_w)^2\geq0.
\]

The moving triangle areas change this by \(O(r\delta^2)\). The exact base
coarea factor is \(\operatorname{area}(E)/(2\|a_0\wedge a_j\|V_H)=2/25\).
Consequently (E14) becomes

\[
 \Delta V/V_H\leq
   \frac{2/25}{s(1-s)}\sum_vd_vx_v^2+o(\delta^2/s).        \tag{E15}
\]

All small remainders in this section are uniform along arbitrary sequences
satisfying (E13).

For each relevant insertion branch, with the duplicate endpoint oriented
at 0, the data give

\[
 R_k(0)=0,\quad R_k(1/2)<0,\quad R_k(1)\leq0.
\]

Its quadratic dependence on \(s\) implies, on \(0\leq s\leq1/2\),

\[
 R_k(s)\geq4R_k(1/2)s(1-s)=-C_k(s),\quad C_k(s)>0.
\]

Indeed the difference is \(2R_k(1)s(s-1/2)\geq0\). Smoothness then gives

\[
 Q(A,b,z)\geq Q_k(A)+2Q_Hx_vz-C_k(s)z^2
                              -C(rz+(r+\|e\|)z^2)        \tag{E16}
\]

when \(x_v>0\); for \(x_v=0\) choose \(z=0\). Set
\(z=Q_Hx_v/C_k(s)=O(\delta/s)\). This tends to zero, so it is feasible.
Using (E3), the exact quadratic formula, and the old volume differential gives

\[
 S\leq G_k\cdot H+\Delta V/V_H
    -\frac{\gamma_k}{s(1-s)}x_v^2+o(\delta^2/s),\qquad
 \gamma_k=-Q_H/(2R_k(1/2))>0.                            \tag{E17}
\]

Here \(G_k\) is the **old seed** relative-ratio gradient. To check the
relative error explicitly, the nontrivial error terms are bounded by

\[
 C\left[r^2+r\delta/s+(r+\|e\|)\delta^2/s^2
                +(r+\delta^2/s)^2\right].
\]

Dividing by \(\delta^2/s\) makes every term tend to zero by (E13).
There is no absolute \(O(t^2)\) term. The section's value at \(z=0\) depends
only on \(A\), not on \(b\); this is why expansion of (E9) preserves the
small-cap factor.

The positive coefficients supplied for each chart satisfy exactly

\[
 \sum\lambda_k=1,\quad\sum\lambda_kG_k=0,\qquad
 \sum_{k\text{ assigned to }v}\lambda_k\gamma_k\geq\theta d_v,
 \quad\theta>2/25.
\]

The two values are \(24/175\) and \((1308-36\sqrt5)/14795\), with the
appropriate symmetry/interchange images. All four oriented charts at a0
are checked separately in the new checker. Taking the weighted sum of
(E17), and then (E15), yields

\[
 S\leq-\frac{\theta-2/25}{s(1-s)}\sum_vd_vx_v^2
                                      +o(\delta^2/s)<0.
\]

At least one \(x_v\) equals \(\delta\), and every \(d_v>0\), so the strict
last inequality follows. This excludes these four shrinking-edge limits.

### 5.3 Zero symplectic pairings: \(j=1,4,5\)

Here the supplied branches cover every vertex of \(E\) and satisfy
\(R_k(A_H,(1-s)a_0+sa_j)=0\) identically in \(s\). For a maximizing vertex,
(E9)--(E10) therefore give

\[
 Q(A,b,z)\geq Q_k(A)+2Q_H\delta z
                              -C(rz+(r+\|e\|)z^2).
\]

The elementary cap bound in (E8) already gives
\(\Delta V/V_H\leq C_0\delta^2/s\) and, on an improving sequence,
\(r\leq M\delta^2/s\), for fixed constants \(C_0,M\).
Choose a **fixed** constant \(B\) and put \(z=B\delta/s\).
For every fixed \(B\) this tends to zero and is feasible. Expanding (E3),
with \(|G_k\cdot H|\leq Lr\), gives

\[
 S\leq (LM+C_0-4B)\delta^2/s+o_B(\delta^2/s).
\]

The errors have the same relative bounds as above, multiplied by fixed
powers of \(B\). Choose \(B>(LM+C_0+1)/4\), and then take the sequence far
enough out. The result is negative, a contradiction. This proves the zero-
pairing cases without inventing endpoint-uniform constants for the old
open-edge theorem and without requiring a new cancellation relation.

## 6. The other endpoint, common collar, and normalization

If \(\mu\to1\), exchange the two duplicate inequalities, using \(b\) as the
old label 0 and \(a_0(A)\) as the extra row. The new old presentation remains
near \(A_H\). Both presentations have genuine splits unless a redundant case
has already reduced the body to at most ten facets.
The new facet converges to \(F_H\), while the normalized extra difference
converges to a positive multiple of \(-D_*\). Its maximum tends to zero and
its oscillation stays bounded away from zero. Thus the new \(\mu\) tends
to zero. Normalize this entire presentation and apply the result just proved.
Only convergence to zero is used; no error estimate relative to \(1-\mu\)
is being assumed.

For completeness, simultaneous translations, dilations and symplectic maps
act smoothly on normalized normal rows near the identity. The difference
of two nearby rows is taken to its derivative applied to that difference,
with an \(o(\|d\|)\) error. After undoing a symmetry at the base, this
derivative tends to the identity. The moving facets also converge. Hence
endpoint convergence of \(\mu\), genuine splitting, and improvement are
preserved in these arguments. This justifies the normalization and label
exchange used above.

If (E1) were false for every pair \((\epsilon,\eta)\), choose an improving
example with both constants replaced by \(1/n\). A subsequence has either
\(\mu\to0\) or \(\mu\to1\). The preceding cases contradict both possibilities.
This proves one common collar and one common local radius, without computing
either. The elementary redundant cases follow from (E2), as in the supplied
handoff. Symmetry covers the other nine duplicate normals. \(\square\)
