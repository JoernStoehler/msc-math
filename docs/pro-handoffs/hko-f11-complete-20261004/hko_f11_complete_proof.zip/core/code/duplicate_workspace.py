#!/usr/bin/env python3
"""An exact starting bank and diagnostic LP for the missing duplicate-normal case.

Reuses the supplied independently implemented finite arithmetic checker. This is
an entry point for further research, NOT a complete directional certificate or
a capacity evaluator. Exact preparation/calibration uses the standard library;
the optional `probe` uses NumPy/SciPy and is numerical evidence only.
"""
from __future__ import annotations
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'code'))
import exact_core as a

DATA = ROOT / 'data'


def atomic_new_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as f:
        json.dump(obj, f, indent=2)
        f.write('\n')


def encoded(x: a.K) -> list[str]:
    # Interchange format matches supplied JSON: descending coefficients.
    vals = list(reversed(x.coefficients()))
    while len(vals) > 1 and vals[0] == '0':
        vals.pop(0)
    return vals


def volume_response(d: list[a.K]) -> a.K:
    """Exact normalized positive-part integral on F0, including zero edge slope.

    For nonzero slope, reuse Fubini with clipped quadratic moments. When the
    integrand is constant on the q-edge, clip the p-pentagon and integrate the
    affine positive part by triangle means. This handles the repeated-value
    cases excluded by the original sector-only tetrahedron formula.
    """
    if len(d) != 4:
        raise ValueError('four direction coordinates required')
    c0, c1 = a.dot(d[:2], a.U[0]), a.dot(d[:2], a.U[1])
    if c0 != c1:
        return a.facet_integral(d)
    linear = lambda p: c0 + a.dot(d[2:], p)
    out = []
    for i, p in enumerate(a.W):
        q = a.W[(i + 1) % len(a.W)]
        fp, fq = linear(p), linear(q)
        pin, qin = a.sign(fp) >= 0, a.sign(fq) >= 0
        if pin:
            out.append(p)
        if pin != qin:
            t = fp / (fp - fq)
            out.append([p[j] + t * (q[j] - p[j]) for j in range(2)])
    clean = []
    for p in out:
        if not clean or p != clean[-1]:
            clean.append(p)
    if len(clean) > 1 and clean[0] == clean[-1]:
        clean.pop()
    total = a.ZERO
    for i in range(1, len(clean) - 1):
        tri = [clean[0], clean[i], clean[i + 1]]
        signed_area = a.det2([tri[1][j] - tri[0][j] for j in range(2)],
                            [tri[2][j] - tri[0][j] for j in range(2)]) / 2
        if a.sign(signed_area) < 0:
            raise ValueError('unexpected clipping orientation')
        total += signed_area * sum((linear(p) for p in tri), a.ZERO) / 3
    return a.K(Fraction(2, 5)) * total / a.area(a.W)


def prepare() -> dict:
    start = time.perf_counter()
    old = json.loads((DATA / 'seeds.json').read_text())
    fac = json.loads((DATA / 'facet_cone_certificate.json').read_text())
    raw = []
    for i, row in enumerate(old):
        raw.append(dict(origin=f'old_seed_{i}', sigma=row['sigma'],
                        beta=[encoded(a.VALUES[s]) for s in row['weights']],
                        pivot=row['pivot']))
    for i, row in enumerate(fac['terms']):
        raw.append(dict(origin=f'facet_sector_{i}', sigma=row['sigma'],
                        beta=row['beta'], pivot=row['pivot']))
    # Duplicate interchange adds witnesses without choosing new free weights.
    raw += [dict(origin=r['origin'] + '_swapped',
                 sigma=[10 if i == 0 else 0 if i == 10 else i for i in r['sigma']],
                 beta=r['beta'], pivot=r['pivot']) for r in list(raw)]
    seen, rows = set(), []
    for row in raw:
        beta = list(map(a.decode, row['beta']))
        key = (tuple(row['sigma']), tuple(beta), tuple(row['pivot']))
        if key in seen:
            continue
        seen.add(key)
        sec = a.Section(a.A + [a.A[0]], row['sigma'], beta, row['pivot'])
        gq = sec.gradient()
        c = a.scale(2 / a.Q0, gq[10])
        aggregate = [x[:] for x in gq[:10]]
        aggregate[0] = a.add(aggregate[0], gq[10])
        G = [-2 * x / a.Q0 - a.VOL_GRAD[j] / a.V0
             for j, x in enumerate(sum(aggregate, []))]
        rows.append(dict(**row, G=[encoded(x) for x in G], c=[encoded(x) for x in c],
                         G_f64=list(map(a.nominal, G)), c_f64=list(map(a.nominal, c))))
    return dict(
        schema='duplicate-normal-starting-bank-v1',
        status='Exact positive touching sections; NOT complete direction coverage.',
        coefficient_order='descending powers of tau; tau^4-10*tau^2+5=0; 0<tau<1',
        Q0=encoded(a.Q0), V0=encoded(a.V0),
        source_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in [DATA / 'seeds.json', DATA / 'facet_cone_certificate.json']},
        section_count=len(rows), sections=rows, seconds=time.perf_counter() - start)


def calibration(bank: dict) -> dict:
    fac = json.loads((DATA / 'facet_cone_certificate.json').read_text())
    rows = {(tuple(r['sigma']), tuple(map(a.decode, r['beta'])), tuple(r['pivot'])): r
            for r in bank['sections']}
    g, c, mass = [a.ZERO] * 40, [a.ZERO] * 4, a.ZERO
    for i, term in enumerate(fac['terms']):
        r = rows[(tuple(term['sigma']), tuple(map(a.decode, term['beta'])), tuple(term['pivot']))]
        lam = a.decode(term['lambda'])
        g = a.add(g, a.scale(lam, list(map(a.decode, r['G']))))
        c = a.add(c, a.scale(lam, list(map(a.decode, r['c']))))
        mass += lam
    if mass != a.ONE or g != [a.ZERO] * 40:
        raise ValueError('sector cancellation did not reproduce')
    d = list(map(a.K, [8, 6, 13, -11]))
    v = volume_response(d)
    gap = a.dot(c, d) - v
    if a.sign(gap - a.K(Fraction(1, 10))) <= 0:
        raise ValueError('known sector margin did not reproduce')
    # Tests of degenerate/repeated-node directions and support symmetry.
    if volume_response(a.A[0]) != a.K(Fraction(2, 5)):
        raise ValueError('whole-facet radial integral')
    if volume_response(a.scale(-1, a.A[0])) != a.ZERO:
        raise ValueError('redundant radial integral')
    if volume_response([a.ZERO] * 4) != a.ZERO:
        raise ValueError('zero integral')
    w = [-x / a.V0 for x in a.VOL_GRAD[:4]]
    tests = [d, a.A[0], [a.ZERO, a.ZERO, a.ONE, a.ZERO],
             [a.ZERO, a.ZERO, a.ZERO, a.ONE],
             [a.ONE, a.ZERO, a.ONE, -a.ONE]]
    for q in tests:
        if volume_response(q) - volume_response(a.scale(-1, q)) != a.dot(w, q):
            raise ValueError('positive-part support identity')
    return dict(all_checks_passed=True, sections=bank['section_count'],
                exact_sector_gradient_cancellation=True,
                center_gap_gt='1/10', center_gap_nominal=a.nominal(gap),
                volume_response_checks=len(tests) + 3,
                scope='Code calibration only; no new directional or F<=11 theorem.')


def probe(bank: dict, d: list[a.K]) -> dict:
    import numpy as np
    from scipy.optimize import linprog
    G = np.array([r['G_f64'] for r in bank['sections']], dtype=float)
    C = np.array([r['c_f64'] for r in bank['sections']], dtype=float)
    direction = np.array(list(map(a.nominal, d)))
    eq = np.vstack([np.ones(len(G)), G.T]); rhs = np.r_[1., np.zeros(40)]
    result = linprog(-C @ direction, A_eq=eq, b_eq=rhs, bounds=(0, None), method='highs')
    v = volume_response(d)
    out = dict(status='Numerical LP over this finite bank only; NOT a certificate.',
               direction=[encoded(x) for x in d],
               volume_response_exact=encoded(v), volume_response_f64=a.nominal(v),
               lp_success=bool(result.success), solver_message=result.message)
    if result.success:
        out.update(support_f64=float(-result.fun),
                   suggested_gap_f64=float(-result.fun-a.nominal(v)),
                   max_cancellation_residual=float(np.max(np.abs(eq @ result.x - rhs))),
                   positive_weights=[dict(index=i, origin=bank['sections'][i]['origin'], weight=float(x))
                                     for i, x in enumerate(result.x) if x > 1e-12])
    return out


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='mode', required=True)
    for mode in ['prepare', 'calibrate']:
        s = sub.add_parser(mode); s.add_argument('--out', type=Path, required=True)
        if mode == 'calibrate': s.add_argument('--bank', type=Path, required=True)
    s = sub.add_parser('probe')
    s.add_argument('--bank', type=Path, required=True)
    s.add_argument('--direction', nargs=4, required=True,
                   help='four rational coordinates, e.g. 8 6 13 -11')
    s.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    if args.mode == 'prepare':
        out = prepare()
    else:
        bank = json.loads(args.bank.read_text())
        out = calibration(bank) if args.mode == 'calibrate' else probe(bank, [a.K(Fraction(x)) for x in args.direction])
    atomic_new_json(args.out, out)
    print(json.dumps({k:v for k,v in out.items() if k not in ['sections', 'positive_weights']}, indent=2))

if __name__ == '__main__':
    main()
